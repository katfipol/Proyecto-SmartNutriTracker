# SmartNutriTracker · Equipo 3 – Gestión de Alimentos

**Historias de usuario:** HU-14 a HU-17  
**Proyecto:** SmartNutriTracker – Colegio "Innovare" · Programación Web III  
**Tecnologías:** .NET 10 · ASP.NET Core Web API · Entity Framework Core 10 · SQL Server · HTML + JS + Bootstrap 5

Este ZIP contiene **solo la parte del Equipo 3**, con las mismas rutas del proyecto completo.
Para tener el sistema funcionando, **descomprima los 6 ZIP en la misma carpeta**: los archivos no se pisan.

---

## 1. Historias de usuario implementadas

| HU | Descripción | Implementación |
|---|---|---|
| HU-14 | Registro de alimentos | `AlimentosService.CrearAsync` · `POST /api/alimentos` (valida coherencia de macros/calorías) |
| HU-15 | Editar y eliminar alimentos | `PUT/DELETE /api/alimentos/{id}`: si el alimento ya se usó, se desactiva para conservar el historial |
| HU-16 | Crear menú diario | `MenusService.CrearAsync` · `POST /api/menus` (alimentos por tiempo de comida) |
| HU-17 | Ver resumen nutricional | `Mapeos.Resumen` evalúa el % de macros con los rangos AMDR · `POST /api/menus/resumen` |

### Clases compartidas que aporta este equipo
`Mapeos.Equipo3.cs` agrupa las comidas, calcula los totales y arma el resumen nutricional.
También lo usan los registros (Equipo 4) y las recomendaciones (Equipo 5).

## 2. Base de datos

**Script del equipo:** `database/por_equipo/3_Equipo3_Alimentos.sql`

Orden de ejecución en SSMS (base nueva): **Equipo 1 → 2 → 3 → 4 → 5 → 6**.
- El script del Equipo 1 crea la base desde cero.
- Cada script comprueba que ya se ejecutaron los anteriores.

### Tablas del equipo
- `CategoriasAlimento`
- `TiposComida`
- `TipoComidaCategorias`
- `Alimentos`
- `MenusDiarios`
- `MenuDetalles`

### Normalización (3FN)
- `Alimentos.CategoriaAlimentoId` es una FK: el nombre de la categoría no se repite en cada alimento.
- `MenuDetalles` guarda solo `AlimentoId` y `Porciones`. **Las calorías y los macros se calculan** (`Alimento × porciones`), no se guardan.
- `TipoComidaCategorias` tiene clave compuesta (TipoComida, Categoría), y su `Orden` depende de la clave completa (2FN).

## 3. API REST (endpoints del equipo)

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/api/alimentos` | Cualquier usuario autenticado | Listar |
| GET | `/api/alimentos/{id}` | Cualquier usuario autenticado | Obtener por id |
| POST | `/api/alimentos` | Admin, Nutricionista | Crear |
| PUT | `/api/alimentos/{id}` | Admin, Nutricionista | Actualizar |
| DELETE | `/api/alimentos/{id}` | Admin, Nutricionista | Eliminar |
| GET | `/api/menus` | Cualquier usuario autenticado | Listar |
| GET | `/api/menus/{id}` | Cualquier usuario autenticado | Obtener por id |
| POST | `/api/menus` | Admin, Nutricionista | Crear |
| PUT | `/api/menus/{id}` | Admin, Nutricionista | Actualizar |
| DELETE | `/api/menus/{id}` | Admin, Nutricionista | Eliminar |
| POST | `/api/menus/resumen` | Cualquier usuario autenticado | HU-17 – Calcula el valor total de una lista de alimentos sin guardarla. |

Todas las rutas (salvo el login) requieren el encabezado `Authorization: Bearer <token>`.
Para probarlas en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 4. Frontend (pantallas del equipo)
- Alimentos: catálogo con filtros y CRUD (`vistas/alimentos.js`)
- Menús diarios: creación con resumen nutricional en vivo (`vistas/menus.js`)

## 5. Archivos del equipo

**Backend**
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/ContextoDatos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Entidades.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Servicios/AlimentosService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Servicios/Mapeos.Equipo3.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo3_Alimentos/Servicios/MenusService.cs`

**Frontend**
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/alimentos.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/menus.js`

**Base de datos**
- `database/por_equipo/3_Equipo3_Alimentos.sql`

## 6. Dependencias con otros equipos
Equipo 1 (usuarios). Su catálogo lo usan los Equipos 4 y 5.

La integración se hace así:
- **Clase parcial `SmartNutriDbContext`:** cada equipo aporta sus `DbSet` y su configuración en `ContextoDatos.cs`, mediante el método `ConfigurarEquipo3`.
- **Clase parcial `Mapeos`:** cada equipo aporta sus conversiones a DTO.
- **Inyección de dependencias:** los servicios se registran en `Program.cs`, que entrega el Equipo 1.

## 7. Cómo ejecutar el sistema completo
1. Descomprima los 6 ZIP en la misma carpeta (por ejemplo `SmartNutriTracker/`).
2. Ejecute en SSMS los scripts `database/por_equipo/1_…sql` a `6_…sql`, en orden.
3. Ajuste la cadena de conexión en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
4. En la carpeta raíz, ejecute:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
5. Abra http://localhost:5200 para el sistema y http://localhost:5200/swagger para la API.

**Usuarios de prueba** (contraseña `Innovare2026!`):

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |
