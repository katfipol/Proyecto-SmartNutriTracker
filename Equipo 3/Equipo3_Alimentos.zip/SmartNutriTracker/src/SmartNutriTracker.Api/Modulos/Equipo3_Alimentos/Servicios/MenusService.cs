// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;

namespace SmartNutriTracker.Api.Services;

public interface IMenusService
{
    Task<IReadOnlyList<MenuResumenDto>> ListarAsync(CancellationToken ct = default);
    Task<MenuDto> ObtenerAsync(int id, CancellationToken ct = default);
    Task<MenuDto> CrearAsync(MenuRequest request, CancellationToken ct = default);
    Task<MenuDto> ActualizarAsync(int id, MenuRequest request, CancellationToken ct = default);
    Task EliminarAsync(int id, CancellationToken ct = default);
    Task<ResumenNutricionalDto> ResumirAsync(IEnumerable<ItemMenuRequest> items, CancellationToken ct = default);
}

public class MenusService(SmartNutriDbContext db, IUsuarioActual usuario, IAuditoriaService auditoria) : IMenusService
{
    public async Task<IReadOnlyList<MenuResumenDto>> ListarAsync(CancellationToken ct = default)
    {
        var menus = await db.MenusDiarios.AsNoTracking()
            .Include(m => m.CreadoPor)
            .Include(m => m.Detalles).ThenInclude(d => d.Alimento)
            .OrderByDescending(m => m.Fecha).ThenByDescending(m => m.Id)
            .ToListAsync(ct);
        return menus.Select(m => new MenuResumenDto(m.Id, m.Nombre, m.Fecha, m.CreadoPor?.Nombre ?? string.Empty, m.Detalles.Count,
            Math.Round(m.Detalles.Sum(d => d.Alimento!.Calorias * d.Porciones), 0))).ToList();
    }

    public async Task<MenuDto> ObtenerAsync(int id, CancellationToken ct = default)
    {
        var m = await db.MenusDiarios.AsNoTracking()
            .Include(x => x.CreadoPor)
            .Include(x => x.Detalles).ThenInclude(d => d.Alimento).ThenInclude(a => a!.CategoriaAlimento)
            .Include(x => x.Detalles).ThenInclude(d => d.TipoComida)
            .AsSplitQuery()
            .FirstOrDefaultAsync(x => x.Id == id, ct)
            ?? throw new NoEncontradoException($"Menú {id} no encontrado.");

        var comidas = Mapeos.AgruparComidas(m.Detalles.Select(d => (d.Id, d.TipoComida!, d.Alimento!, d.Porciones)));
        var resumen = Mapeos.Resumen(Mapeos.Totales(m.Detalles.Select(d => (d.Alimento!, d.Porciones))));
        return new MenuDto(m.Id, m.Nombre, m.Fecha, m.Descripcion, m.CreadoPor?.Nombre ?? string.Empty, m.FechaCreacion, comidas, resumen);
    }

    public async Task<MenuDto> CrearAsync(MenuRequest request, CancellationToken ct = default)
    {
        await ValidarItemsAsync(request.Items, ct);
        var m = new MenuDiario
        {
            Nombre = request.Nombre.Trim(),
            Fecha = request.Fecha,
            Descripcion = request.Descripcion,
            CreadoPorId = usuario.Id,
            FechaCreacion = DateTime.UtcNow,
            Detalles = request.Items.Select(i => new MenuDetalle { TipoComidaId = i.TipoComidaId, AlimentoId = i.AlimentoId, Porciones = i.Porciones }).ToList()
        };
        db.MenusDiarios.Add(m);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CREAR", "MenuDiario", m.Id, $"{m.Nombre} ({m.Detalles.Count} ítems)", ct: ct);
        return await ObtenerAsync(m.Id, ct);
    }

    public async Task<MenuDto> ActualizarAsync(int id, MenuRequest request, CancellationToken ct = default)
    {
        var m = await db.MenusDiarios.Include(x => x.Detalles).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NoEncontradoException($"Menú {id} no encontrado.");
        await ValidarItemsAsync(request.Items, ct);
        m.Nombre = request.Nombre.Trim();
        m.Fecha = request.Fecha;
        m.Descripcion = request.Descripcion;
        db.MenuDetalles.RemoveRange(m.Detalles);
        m.Detalles = request.Items.Select(i => new MenuDetalle { MenuId = id, TipoComidaId = i.TipoComidaId, AlimentoId = i.AlimentoId, Porciones = i.Porciones }).ToList();
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "MenuDiario", id, m.Nombre, ct: ct);
        return await ObtenerAsync(id, ct);
    }

    public async Task EliminarAsync(int id, CancellationToken ct = default)
    {
        var m = await db.MenusDiarios.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Menú {id} no encontrado.");
        db.MenusDiarios.Remove(m);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ELIMINAR", "MenuDiario", id, m.Nombre, ct: ct);
    }

    public async Task<ResumenNutricionalDto> ResumirAsync(IEnumerable<ItemMenuRequest> items, CancellationToken ct = default)
    {
        var lista = items.ToList();
        var ids = lista.Select(i => i.AlimentoId).Distinct().ToList();
        var alimentos = await db.Alimentos.AsNoTracking().Where(a => ids.Contains(a.Id)).ToDictionaryAsync(a => a.Id, ct);
        var faltantes = ids.Where(i => !alimentos.ContainsKey(i)).ToList();
        if (faltantes.Count > 0) throw new NoEncontradoException($"Alimentos no encontrados: {string.Join(", ", faltantes)}.");
        return Mapeos.Resumen(Mapeos.Totales(lista.Select(i => (alimentos[i.AlimentoId], i.Porciones))));
    }

    private async Task ValidarItemsAsync(List<ItemMenuRequest> items, CancellationToken ct)
    {
        if (items.Count == 0) throw new ReglaNegocioException("El menú debe tener al menos un alimento.");
        var alimentos = items.Select(i => i.AlimentoId).Distinct().ToList();
        var tipos = items.Select(i => i.TipoComidaId).Distinct().ToList();
        if (await db.Alimentos.CountAsync(a => alimentos.Contains(a.Id) && a.Activo, ct) != alimentos.Count)
            throw new ReglaNegocioException("Hay alimentos inexistentes o inactivos en el menú.");
        if (await db.TiposComida.CountAsync(t => tipos.Contains(t.Id), ct) != tipos.Count)
            throw new ReglaNegocioException("Hay tiempos de comida no válidos en el menú.");
    }
}
