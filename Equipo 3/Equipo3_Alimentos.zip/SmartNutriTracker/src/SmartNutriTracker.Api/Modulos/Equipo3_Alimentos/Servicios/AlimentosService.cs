// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;

namespace SmartNutriTracker.Api.Services;

public interface IAlimentosService
{
    Task<IReadOnlyList<AlimentoDto>> ListarAsync(string? buscar, int? categoriaId, bool incluirInactivos, CancellationToken ct = default);
    Task<AlimentoDto> ObtenerAsync(int id, CancellationToken ct = default);
    Task<AlimentoDto> CrearAsync(AlimentoRequest request, CancellationToken ct = default);
    Task<AlimentoDto> ActualizarAsync(int id, AlimentoRequest request, CancellationToken ct = default);
    Task<string> EliminarAsync(int id, CancellationToken ct = default);
}

public class AlimentosService(SmartNutriDbContext db, IAuditoriaService auditoria) : IAlimentosService
{
    public async Task<IReadOnlyList<AlimentoDto>> ListarAsync(string? buscar, int? categoriaId, bool incluirInactivos, CancellationToken ct = default)
    {
        var q = db.Alimentos.AsNoTracking().Include(a => a.CategoriaAlimento).AsQueryable();
        if (!incluirInactivos) q = q.Where(a => a.Activo);
        if (categoriaId.HasValue) q = q.Where(a => a.CategoriaAlimentoId == categoriaId);
        if (!string.IsNullOrWhiteSpace(buscar)) q = q.Where(a => a.Nombre.Contains(buscar));
        return (await q.OrderBy(a => a.Nombre).ToListAsync(ct)).Select(Mapeos.ADto).ToList();
    }

    public async Task<AlimentoDto> ObtenerAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Alimentos.AsNoTracking().Include(x => x.CategoriaAlimento).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NoEncontradoException($"Alimento {id} no encontrado.");
        return Mapeos.ADto(a);
    }

    public async Task<AlimentoDto> CrearAsync(AlimentoRequest request, CancellationToken ct = default)
    {
        await ValidarAsync(request, null, ct);
        var a = new Alimento();
        Copiar(request, a);
        db.Alimentos.Add(a);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CREAR", "Alimento", a.Id, a.Nombre, ct: ct);
        return await ObtenerAsync(a.Id, ct);
    }

    public async Task<AlimentoDto> ActualizarAsync(int id, AlimentoRequest request, CancellationToken ct = default)
    {
        var a = await db.Alimentos.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Alimento {id} no encontrado.");
        await ValidarAsync(request, id, ct);
        Copiar(request, a);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "Alimento", id, a.Nombre, ct: ct);
        return await ObtenerAsync(id, ct);
    }

    /// <summary>Si el alimento ya fue usado se desactiva (conserva el historial); si no, se elimina.</summary>
    public async Task<string> EliminarAsync(int id, CancellationToken ct = default)
    {
        var a = await db.Alimentos.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Alimento {id} no encontrado.");
        var enUso = await db.RegistrosConsumo.AnyAsync(x => x.AlimentoId == id, ct)
                    || await db.MenuDetalles.AnyAsync(x => x.AlimentoId == id, ct)
                    || await db.RecomendacionDetalles.AnyAsync(x => x.AlimentoId == id, ct)
                    || await db.AlimentosExcluidos.AnyAsync(x => x.AlimentoId == id, ct);
        string resultado;
        if (enUso)
        {
            a.Activo = false;
            resultado = "El alimento tiene registros asociados: se desactivó para conservar el historial.";
            await db.SaveChangesAsync(ct);
            await auditoria.RegistrarAsync("DESACTIVAR", "Alimento", id, a.Nombre, ct: ct);
        }
        else
        {
            db.Alimentos.Remove(a);
            resultado = "Alimento eliminado.";
            await db.SaveChangesAsync(ct);
            await auditoria.RegistrarAsync("ELIMINAR", "Alimento", id, a.Nombre, ct: ct);
        }
        return resultado;
    }

    private async Task ValidarAsync(AlimentoRequest r, int? id, CancellationToken ct)
    {
        var nombre = r.Nombre.Trim();
        if (await db.Alimentos.AnyAsync(a => a.Nombre == nombre && a.Id != id, ct))
            throw new ReglaNegocioException($"Ya existe un alimento llamado '{nombre}'.");
        if (!await db.CategoriasAlimento.AnyAsync(c => c.Id == r.CategoriaAlimentoId, ct))
            throw new ReglaNegocioException("Categoría no válida.");
        var kcalMacros = r.Proteinas * 4 + r.Carbohidratos * 4 + r.Grasas * 9;
        if (r.Calorias > 0 && kcalMacros > r.Calorias * 1.5m + 20)
            throw new ReglaNegocioException($"Los macronutrientes suman {kcalMacros:0} kcal, muy por encima de las {r.Calorias:0} kcal indicadas. Revise los valores.");
        if (r.Azucares > r.Carbohidratos)
            throw new ReglaNegocioException("Los azúcares no pueden ser mayores que los carbohidratos.");
    }

    private static void Copiar(AlimentoRequest r, Alimento a)
    {
        a.Nombre = r.Nombre.Trim();
        a.CategoriaAlimentoId = r.CategoriaAlimentoId;
        a.PorcionDescripcion = r.PorcionDescripcion.Trim();
        a.PorcionGramos = r.PorcionGramos;
        a.Calorias = r.Calorias;
        a.Proteinas = r.Proteinas;
        a.Carbohidratos = r.Carbohidratos;
        a.Grasas = r.Grasas;
        a.Fibra = r.Fibra;
        a.Azucares = r.Azucares;
        a.SodioMg = r.SodioMg;
        a.Activo = r.Activo;
    }
}
