// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

public sealed record AlimentoDto(
    int Id, string Nombre, int CategoriaAlimentoId, string Categoria, string CategoriaCodigo, string PorcionDescripcion,
    decimal PorcionGramos, decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas,
    decimal Fibra, decimal Azucares, decimal SodioMg, bool Activo);

public sealed class AlimentoRequest
{
    [Required, MaxLength(120)] public string Nombre { get; set; } = string.Empty;
    [Required, Range(1, int.MaxValue)] public int CategoriaAlimentoId { get; set; }
    [Required, MaxLength(60)] public string PorcionDescripcion { get; set; } = string.Empty;
    [Required, Range(0.1, 5000)] public decimal PorcionGramos { get; set; }
    [Required, Range(0, 5000)] public decimal Calorias { get; set; }
    [Required, Range(0, 500)] public decimal Proteinas { get; set; }
    [Required, Range(0, 500)] public decimal Carbohidratos { get; set; }
    [Required, Range(0, 500)] public decimal Grasas { get; set; }
    [Range(0, 500)] public decimal Fibra { get; set; }
    [Range(0, 500)] public decimal Azucares { get; set; }
    [Range(0, 20000)] public decimal SodioMg { get; set; }
    public bool Activo { get; set; } = true;
}

public sealed class ItemMenuRequest
{
    [Required, Range(1, int.MaxValue)] public int TipoComidaId { get; set; }
    [Required, Range(1, int.MaxValue)] public int AlimentoId { get; set; }
    [Required, Range(0.25, 10)] public decimal Porciones { get; set; }
}

public sealed class MenuRequest
{
    [Required, MaxLength(100)] public string Nombre { get; set; } = string.Empty;
    public DateOnly? Fecha { get; set; }
    [MaxLength(300)] public string? Descripcion { get; set; }
    [Required, MinLength(1)] public List<ItemMenuRequest> Items { get; set; } = [];
}

public sealed record ItemComidaDto(int Id, int AlimentoId, string Alimento, string Categoria, string Porcion, decimal Porciones,
    decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas);

public sealed record ComidaDto(int TipoComidaId, string TipoComida, int Orden, decimal Calorias, decimal Proteinas,
    decimal Carbohidratos, decimal Grasas, IReadOnlyList<ItemComidaDto> Items);

public sealed record ResumenNutricionalDto(decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas,
    decimal PctProteina, decimal PctCarbohidratos, decimal PctGrasas, string Evaluacion);

public sealed record MenuResumenDto(int Id, string Nombre, DateOnly? Fecha, string CreadoPor, int Items, decimal Calorias);

public sealed record MenuDto(int Id, string Nombre, DateOnly? Fecha, string? Descripcion, string CreadoPor,
    DateTime FechaCreacion, IReadOnlyList<ComidaDto> Comidas, ResumenNutricionalDto Resumen);

public sealed class ResumenItemsRequest
{
    [Required, MinLength(1)] public List<ItemMenuRequest> Items { get; set; } = [];
}
