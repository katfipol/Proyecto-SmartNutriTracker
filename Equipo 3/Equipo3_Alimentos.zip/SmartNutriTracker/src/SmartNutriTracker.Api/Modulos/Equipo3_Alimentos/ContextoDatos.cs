// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 3 – Gestión de Alimentos dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<CategoriaAlimento> CategoriasAlimento => Set<CategoriaAlimento>();
    public DbSet<TipoComida> TiposComida => Set<TipoComida>();
    public DbSet<TipoComidaCategoria> TipoComidaCategorias => Set<TipoComidaCategoria>();
    public DbSet<Alimento> Alimentos => Set<Alimento>();
    public DbSet<MenuDiario> MenusDiarios => Set<MenuDiario>();
    public DbSet<MenuDetalle> MenuDetalles => Set<MenuDetalle>();

    partial void ConfigurarEquipo3(ModelBuilder mb)
    {
        mb.Entity<CategoriaAlimento>().ToTable("CategoriasAlimento");
        mb.Entity<TipoComida>(e =>
        {
            e.ToTable("TiposComida");
            e.HasMany(x => x.Categorias).WithOne(x => x.TipoComida).HasForeignKey(x => x.TipoComidaId);
        });
        mb.Entity<TipoComidaCategoria>(e =>
        {
            e.ToTable("TipoComidaCategorias");
            e.HasKey(x => new { x.TipoComidaId, x.CategoriaAlimentoId });
        });
        mb.Entity<Alimento>().ToTable("Alimentos");
        mb.Entity<MenuDiario>(e =>
        {
            e.ToTable("MenusDiarios");
            e.HasOne(x => x.CreadoPor).WithMany().HasForeignKey(x => x.CreadoPorId).OnDelete(DeleteBehavior.Restrict);
            e.HasMany(x => x.Detalles).WithOne(x => x.Menu).HasForeignKey(x => x.MenuId).OnDelete(DeleteBehavior.Cascade);
        });
        mb.Entity<MenuDetalle>().ToTable("MenuDetalles");
    }
}
