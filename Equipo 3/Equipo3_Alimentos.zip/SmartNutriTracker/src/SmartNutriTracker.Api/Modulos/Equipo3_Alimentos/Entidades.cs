// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Data.Entities;

public class CategoriaAlimento
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
}

public class TipoComida
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int Orden { get; set; }
    public decimal PorcentajeCalorias { get; set; }

    public List<TipoComidaCategoria> Categorias { get; set; } = [];
}

public class TipoComidaCategoria
{
    public int TipoComidaId { get; set; }
    public int CategoriaAlimentoId { get; set; }
    public int Orden { get; set; }

    public TipoComida? TipoComida { get; set; }
    public CategoriaAlimento? CategoriaAlimento { get; set; }
}

public class Alimento
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int CategoriaAlimentoId { get; set; }
    public string PorcionDescripcion { get; set; } = string.Empty;
    public decimal PorcionGramos { get; set; }
    public decimal Calorias { get; set; }
    public decimal Proteinas { get; set; }
    public decimal Carbohidratos { get; set; }
    public decimal Grasas { get; set; }
    public decimal Fibra { get; set; }
    public decimal Azucares { get; set; }
    public decimal SodioMg { get; set; }
    public bool Activo { get; set; } = true;

    public CategoriaAlimento? CategoriaAlimento { get; set; }
}

public class MenuDiario
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public DateOnly? Fecha { get; set; }
    public string? Descripcion { get; set; }
    public int CreadoPorId { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public Usuario? CreadoPor { get; set; }
    public List<MenuDetalle> Detalles { get; set; } = [];
}

public class MenuDetalle
{
    public int Id { get; set; }
    public int MenuId { get; set; }
    public int TipoComidaId { get; set; }
    public int AlimentoId { get; set; }
    public decimal Porciones { get; set; }

    public MenuDiario? Menu { get; set; }
    public TipoComida? TipoComida { get; set; }
    public Alimento? Alimento { get; set; }
}
