// EQUIPO 3 – Gestión de Alimentos
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 3 – HU-14 / HU-15: catálogo de alimentos.</summary>
[ApiController]
[Route("api/alimentos")]
[Authorize]
[Produces("application/json")]
public class AlimentosController(IAlimentosService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<AlimentoDto>>> Listar(
        [FromQuery] string? buscar, [FromQuery] int? categoriaId, [FromQuery] bool incluirInactivos = false, CancellationToken ct = default) =>
        Ok(await servicio.ListarAsync(buscar, categoriaId, incluirInactivos, ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<AlimentoDto>> Obtener(int id, CancellationToken ct) => Ok(await servicio.ObtenerAsync(id, ct));

    [HttpPost]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<AlimentoDto>> Crear([FromBody] AlimentoRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.CrearAsync(request, ct));

    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<AlimentoDto>> Actualizar(int id, [FromBody] AlimentoRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarAsync(id, request, ct));

    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<MensajeDto>> Eliminar(int id, CancellationToken ct) => Ok(new MensajeDto(await servicio.EliminarAsync(id, ct)));
}

/// <summary>EQUIPO 3 – HU-16 / HU-17: menús diarios y resumen nutricional.</summary>
[ApiController]
[Route("api/menus")]
[Authorize]
[Produces("application/json")]
public class MenusController(IMenusService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<MenuResumenDto>>> Listar(CancellationToken ct) => Ok(await servicio.ListarAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<MenuDto>> Obtener(int id, CancellationToken ct) => Ok(await servicio.ObtenerAsync(id, ct));

    [HttpPost]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<MenuDto>> Crear([FromBody] MenuRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.CrearAsync(request, ct));

    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<MenuDto>> Actualizar(int id, [FromBody] MenuRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarAsync(id, request, ct));

    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<IActionResult> Eliminar(int id, CancellationToken ct)
    {
        await servicio.EliminarAsync(id, ct);
        return NoContent();
    }

    /// <summary>HU-17 – Calcula el valor total de una lista de alimentos sin guardarla.</summary>
    [HttpPost("resumen")]
    public async Task<ActionResult<ResumenNutricionalDto>> Resumen([FromBody] ResumenItemsRequest request, CancellationToken ct) =>
        Ok(await servicio.ResumirAsync(request.Items, ct));
}
