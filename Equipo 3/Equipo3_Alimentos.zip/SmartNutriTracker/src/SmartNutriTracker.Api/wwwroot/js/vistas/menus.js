// HU-16 Crear menú diario · HU-17 Resumen nutricional
import { api } from '../api.js';
import { estado, esSalud } from '../estado.js';
import { esc, num, fecha, vacio, abrirModal, opciones, toast, on, confirmar, htmlComidas, htmlResumen } from '../ui.js';

export async function render(ctx) {
  const { el } = ctx;
  const menus = await api.get('/api/menus');
  const editar = esSalud();
  el.innerHTML = `
    <div class="d-flex mb-3"><div class="muted">Menús base del comedor escolar con su valor nutricional.</div>
      ${editar ? '<button class="btn btn-primary btn-sm ms-auto" data-accion="nuevo"><i class="bi bi-plus-lg me-1"></i>Nuevo menú</button>' : ''}</div>
    <div class="row g-3">${menus.length ? menus.map(m => `
      <div class="col-md-6 col-xl-4"><div class="tarjeta h-100"><div class="cuerpo pt-3">
        <div class="d-flex justify-content-between align-items-start">
          <div><h5 class="fw-bold mb-0">${esc(m.nombre)}</h5><div class="small muted">${m.fecha ? fecha(m.fecha) : 'Sin fecha'} · ${esc(m.creadoPor)}</div></div>
          <span class="badge b-verde fs-6">${num(m.calorias)} kcal</span></div>
        <div class="small muted my-2">${m.items} alimento(s)</div>
        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-outline-primary" data-accion="ver" data-id="${m.id}"><i class="bi bi-eye me-1"></i>Ver resumen</button>
          ${editar ? `<button class="btn btn-sm btn-light" data-accion="editar" data-id="${m.id}"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-light text-danger" data-accion="eliminar" data-id="${m.id}"><i class="bi bi-trash"></i></button>` : ''}
        </div></div></div></div>`).join('') : `<div class="col-12">${vacio('Aún no hay menús registrados.', 'bi-card-list')}</div>`}
    </div>`;

  const recargar = () => render(ctx);
  on(el, 'click', '[data-accion=nuevo]', () => formulario(null, recargar));
  on(el, 'click', '[data-accion=ver]', async (_, b) => {
    const m = await api.get(`/api/menus/${b.dataset.id}`);
    abrirModal({
      titulo: m.nombre, tamano: 'modal-lg',
      cuerpo: `<div class="row g-3"><div class="col-md-7">${htmlComidas(m.comidas)}</div>
        <div class="col-md-5"><div class="tarjeta p-3">${htmlResumen(m.resumen)}</div>
        ${m.descripcion ? `<p class="small muted mt-3">${esc(m.descripcion)}</p>` : ''}</div></div>`
    });
  });
  on(el, 'click', '[data-accion=editar]', async (_, b) => formulario(await api.get(`/api/menus/${b.dataset.id}`), recargar));
  on(el, 'click', '[data-accion=eliminar]', async (_, b) => {
    if (!await confirmar('¿Eliminar este menú?', 'Eliminar')) return;
    await api.del(`/api/menus/${b.dataset.id}`);
    toast('Menú eliminado.');
    recargar();
  });
}

async function formulario(m, recargar) {
  const alimentos = await api.get('/api/alimentos');
  const tipos = estado.catalogos.tiposComida;
  const items = m ? m.comidas.flatMap(c => c.items.map(i => ({ tipoComidaId: c.tipoComidaId, alimentoId: i.alimentoId, porciones: i.porciones })))
                  : [{ tipoComidaId: tipos[0].id, alimentoId: alimentos[0]?.id, porciones: 1 }];
  const fila = (i) => `<tr>
    <td><select class="form-select form-select-sm" data-campo="tipoComidaId">${opciones(tipos, i.tipoComidaId)}</select></td>
    <td><select class="form-select form-select-sm" data-campo="alimentoId">${opciones(alimentos, i.alimentoId)}</select></td>
    <td style="width:110px"><input type="number" step="0.25" min="0.25" max="10" class="form-control form-control-sm" data-campo="porciones" value="${i.porciones}"></td>
    <td><button type="button" class="btn btn-sm btn-light text-danger" data-accion="quitar"><i class="bi bi-x-lg"></i></button></td></tr>`;

  const modal = abrirModal({
    titulo: m ? `Editar menú: ${m.nombre}` : 'Nuevo menú diario', tamano: 'modal-xl',
    cuerpo: `<div class="row g-3">
      <div class="col-lg-8">
        <div class="row g-2 mb-3">
          <div class="col-md-6"><label class="form-label">Nombre</label><input class="form-control" id="m-nombre" required maxlength="100" value="${esc(m?.nombre)}"></div>
          <div class="col-md-6"><label class="form-label">Fecha (opcional)</label><input type="date" class="form-control" id="m-fecha" value="${esc(m?.fecha ?? '')}"></div>
          <div class="col-12"><label class="form-label">Descripción</label><input class="form-control" id="m-desc" maxlength="300" value="${esc(m?.descripcion ?? '')}"></div>
        </div>
        <table class="table table-sm"><thead><tr><th>Comida</th><th>Alimento</th><th>Porciones</th><th></th></tr></thead>
          <tbody id="m-items">${items.map(fila).join('')}</tbody></table>
        <button type="button" class="btn btn-sm btn-outline-primary" data-accion="agregar"><i class="bi bi-plus-lg me-1"></i>Agregar alimento</button>
      </div>
      <div class="col-lg-4"><div class="tarjeta p-3 position-sticky" style="top:0"><div class="fw-bold mb-2">Resumen nutricional</div><div id="m-resumen" class="small muted">Calculando...</div></div></div>
    </div>`,
    alGuardar: async () => {
      const datos = {
        nombre: modal.querySelector('#m-nombre').value.trim(),
        fecha: modal.querySelector('#m-fecha').value || null,
        descripcion: modal.querySelector('#m-desc').value.trim() || null,
        items: leerItems()
      };
      if (m) await api.put(`/api/menus/${m.id}`, datos); else await api.post('/api/menus', datos);
      toast(m ? 'Menú actualizado.' : 'Menú creado.');
      recargar();
    }
  });

  const cuerpoTabla = modal.querySelector('#m-items');
  function leerItems() {
    return [...cuerpoTabla.querySelectorAll('tr')].map(tr => ({
      tipoComidaId: parseInt(tr.querySelector('[data-campo=tipoComidaId]').value, 10),
      alimentoId: parseInt(tr.querySelector('[data-campo=alimentoId]').value, 10),
      porciones: parseFloat(tr.querySelector('[data-campo=porciones]').value) || 0
    })).filter(i => i.porciones > 0);
  }
  let t;
  async function resumir() {
    const lista = leerItems();
    const destino = modal.querySelector('#m-resumen');
    if (!lista.length) { destino.innerHTML = 'Agregue alimentos.'; return; }
    try { destino.className = ''; destino.innerHTML = htmlResumen(await api.post('/api/menus/resumen', { items: lista })); }
    catch (e) { destino.textContent = e.message; }
  }
  const programar = () => { clearTimeout(t); t = setTimeout(resumir, 250); };
  on(modal, 'click', '[data-accion=agregar]', () => { cuerpoTabla.insertAdjacentHTML('beforeend', fila({ tipoComidaId: tipos[0].id, alimentoId: alimentos[0]?.id, porciones: 1 })); programar(); });
  on(modal, 'click', '[data-accion=quitar]', (_, b) => { b.closest('tr').remove(); programar(); });
  cuerpoTabla.addEventListener('change', programar);
  cuerpoTabla.addEventListener('input', programar);
  resumir();
}
