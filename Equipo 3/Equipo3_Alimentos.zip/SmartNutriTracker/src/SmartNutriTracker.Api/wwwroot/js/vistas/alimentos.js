// HU-14 / HU-15 – Catálogo de alimentos
import { api, conParametros } from '../api.js';
import { estado, esSalud } from '../estado.js';
import { esc, num, vacio, abrirModal, leerFormulario, opciones, toast, on, confirmar } from '../ui.js';

let filtros = { buscar: '', categoriaId: '', incluirInactivos: false };

export async function render({ el }) {
  const editar = esSalud();
  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2">
        <h3><i class="bi bi-basket me-1"></i>Catálogo de alimentos</h3>
        <div class="ms-auto d-flex flex-wrap gap-2">
          <input class="form-control form-control-sm" style="width:220px" placeholder="Buscar alimento..." id="f-buscar" value="${esc(filtros.buscar)}">
          <select class="form-select form-select-sm" style="width:220px" id="f-cat">${opciones(estado.catalogos.categoriasAlimento, filtros.categoriaId, { vacioTexto: 'Todas las categorías' })}</select>
          ${editar ? `<div class="form-check form-switch align-self-center small"><input class="form-check-input" type="checkbox" id="f-inactivos" ${filtros.incluirInactivos ? 'checked' : ''}>
            <label class="form-check-label" for="f-inactivos">Inactivos</label></div>
            <button class="btn btn-primary btn-sm" data-accion="nuevo"><i class="bi bi-plus-lg me-1"></i>Nuevo alimento</button>` : ''}
        </div>
      </div>
      <div class="cuerpo p-0" id="tabla"></div>
    </div>`;

  const cargar = async () => {
    const lista = await api.get(conParametros('/api/alimentos', filtros));
    el.querySelector('#tabla').innerHTML = lista.length ? `
      <div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Alimento</th><th>Categoría</th><th>Porción</th><th class="text-end">Kcal</th><th class="text-end">Prot.</th>
          <th class="text-end">Carb.</th><th class="text-end">Grasas</th><th class="text-end">Azúcar</th><th class="text-end">Sodio</th>${editar ? '<th></th>' : ''}</tr></thead>
        <tbody>${lista.map(a => `<tr class="${a.activo ? '' : 'opacity-50'}">
          <td class="fw-semibold">${esc(a.nombre)} ${a.activo ? '' : '<span class="badge b-gris">Inactivo</span>'}</td>
          <td><span class="badge b-verde">${esc(a.categoria)}</span></td>
          <td class="small">${esc(a.porcionDescripcion)}</td>
          <td class="text-end fw-semibold">${num(a.calorias)}</td><td class="text-end">${num(a.proteinas, 1)} g</td>
          <td class="text-end">${num(a.carbohidratos, 1)} g</td><td class="text-end">${num(a.grasas, 1)} g</td>
          <td class="text-end ${a.azucares > 25 ? 'text-danger fw-semibold' : ''}">${num(a.azucares, 1)} g</td>
          <td class="text-end ${a.sodioMg > 500 ? 'text-danger fw-semibold' : ''}">${num(a.sodioMg)} mg</td>
          ${editar ? `<td class="text-end text-nowrap">
            <button class="btn btn-sm btn-light" data-accion="editar" data-id="${a.id}" title="Editar"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-light text-danger" data-accion="eliminar" data-id="${a.id}" data-nombre="${esc(a.nombre)}" title="Eliminar"><i class="bi bi-trash"></i></button></td>` : ''}
        </tr>`).join('')}</tbody></table></div>
      <div class="p-2 small muted text-end">${lista.length} alimento(s) · valores por porción</div>` : vacio('No se encontraron alimentos.', 'bi-basket');
  };

  let t;
  el.querySelector('#f-buscar').addEventListener('input', (ev) => { clearTimeout(t); t = setTimeout(() => { filtros.buscar = ev.target.value; cargar(); }, 300); });
  el.querySelector('#f-cat').addEventListener('change', (ev) => { filtros.categoriaId = ev.target.value; cargar(); });
  el.querySelector('#f-inactivos')?.addEventListener('change', (ev) => { filtros.incluirInactivos = ev.target.checked; cargar(); });
  on(el, 'click', '[data-accion=nuevo]', () => formulario(null, cargar));
  on(el, 'click', '[data-accion=editar]', async (_, b) => formulario(await api.get(`/api/alimentos/${b.dataset.id}`), cargar));
  on(el, 'click', '[data-accion=eliminar]', async (_, b) => {
    if (!await confirmar(`¿Eliminar "${b.dataset.nombre}"? Si ya fue usado se desactivará.`, 'Eliminar')) return;
    try {
      const r = await api.del(`/api/alimentos/${b.dataset.id}`);
      toast(r.mensaje);
      cargar();
    } catch (e) { toast(e.message, 'error'); }
  });
  await cargar();
}

function formulario(a, recargar) {
  const campo = (nombre, etiqueta, valor, extra = '') =>
    `<div class="col-6 col-md-3"><label class="form-label">${etiqueta}</label><input type="number" step="0.1" min="0" class="form-control" name="${nombre}" data-tipo="num" value="${valor ?? 0}" ${extra}></div>`;
  abrirModal({
    titulo: a ? `Editar: ${a.nombre}` : 'Nuevo alimento', tamano: 'modal-lg',
    cuerpo: `<div class="row g-3">
      <div class="col-md-6"><label class="form-label">Nombre</label><input class="form-control" name="nombre" required maxlength="120" value="${esc(a?.nombre)}"></div>
      <div class="col-md-6"><label class="form-label">Categoría</label><select class="form-select" name="categoriaAlimentoId" data-tipo="int">${opciones(estado.catalogos.categoriasAlimento, a?.categoriaAlimentoId)}</select></div>
      <div class="col-md-8"><label class="form-label">Porción</label><input class="form-control" name="porcionDescripcion" required maxlength="60" placeholder="1 taza (240 ml)" value="${esc(a?.porcionDescripcion)}"></div>
      <div class="col-md-4"><label class="form-label">Gramos por porción</label><input type="number" step="0.1" min="0.1" class="form-control" name="porcionGramos" data-tipo="num" required value="${a?.porcionGramos ?? ''}"></div>
      ${campo('calorias', 'Calorías (kcal)', a?.calorias, 'required')}
      ${campo('proteinas', 'Proteínas (g)', a?.proteinas, 'required')}
      ${campo('carbohidratos', 'Carbohidratos (g)', a?.carbohidratos, 'required')}
      ${campo('grasas', 'Grasas (g)', a?.grasas, 'required')}
      ${campo('fibra', 'Fibra (g)', a?.fibra)}
      ${campo('azucares', 'Azúcares (g)', a?.azucares)}
      ${campo('sodioMg', 'Sodio (mg)', a?.sodioMg)}
      <div class="col-6 col-md-3 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="al-activo" ${a?.activo === false ? '' : 'checked'}>
        <label class="form-check-label" for="al-activo">Activo</label></div></div>
    </div>`,
    alGuardar: async (form) => {
      const datos = leerFormulario(form);
      if (a) await api.put(`/api/alimentos/${a.id}`, datos); else await api.post('/api/alimentos', datos);
      toast(a ? 'Alimento actualizado.' : 'Alimento registrado.');
      recargar();
    }
  });
}
