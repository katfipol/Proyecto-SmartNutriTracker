# SmartNutriTracker · Equipo 2 – Perfil y Reportes

**Historias de usuario:** HU-08 a HU-12  
**Proyecto:** SmartNutriTracker – Colegio "Innovare" · Programación Web III  
**Tecnologías:** .NET 10 · ASP.NET Core Web API · Entity Framework Core 10 · SQL Server · HTML + JS + Bootstrap 5

Este ZIP contiene **solo la parte del Equipo 2**, con las mismas rutas del proyecto completo.
Para tener el sistema funcionando, **descomprima los 6 ZIP en la misma carpeta**: los archivos no se pisan.

---

## 1. Historias de usuario implementadas

| HU | Descripción | Implementación |
|---|---|---|
| HU-08 | Registro de estudiantes | `EstudiantesService.CrearAsync` (opcionalmente crea su cuenta) · `POST /api/estudiantes` |
| HU-09 | Ver perfil, IMC y objetivos | `GET /api/estudiantes/{id}` y `/mi-perfil`, con cálculo nutricional y evolución de peso |
| HU-10 | Editar datos físicos y objetivos | `PUT /api/estudiantes/{id}/datos-fisicos`: guarda la medición y reevalúa el IMC |
| HU-11 | Reporte nutricional semanal | `ReportesService.SemanalAsync`: 7 días, promedios, % de cumplimiento y conclusiones |
| HU-12 | Dashboard general | `ReportesService.DashboardAsync`: KPIs, estudiantes por IMC, alertas y citas |

### Reglas de negocio
- La edad del estudiante debe estar entre 5 y 25 años.
- Un docente solo puede registrar estudiantes en sus propios cursos.
- Cada cambio de peso o talla queda en `MedicionesEstudiante` (una medición por día).
- Desactivar un estudiante también desactiva su cuenta de acceso.

## 2. Base de datos

**Script del equipo:** `database/por_equipo/2_Equipo2_PerfilReportes.sql`

Orden de ejecución en SSMS (base nueva): **Equipo 1 → 2 → 3 → 4 → 5 → 6**.
- El script del Equipo 1 crea la base desde cero.
- Cada script comprueba que ya se ejecutaron los anteriores.

### Tablas del equipo
- `NivelesActividad`
- `Cursos`
- `Estudiantes`
- `MedicionesEstudiante`

### Normalización (3FN)
- `Estudiantes.NivelActividadId` es una FK: el factor de actividad vive solo en `NivelesActividad`, sin dependencia transitiva.
- `Estudiantes.CursoId` es una FK, y el docente está en `Cursos.DocenteId`.
- El **IMC y la edad no se guardan**: se calculan a partir de peso, talla y fecha de nacimiento.
- El historial de peso está en una tabla aparte (`MedicionesEstudiante`), no en columnas repetidas (1FN).
- `Estudiantes.ObjetivoId` se relaciona con `ObjetivosNutricionales` (Equipo 5). La FK la agrega el script del Equipo 5.

## 3. API REST (endpoints del equipo)

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/api/estudiantes` | Admin, Docente, Nutricionista | Listar |
| GET | `/api/estudiantes/mi-perfil` | Estudiante | HU-09 – Perfil del estudiante autenticado. |
| GET | `/api/estudiantes/{id}` | Cualquier usuario autenticado | Perfil |
| POST | `/api/estudiantes` | Admin, Docente, Nutricionista | HU-08 – Registrar estudiante (opcionalmente con su cuenta de acceso). |
| PUT | `/api/estudiantes/{id}` | Admin, Docente, Nutricionista | Actualizar |
| PUT | `/api/estudiantes/{id}/datos-fisicos` | Cualquier usuario autenticado | HU-10 – Actualizar datos físicos y objetivo. |
| PUT | `/api/estudiantes/{id}/excluidos` | Cualquier usuario autenticado | HU-25 – Alimentos que el estudiante no consume (alergias, gustos). |
| DELETE | `/api/estudiantes/{id}` | Admin | Desactivar (borrado lógico) |
| GET | `/api/reportes/estudiante/{estudianteId}/semanal` | Cualquier usuario autenticado | HU-11 – Reporte de los 7 días que terminan en 'hasta' (por defecto hoy). |
| GET | `/api/reportes/dashboard` | Admin, Docente, Nutricionista | HU-12 – Dashboard general (personal del colegio). |
| GET | `/api/reportes/mi-resumen` | Estudiante | Resumen del día para el estudiante autenticado. |

Todas las rutas (salvo el login) requieren el encabezado `Authorization: Bearer <token>`.
Para probarlas en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 4. Frontend (pantallas del equipo)
- Inicio: dashboard del personal y resumen del día del estudiante (`vistas/inicio.js`)
- Estudiantes: listado, registro y edición (`vistas/estudiantes.js`)
- Perfil del estudiante / Mi perfil (`vistas/perfil.js`)
- Reporte semanal con gráficos (`vistas/reportes.js`)

## 5. Archivos del equipo

**Backend**
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/ContextoDatos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/Entidades.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/Servicios/EstudiantesService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo2_PerfilReportes/Servicios/ReportesService.cs`

**Frontend**
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/estudiantes.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/inicio.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/perfil.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/reportes.js`

**Base de datos**
- `database/por_equipo/2_Equipo2_PerfilReportes.sql`

## 6. Dependencias con otros equipos
Equipo 1 (usuarios y base). Usa el cálculo nutricional del Equipo 5, las alertas de IMC del Equipo 6 y los registros del Equipo 4 para los reportes.

La integración se hace así:
- **Clase parcial `SmartNutriDbContext`:** cada equipo aporta sus `DbSet` y su configuración en `ContextoDatos.cs`, mediante el método `ConfigurarEquipo2`.
- **Clase parcial `Mapeos`:** cada equipo aporta sus conversiones a DTO.
- **Inyección de dependencias:** los servicios se registran en `Program.cs`, que entrega el Equipo 1.

## 7. Cómo ejecutar el sistema completo
1. Descomprima los 6 ZIP en la misma carpeta (por ejemplo `SmartNutriTracker/`).
2. Ejecute en SSMS los scripts `database/por_equipo/1_…sql` a `6_…sql`, en orden.
3. Ajuste la cadena de conexión en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
4. En la carpeta raíz, ejecute:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
5. Abra http://localhost:5200 para el sistema y http://localhost:5200/swagger para la API.

**Usuarios de prueba** (contraseña `Innovare2026!`):

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |
