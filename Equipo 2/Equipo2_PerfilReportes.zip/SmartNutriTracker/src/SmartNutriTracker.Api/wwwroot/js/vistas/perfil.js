// HU-09 Ver perfil · HU-10 Editar datos físicos y objetivo · HU-25 alimentos excluidos
import { api } from '../api.js';
import { estado, esPersonal, recordarEstudiante } from '../estado.js';
import { esc, num, badgeImc, fecha, grafico, abrirModal, leerFormulario, opciones, toast, on } from '../ui.js';
import { formulario } from './estudiantes.js';

export async function render(ctx) {
  const { el, id, titulo } = ctx;
  const p = id ? await api.get(`/api/estudiantes/${id}`) : await api.get('/api/estudiantes/mi-perfil');
  if (id) { titulo(`Perfil · ${p.nombreCompleto}`); recordarEstudiante(p.id); }
  const c = p.calculo;

  el.innerHTML = `
    <div class="d-flex flex-wrap gap-2 mb-3">
      ${id ? '<a href="#/estudiantes" class="btn btn-sm btn-light"><i class="bi bi-arrow-left me-1"></i>Estudiantes</a>' : ''}
      <div class="ms-auto d-flex flex-wrap gap-2">
        <button class="btn btn-sm btn-primary" data-accion="fisicos"><i class="bi bi-rulers me-1"></i>Actualizar peso, talla y objetivo</button>
        <button class="btn btn-sm btn-outline-primary" data-accion="excluidos"><i class="bi bi-slash-circle me-1"></i>Alimentos que no consume</button>
        ${id && esPersonal() ? '<button class="btn btn-sm btn-light" data-accion="editar"><i class="bi bi-pencil me-1"></i>Editar datos</button>' : ''}
        ${id ? `<a class="btn btn-sm btn-light" href="#/registro?estudiante=${p.id}"><i class="bi bi-journal-check me-1"></i>Registro</a>
                <a class="btn btn-sm btn-light" href="#/reportes?estudiante=${p.id}"><i class="bi bi-graph-up me-1"></i>Reporte</a>
                <a class="btn btn-sm btn-light" href="#/recomendaciones?estudiante=${p.id}"><i class="bi bi-stars me-1"></i>Recomendación</a>` : ''}
      </div>
    </div>

    <div class="row g-3">
      <div class="col-xl-4">
        <div class="tarjeta mb-3"><div class="cuerpo pt-4 text-center">
          <div class="avatar mx-auto mb-2" style="width:72px;height:72px;font-size:1.5rem">${esc(p.nombres[0])}${esc(p.apellidos[0])}</div>
          <h4 class="fw-bold mb-0">${esc(p.nombreCompleto)}</h4>
          <div class="muted">${esc(p.curso)} · ${p.edad} años · ${p.sexo === 'F' ? 'Femenino' : 'Masculino'}</div>
          ${p.correo ? `<div class="small mt-1"><i class="bi bi-envelope"></i> ${esc(p.correo)}</div>` : ''}
          ${!p.activo ? '<span class="badge b-coral mt-2">Inactivo</span>' : ''}
          <hr>
          <div class="row g-2 text-center">
            <div class="col-4"><div class="muted small">Peso</div><div class="fw-bold">${num(p.pesoKg, 1)} kg</div></div>
            <div class="col-4"><div class="muted small">Talla</div><div class="fw-bold">${num(p.alturaCm)} cm</div></div>
            <div class="col-4"><div class="muted small">IMC</div><div class="fw-bold">${num(c.imc, 1)}</div></div>
          </div>
          <div class="mt-2">${badgeImc(c.categoriaImc)}</div>
          <div class="text-start small mt-3">
            <div class="d-flex justify-content-between py-1 border-bottom"><span class="muted">Nacimiento</span><span>${fecha(p.fechaNacimiento)}</span></div>
            <div class="d-flex justify-content-between py-1 border-bottom"><span class="muted">Actividad</span><span>${esc(p.nivelActividad)}</span></div>
            <div class="d-flex justify-content-between py-1"><span class="muted">Objetivo</span><span class="fw-semibold">${esc(p.objetivo)}</span></div>
          </div>
        </div></div>

        <div class="tarjeta"><div class="cabecera"><i class="bi bi-slash-circle" style="color:var(--snt-coral)"></i><h3>No consume</h3></div>
          <div class="cuerpo">${p.alimentosExcluidos.length ? p.alimentosExcluidos.map(x =>
            `<span class="badge b-coral me-1 mb-1">${esc(x.alimento)}${x.motivo ? ` · ${esc(x.motivo)}` : ''}</span>`).join('')
            : '<span class="muted small">Sin restricciones registradas.</span>'}</div></div>
      </div>

      <div class="col-xl-8">
        <div class="tarjeta mb-3"><div class="cabecera"><i class="bi bi-calculator" style="color:var(--snt-700)"></i><h3>Requerimientos nutricionales (cálculo automático)</h3></div>
          <div class="cuerpo">
            <div class="row g-3 text-center mb-3">
              <div class="col-6 col-md-3"><div class="p-3 rounded-3" style="background:var(--snt-50)"><div class="muted small">Metabolismo basal</div><div class="fs-5 fw-bold">${num(c.tmb)} kcal</div></div></div>
              <div class="col-6 col-md-3"><div class="p-3 rounded-3" style="background:var(--snt-50)"><div class="muted small">Gasto energético</div><div class="fs-5 fw-bold">${num(c.gastoEnergeticoTotal)} kcal</div></div></div>
              <div class="col-6 col-md-3"><div class="p-3 rounded-3" style="background:var(--snt-100)"><div class="muted small">Objetivo diario</div><div class="fs-5 fw-bold" style="color:var(--snt-900)">${num(c.caloriasObjetivo)} kcal</div></div></div>
              <div class="col-6 col-md-3"><div class="p-3 rounded-3" style="background:var(--snt-50)"><div class="muted small">Objetivo aplicado</div><div class="fs-5 fw-bold">${esc(c.objetivoAplicado)}</div></div></div>
            </div>
            <div class="row g-3 align-items-center">
              <div class="col-md-5"><div class="chart-box" style="height:200px"><canvas id="g-macros"></canvas></div></div>
              <div class="col-md-7">
                <div class="d-flex justify-content-between py-1 border-bottom"><span>Proteínas</span><strong>${num(c.proteinasG, 1)} g</strong></div>
                <div class="d-flex justify-content-between py-1 border-bottom"><span>Carbohidratos</span><strong>${num(c.carbohidratosG, 1)} g</strong></div>
                <div class="d-flex justify-content-between py-1 mb-2"><span>Grasas</span><strong>${num(c.grasasG, 1)} g</strong></div>
                ${c.observaciones.map(o => `<div class="observacion">${esc(o)}</div>`).join('')}
              </div>
            </div>
          </div></div>

        <div class="tarjeta"><div class="cabecera"><i class="bi bi-activity" style="color:var(--snt-700)"></i><h3>Evolución de peso e IMC</h3></div>
          <div class="cuerpo"><div class="chart-box"><canvas id="g-mediciones"></canvas></div></div></div>
      </div>
    </div>`;

  grafico(el.querySelector('#g-macros'), {
    type: 'doughnut',
    data: { labels: ['Proteínas', 'Carbohidratos', 'Grasas'],
      datasets: [{ data: [c.proteinasG * 4, c.carbohidratosG * 4, c.grasasG * 9].map(Math.round), backgroundColor: ['#2d6a4f', '#a7c957', '#e9c46a'] }] },
    options: { cutout: '60%', plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: (t) => ` ${t.label}: ${t.raw} kcal` } } } }
  });
  grafico(el.querySelector('#g-mediciones'), {
    type: 'line',
    data: {
      labels: p.mediciones.map(m => fecha(m.fecha)),
      datasets: [
        { label: 'Peso (kg)', data: p.mediciones.map(m => m.pesoKg), borderColor: '#2d6a4f', backgroundColor: 'rgba(82,183,136,.15)', fill: true, tension: .3, yAxisID: 'y' },
        { label: 'IMC', data: p.mediciones.map(m => m.imc), borderColor: '#a7c957', tension: .3, yAxisID: 'y2' }
      ]
    },
    options: { scales: { y2: { position: 'right', grid: { drawOnChartArea: false } } } }
  });

  const recargar = () => render(ctx);
  on(el, 'click', '[data-accion=fisicos]', () => modalFisicos(p, recargar));
  on(el, 'click', '[data-accion=excluidos]', () => modalExcluidos(p, recargar));
  on(el, 'click', '[data-accion=editar]', () => formulario(p, recargar));
}

function modalFisicos(p, recargar) {
  const cat = estado.catalogos;
  abrirModal({
    titulo: 'Actualizar datos físicos y objetivo',
    cuerpo: `<div class="row g-3">
      <div class="col-6"><label class="form-label">Peso (kg)</label><input type="number" step="0.1" min="10" max="300" class="form-control" name="pesoKg" data-tipo="num" required value="${p.pesoKg}"></div>
      <div class="col-6"><label class="form-label">Talla (cm)</label><input type="number" step="0.1" min="80" max="230" class="form-control" name="alturaCm" data-tipo="num" required value="${p.alturaCm}"></div>
      <div class="col-12"><label class="form-label">Nivel de actividad física</label><select class="form-select" name="nivelActividadId" data-tipo="int">${opciones(cat.nivelesActividad, p.nivelActividadId)}</select></div>
      <div class="col-12"><label class="form-label">Mi objetivo</label><select class="form-select" name="objetivoId" data-tipo="int">${opciones(cat.objetivos, p.objetivoId)}</select>
        <div class="form-text">Si el objetivo no es adecuado para tu IMC, el sistema aplicará el recomendado.</div></div>
    </div>`,
    alGuardar: async (form) => {
      await api.put(`/api/estudiantes/${p.id}/datos-fisicos`, leerFormulario(form));
      toast('Datos actualizados. Se recalcularon tus requerimientos.');
      recargar();
    }
  });
}

async function modalExcluidos(p, recargar) {
  const alimentos = await api.get('/api/alimentos');
  const excluidos = new Map(p.alimentosExcluidos.map(x => [x.alimentoId, x.motivo]));
  abrirModal({
    titulo: 'Alimentos que no consume', tamano: 'modal-lg',
    cuerpo: `<p class="small muted">Marca los alimentos que no deben aparecer en tus recomendaciones (alergias, intolerancias o preferencias).</p>
      <input class="form-control form-control-sm mb-2" placeholder="Filtrar..." id="filtro-exc">
      <div style="max-height:380px;overflow:auto" id="lista-exc">${alimentos.map(a => `
        <div class="d-flex align-items-center gap-2 py-1 border-bottom fila-exc" data-nombre="${esc(a.nombre.toLowerCase())}">
          <input class="form-check-input mt-0" type="checkbox" value="${a.id}" id="exc-${a.id}" ${excluidos.has(a.id) ? 'checked' : ''}>
          <label class="form-check-label flex-grow-1" for="exc-${a.id}">${esc(a.nombre)} <span class="small muted">· ${esc(a.categoria)}</span></label>
          <input class="form-control form-control-sm" style="width:170px" placeholder="Motivo" maxlength="150" data-motivo="${a.id}" value="${esc(excluidos.get(a.id) ?? '')}">
        </div>`).join('')}</div>`,
    alGuardar: async (form) => {
      const lista = [...form.querySelectorAll('#lista-exc input[type=checkbox]:checked')].map(chk => ({
        alimentoId: parseInt(chk.value, 10),
        motivo: form.querySelector(`[data-motivo="${chk.value}"]`).value.trim() || null
      }));
      await api.put(`/api/estudiantes/${p.id}/excluidos`, lista);
      toast('Preferencias guardadas.');
      recargar();
    }
  }).querySelector('#filtro-exc').addEventListener('input', (ev) => {
    const t = ev.target.value.toLowerCase();
    document.querySelectorAll('.fila-exc').forEach(f => f.classList.toggle('d-none', !f.dataset.nombre.includes(t)));
  });
}
