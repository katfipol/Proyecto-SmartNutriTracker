// HU-11 – Reporte nutricional semanal
import { api, conParametros } from '../api.js';
import { cargarEstudiantes, estudianteSeleccionado, htmlSelectorEstudiante, engancharSelector } from '../estado.js';
import { esc, num, fecha, fechaCorta, hoyIso, kpi, grafico, badgeImc, vacio } from '../ui.js';

let hasta = null;

export async function render(ctx) {
  const { el, params } = ctx;
  await cargarEstudiantes();
  const id = estudianteSeleccionado(params);
  if (!id) { el.innerHTML = vacio('No hay estudiantes disponibles.', 'bi-people'); return; }
  hasta ??= hoyIso();
  const r = await api.get(conParametros(`/api/reportes/estudiante/${id}/semanal`, { hasta }));

  el.innerHTML = `
    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
      ${htmlSelectorEstudiante(id)}
      <div class="ms-auto d-flex gap-2 align-items-center">
        <label class="form-label mb-0 small" for="f-hasta">Semana que termina el</label>
        <input type="date" class="form-control form-control-sm" id="f-hasta" value="${hasta}" max="${hoyIso()}" style="width:160px">
        <button class="btn btn-sm btn-outline-primary" data-accion="imprimir"><i class="bi bi-printer me-1"></i>Imprimir</button>
      </div>
    </div>

    <div class="tarjeta mb-3 p-3 d-flex flex-wrap gap-3 align-items-center">
      <div><div class="fw-bold fs-5">${esc(r.estudiante)}</div><div class="muted small">${esc(r.curso)} · ${fecha(r.desde)} al ${fecha(r.hasta)}</div></div>
      <div class="ms-auto">IMC <strong>${num(r.imc, 1)}</strong> ${badgeImc(r.categoriaImc)} · Objetivo <strong>${num(r.caloriasObjetivo)} kcal/día</strong></div>
    </div>

    <div class="row g-3 mb-3">
      <div class="col-6 col-xl-2">${kpi('bi-fire', 'ic-verde', num(r.promedioCalorias), 'kcal/día promedio')}</div>
      <div class="col-6 col-xl-2">${kpi('bi-bullseye', 'ic-lima', num(r.porcentajeCumplimiento) + '%', 'del objetivo calórico')}</div>
      <div class="col-6 col-xl-2">${kpi('bi-droplet', 'ic-lima', num(r.promedioAguaMl), 'ml de agua/día')}</div>
      <div class="col-6 col-xl-2">${kpi('bi-moon-stars', 'ic-ambar', num(r.promedioSueno, 1) + ' h', 'sueño promedio')}</div>
      <div class="col-6 col-xl-2">${kpi('bi-bicycle', 'ic-verde', num(r.promedioActividad), 'min actividad/día')}</div>
      <div class="col-6 col-xl-2">${kpi('bi-exclamation-triangle', 'ic-coral', r.alertasSemana, 'alertas en la semana')}</div>
    </div>

    <div class="row g-3 mb-3">
      <div class="col-xl-8"><div class="tarjeta h-100"><div class="cabecera"><h3>Calorías y macronutrientes por día</h3></div>
        <div class="cuerpo"><div class="chart-box"><canvas id="g-kcal"></canvas></div></div></div></div>
      <div class="col-xl-4"><div class="tarjeta h-100"><div class="cabecera"><h3><i class="bi bi-clipboard2-pulse me-1"></i>Conclusiones</h3></div>
        <div class="cuerpo">${r.conclusiones.map(c => `<div class="observacion ${/adecuado|Sin observaciones/.test(c) ? '' : 'alerta'}">${esc(c)}</div>`).join('')}
        <div class="small muted mt-2">Días con registro: ${r.diasConRegistro} de 7</div></div></div></div>
    </div>

    <div class="row g-3">
      <div class="col-xl-6"><div class="tarjeta"><div class="cabecera"><h3>Hábitos</h3></div>
        <div class="cuerpo"><div class="chart-box"><canvas id="g-habitos"></canvas></div></div></div></div>
      <div class="col-xl-6"><div class="tarjeta"><div class="cabecera"><h3>Detalle diario</h3></div>
        <div class="cuerpo p-0"><div class="table-responsive"><table class="table table-sm">
          <thead><tr><th>Día</th><th class="text-end">Kcal</th><th class="text-end">Azúcar</th><th class="text-end">Sodio</th><th class="text-end">Sueño</th><th class="text-end">Agua</th><th class="text-end">Act.</th></tr></thead>
          <tbody>${r.dias.map(d => `<tr><td>${fecha(d.fecha, true)}</td>
            <td class="text-end">${d.calorias ? num(d.calorias) : '—'}</td><td class="text-end">${d.calorias ? num(d.azucares, 1) + ' g' : '—'}</td>
            <td class="text-end">${d.calorias ? num(d.sodioMg) + ' mg' : '—'}</td><td class="text-end">${d.horasSueno != null ? num(d.horasSueno, 1) + ' h' : '—'}</td>
            <td class="text-end">${d.aguaMl != null ? num(d.aguaMl) + ' ml' : '—'}</td><td class="text-end">${d.minutosActividad != null ? d.minutosActividad + "'" : '—'}</td></tr>`).join('')}
          </tbody></table></div></div></div></div>
    </div>`;

  const etiquetas = r.dias.map(d => fechaCorta(d.fecha));
  grafico(el.querySelector('#g-kcal'), {
    data: {
      labels: etiquetas,
      datasets: [
        { type: 'bar', label: 'Proteínas (kcal)', data: r.dias.map(d => Math.round(d.proteinas * 4)), backgroundColor: '#2d6a4f', stack: 'm', borderRadius: 4 },
        { type: 'bar', label: 'Carbohidratos (kcal)', data: r.dias.map(d => Math.round(d.carbohidratos * 4)), backgroundColor: '#a7c957', stack: 'm', borderRadius: 4 },
        { type: 'bar', label: 'Grasas (kcal)', data: r.dias.map(d => Math.round(d.grasas * 9)), backgroundColor: '#e9c46a', stack: 'm', borderRadius: 4 },
        { type: 'line', label: 'Objetivo', data: r.dias.map(() => r.caloriasObjetivo), borderColor: '#1b4332', borderDash: [6, 4], pointRadius: 0 }
      ]
    },
    options: { scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true } } }
  });
  grafico(el.querySelector('#g-habitos'), {
    type: 'line',
    data: {
      labels: etiquetas,
      datasets: [
        { label: 'Agua (ml)', data: r.dias.map(d => d.aguaMl), borderColor: '#52b788', backgroundColor: 'rgba(82,183,136,.15)', fill: true, tension: .3, yAxisID: 'y' },
        { label: 'Sueño (h)', data: r.dias.map(d => d.horasSueno), borderColor: '#1b4332', tension: .3, yAxisID: 'y2' },
        { label: 'Actividad (min)', data: r.dias.map(d => d.minutosActividad), borderColor: '#e9c46a', tension: .3, yAxisID: 'y2' }
      ]
    },
    options: { spanGaps: true, scales: { y: { beginAtZero: true }, y2: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } } } }
  });

  engancharSelector(el, () => render(ctx));
  el.querySelector('#f-hasta').addEventListener('change', (ev) => { if (ev.target.value) { hasta = ev.target.value; render(ctx); } });
  el.querySelector('[data-accion=imprimir]').addEventListener('click', () => window.print());
}
