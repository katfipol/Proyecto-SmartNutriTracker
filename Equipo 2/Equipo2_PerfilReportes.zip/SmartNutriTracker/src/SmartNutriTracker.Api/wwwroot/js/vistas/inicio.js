// Inicio: dashboard general (HU-12) para el personal y resumen del día para el estudiante
import { api } from '../api.js';
import { estado } from '../estado.js';
import { esc, num, kpi, grafico, PALETA, badgeImc, badgeNivel, fecha, fechaHora, fechaCorta, barra, vacio, hoyIso } from '../ui.js';

export async function render(ctx) {
  if (estado.usuario.rol === 'Estudiante') return renderEstudiante(ctx);
  return renderPersonal(ctx);
}

async function renderPersonal({ el }) {
  const d = await api.get('/api/reportes/dashboard');
  const saludo = estado.usuario.nombre.split(' ').slice(0, 2).join(' ');
  el.innerHTML = `
    <div class="mb-4"><h3 class="fw-bold mb-0" style="color:var(--snt-900)">Hola, ${esc(saludo)} 👋</h3>
      <div class="muted">Estado general de ${estado.usuario.rol === 'Docente' ? 'tus cursos' : 'los estudiantes'} al ${fecha(hoyIso())}.</div></div>

    <div class="row g-3 mb-4">
      <div class="col-sm-6 col-xl-3">${kpi('bi-people', 'ic-verde', d.totalEstudiantes, 'Estudiantes activos')}</div>
      <div class="col-sm-6 col-xl-3">${kpi('bi-journal-check', 'ic-lima', `${d.registraronHoy}<span class="fs-6 muted">/${d.totalEstudiantes}</span>`, 'Registraron hoy')}</div>
      <div class="col-sm-6 col-xl-3">${kpi('bi-exclamation-triangle', 'ic-coral', d.alertasPendientes, 'Alertas pendientes')}</div>
      <div class="col-sm-6 col-xl-3">${kpi('bi-calendar2-heart', 'ic-ambar', d.citasProximas, 'Citas en 7 días')}</div>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-lg-5"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-pie-chart" style="color:var(--snt-700)"></i><h3>Estudiantes por categoría de IMC</h3></div>
        <div class="cuerpo"><div class="chart-box"><canvas id="g-imc"></canvas></div></div></div></div>
      <div class="col-lg-7"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-bar-chart" style="color:var(--snt-700)"></i><h3>Alertas pendientes por tipo</h3></div>
        <div class="cuerpo">${d.alertasPorTipo.length ? '<div class="chart-box"><canvas id="g-alertas"></canvas></div>' : vacio('Sin alertas pendientes. ¡Excelente!', 'bi-emoji-smile')}</div></div></div>
    </div>

    <div class="row g-3">
      <div class="col-xl-7"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-heart-pulse" style="color:var(--snt-coral)"></i><h3>Estudiantes que requieren atención</h3>
        <a href="#/alertas" class="ms-auto small">Ver alertas</a></div>
        <div class="cuerpo p-0">${d.estudiantesRiesgo.length ? `
          <div class="table-responsive"><table class="table table-hover">
            <thead><tr><th>Estudiante</th><th>Curso</th><th>IMC</th><th class="text-center">Alertas</th><th></th></tr></thead>
            <tbody>${d.estudiantesRiesgo.map(r => `<tr>
              <td class="fw-semibold">${esc(r.estudiante)}</td><td class="muted">${esc(r.curso)}</td>
              <td>${num(r.imc, 1)} ${badgeImc(r.categoriaImc)}</td>
              <td class="text-center">${r.alertasPendientes ? `<span class="badge b-coral">${r.alertasPendientes}</span>` : '—'}</td>
              <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="#/estudiante/${r.id}">Ver</a></td></tr>`).join('')}
            </tbody></table></div>` : '<div class="p-3">' + vacio('Ningún estudiante en riesgo.', 'bi-shield-check') + '</div>'}
        </div></div></div>

      <div class="col-xl-5">
        <div class="tarjeta mb-3"><div class="cabecera"><i class="bi bi-bell" style="color:var(--snt-ambar)"></i><h3>Últimas alertas</h3></div>
          <div class="cuerpo">${d.ultimasAlertas.length ? d.ultimasAlertas.map(a => `
            <div class="d-flex gap-2 py-2 border-bottom">
              <div>${badgeNivel(a.nivel)}</div>
              <div class="small"><div class="fw-semibold">${esc(a.estudiante)} · ${esc(a.tipo)}</div>
                <div class="muted">${esc(a.mensaje)} · ${fecha(a.fecha)}</div></div></div>`).join('') : vacio('Sin alertas.')}
          </div></div>
        <div class="tarjeta"><div class="cabecera"><i class="bi bi-calendar-event" style="color:var(--snt-700)"></i><h3>Próximas citas</h3>
          <a href="#/citas" class="ms-auto small">Agenda</a></div>
          <div class="cuerpo">${d.proximasCitas.length ? d.proximasCitas.map(c => `
            <div class="d-flex justify-content-between py-2 border-bottom small">
              <div><div class="fw-semibold">${esc(c.estudiante)}</div><div class="muted">${esc(c.motivo)}</div></div>
              <div class="text-end text-nowrap"><div class="fw-semibold">${fechaHora(c.fechaHora)}</div><div class="muted">${esc(c.nutricionista)}</div></div>
            </div>`).join('') : vacio('No hay citas programadas.', 'bi-calendar')}
          </div></div>
      </div>
    </div>`;

  grafico(el.querySelector('#g-imc'), {
    type: 'doughnut',
    data: {
      labels: d.porCategoriaImc.map(c => c.etiqueta),
      datasets: [{ data: d.porCategoriaImc.map(c => c.cantidad), backgroundColor: ['#e9c46a', '#52b788', '#a7c957', '#e76f51', '#95d5b2'], borderWidth: 2 }]
    },
    options: { cutout: '62%', plugins: { legend: { position: 'bottom' } } }
  });
  if (d.alertasPorTipo.length) {
    grafico(el.querySelector('#g-alertas'), {
      type: 'bar',
      data: { labels: d.alertasPorTipo.map(c => c.etiqueta), datasets: [{ label: 'Alertas', data: d.alertasPorTipo.map(c => c.cantidad), backgroundColor: PALETA[0], borderRadius: 8, maxBarThickness: 34 }] },
      options: { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { x: { ticks: { precision: 0 } } } }
    });
  }
}

async function renderEstudiante({ el }) {
  const r = await api.get('/api/reportes/mi-resumen');
  const pct = r.caloriasObjetivo > 0 ? Math.round(r.caloriasHoy / r.caloriasObjetivo * 100) : 0;
  el.innerHTML = `
    <div class="tarjeta mb-4 p-4" style="background:linear-gradient(135deg,var(--snt-800),var(--snt-700));color:#fff;border:none">
      <div class="d-flex flex-wrap justify-content-between gap-3 align-items-center">
        <div><h3 class="fw-bold mb-1">¡Hola, ${esc(r.nombre.split(' ')[0])}!</h3>
          <div style="color:var(--snt-100)">Tu objetivo diario es de <strong>${num(r.caloriasObjetivo)} kcal</strong>. IMC ${num(r.imc, 1)} · ${esc(r.categoriaImc)}</div></div>
        <div class="d-flex gap-2">
          <a href="#/registro" class="btn btn-lima fw-semibold"><i class="bi bi-plus-circle me-1"></i>Registrar mi día</a>
          <a href="#/recomendaciones" class="btn btn-outline-light"><i class="bi bi-stars me-1"></i>Mi menú</a>
        </div>
      </div>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-md-6 col-xl-3"><div class="tarjeta kpi flex-column align-items-stretch">
        <div class="d-flex gap-3 align-items-center"><div class="icono ic-verde"><i class="bi bi-fire"></i></div>
          <div><div class="valor">${num(r.caloriasHoy)}</div><div class="etiqueta">kcal hoy (${pct}%)</div></div></div>
        <div class="mt-2">${barra(r.caloriasHoy, r.caloriasObjetivo)}</div></div></div>
      <div class="col-md-6 col-xl-3"><div class="tarjeta kpi flex-column align-items-stretch">
        <div class="d-flex gap-3 align-items-center"><div class="icono ic-lima"><i class="bi bi-droplet"></i></div>
          <div><div class="valor">${num(r.aguaHoyMl)}</div><div class="etiqueta">ml de agua (meta 2000)</div></div></div>
        <div class="mt-2">${barra(r.aguaHoyMl, 2000)}</div></div></div>
      <div class="col-md-6 col-xl-3">${kpi('bi-moon-stars', 'ic-ambar', r.suenoHoy != null ? num(r.suenoHoy, 1) + ' h' : '—', 'Sueño registrado hoy')}</div>
      <div class="col-md-6 col-xl-3">${kpi('bi-bicycle', 'ic-coral', r.actividadHoy != null ? r.actividadHoy + ' min' : '—', 'Actividad física hoy')}</div>
    </div>

    <div class="row g-3">
      <div class="col-xl-8"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-graph-up" style="color:var(--snt-700)"></i><h3>Mis últimos 7 días</h3></div>
        <div class="cuerpo"><div class="chart-box"><canvas id="g-semana"></canvas></div></div></div></div>
      <div class="col-xl-4">
        <div class="tarjeta mb-3"><div class="cabecera"><i class="bi bi-calendar2-heart" style="color:var(--snt-700)"></i><h3>Próxima cita</h3></div>
          <div class="cuerpo">${r.proximaCita ? `<div class="fw-bold">${fechaHora(r.proximaCita.fechaHora)}</div>
            <div class="muted small">${esc(r.proximaCita.nutricionista)} · ${r.proximaCita.duracionMinutos} min</div>
            <div class="mt-2 small">${esc(r.proximaCita.motivo)}</div>` : vacio('Sin citas programadas.', 'bi-calendar')}</div></div>
        <div class="tarjeta"><div class="cabecera"><i class="bi bi-info-circle" style="color:var(--snt-700)"></i><h3>Avisos</h3></div>
          <div class="cuerpo small">
            <div class="d-flex justify-content-between py-1"><span>Notificaciones sin leer</span><a href="#/notificaciones" class="badge b-verde">${r.notificacionesNoLeidas}</a></div>
            <div class="d-flex justify-content-between py-1"><span>Alertas de hábitos pendientes</span><span class="badge ${r.alertasPendientes ? 'b-coral' : 'b-verde'}">${r.alertasPendientes}</span></div>
            <div class="d-flex justify-content-between py-1"><span>Última recomendación</span>${r.ultimaRecomendacionId ? '<a href="#/recomendaciones">Ver menú</a>' : '<span class="muted">Aún no generada</span>'}</div>
          </div></div>
      </div>
    </div>`;

  grafico(el.querySelector('#g-semana'), {
    data: {
      labels: r.ultimosDias.map(d => fechaCorta(d.fecha)),
      datasets: [
        { type: 'bar', label: 'Calorías', data: r.ultimosDias.map(d => d.calorias), backgroundColor: '#52b788', borderRadius: 8, maxBarThickness: 40, yAxisID: 'y' },
        { type: 'line', label: 'Objetivo', data: r.ultimosDias.map(() => r.caloriasObjetivo), borderColor: '#1b4332', borderDash: [6, 4], pointRadius: 0, yAxisID: 'y' },
        { type: 'line', label: 'Agua (ml)', data: r.ultimosDias.map(d => d.aguaMl ?? 0), borderColor: '#a7c957', backgroundColor: '#a7c957', tension: .35, yAxisID: 'y2' }
      ]
    },
    options: { scales: { y: { beginAtZero: true, title: { display: true, text: 'kcal' } }, y2: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false }, title: { display: true, text: 'ml' } } } }
  });
}
