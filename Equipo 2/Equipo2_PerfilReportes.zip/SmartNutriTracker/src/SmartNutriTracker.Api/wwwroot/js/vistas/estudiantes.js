// HU-08 Registro de estudiantes · listado para el personal
import { api, conParametros } from '../api.js';
import { estado, esRol, cargarEstudiantes } from '../estado.js';
import { esc, num, badgeImc, vacio, abrirModal, leerFormulario, opciones, toast, on } from '../ui.js';

let filtros = { buscar: '', cursoId: '', incluirInactivos: false };

export async function render({ el }) {
  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2">
        <h3><i class="bi bi-people me-1"></i>Estudiantes</h3>
        <div class="ms-auto d-flex flex-wrap gap-2">
          <input class="form-control form-control-sm" style="width:220px" placeholder="Buscar por nombre..." id="f-buscar" value="${esc(filtros.buscar)}">
          <select class="form-select form-select-sm" style="width:190px" id="f-curso">${opciones(estado.catalogos.cursos, filtros.cursoId, { vacioTexto: 'Todos los cursos' })}</select>
          <div class="form-check form-switch align-self-center small"><input class="form-check-input" type="checkbox" id="f-inactivos" ${filtros.incluirInactivos ? 'checked' : ''}>
            <label class="form-check-label" for="f-inactivos">Inactivos</label></div>
          <button class="btn btn-primary btn-sm" data-accion="nuevo"><i class="bi bi-person-plus me-1"></i>Registrar estudiante</button>
        </div>
      </div>
      <div class="cuerpo p-0" id="tabla"></div>
    </div>`;

  const cargar = async () => {
    const lista = await api.get(conParametros('/api/estudiantes', filtros));
    el.querySelector('#tabla').innerHTML = lista.length ? `
      <div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Estudiante</th><th>Curso</th><th>Edad</th><th>Peso / Talla</th><th>IMC</th><th>Objetivo</th><th>Cuenta</th><th></th></tr></thead>
        <tbody>${lista.map(e => `<tr class="${e.activo ? '' : 'opacity-50'}">
          <td><div class="fw-semibold">${esc(e.nombreCompleto)}</div><div class="small muted">${e.sexo === 'F' ? 'Femenino' : 'Masculino'}</div></td>
          <td>${esc(e.curso)}</td><td>${e.edad} años</td>
          <td>${num(e.pesoKg, 1)} kg · ${num(e.alturaCm)} cm</td>
          <td>${num(e.imc, 1)} ${badgeImc(e.categoriaImc)}</td>
          <td>${esc(e.objetivo)}</td>
          <td class="small">${e.correo ? esc(e.correo) : '<span class="muted">Sin cuenta</span>'}</td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-outline-primary" href="#/estudiante/${e.id}" title="Perfil"><i class="bi bi-eye"></i></a>
            <button class="btn btn-sm btn-light" data-accion="editar" data-id="${e.id}" title="Editar"><i class="bi bi-pencil"></i></button>
          </td></tr>`).join('')}</tbody></table></div>` : vacio('No se encontraron estudiantes.', 'bi-people');
  };

  let temporizador;
  el.querySelector('#f-buscar').addEventListener('input', (ev) => {
    clearTimeout(temporizador);
    temporizador = setTimeout(() => { filtros.buscar = ev.target.value; cargar(); }, 300);
  });
  el.querySelector('#f-curso').addEventListener('change', (ev) => { filtros.cursoId = ev.target.value; cargar(); });
  el.querySelector('#f-inactivos').addEventListener('change', (ev) => { filtros.incluirInactivos = ev.target.checked; cargar(); });
  on(el, 'click', '[data-accion=nuevo]', () => formulario(null, cargar));
  on(el, 'click', '[data-accion=editar]', async (_, b) => formulario(await api.get(`/api/estudiantes/${b.dataset.id}`), cargar));

  await cargar();
}

/** Formulario de alta/edición de estudiante (también lo usa la vista de perfil). */
export function formulario(e, alGuardar) {
  const cat = estado.catalogos;
  const cursos = esRol('Docente') ? cat.cursos.filter(c => c.docenteId === estado.usuario.id) : cat.cursos;
  const cuerpo = `
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">Nombres</label><input class="form-control" name="nombres" required maxlength="100" value="${esc(e?.nombres)}"></div>
      <div class="col-md-6"><label class="form-label">Apellidos</label><input class="form-control" name="apellidos" required maxlength="100" value="${esc(e?.apellidos)}"></div>
      <div class="col-md-4"><label class="form-label">Fecha de nacimiento</label><input type="date" class="form-control" name="fechaNacimiento" required value="${esc(e?.fechaNacimiento)}"></div>
      <div class="col-md-4"><label class="form-label">Sexo</label><select class="form-select" name="sexo">
        <option value="F" ${e?.sexo === 'F' ? 'selected' : ''}>Femenino</option><option value="M" ${e?.sexo === 'M' ? 'selected' : ''}>Masculino</option></select></div>
      <div class="col-md-4"><label class="form-label">Curso</label><select class="form-select" name="cursoId" data-tipo="int" required>${opciones(cursos, e?.cursoId)}</select></div>
      <div class="col-md-3"><label class="form-label">Peso (kg)</label><input type="number" step="0.1" min="10" max="300" class="form-control" name="pesoKg" data-tipo="num" required value="${e?.pesoKg ?? ''}"></div>
      <div class="col-md-3"><label class="form-label">Talla (cm)</label><input type="number" step="0.1" min="80" max="230" class="form-control" name="alturaCm" data-tipo="num" required value="${e?.alturaCm ?? ''}"></div>
      <div class="col-md-6"><label class="form-label">Nivel de actividad</label><select class="form-select" name="nivelActividadId" data-tipo="int">${opciones(cat.nivelesActividad, e?.nivelActividadId ?? cat.nivelesActividad[2]?.id)}</select></div>
      <div class="col-md-6"><label class="form-label">Objetivo</label><select class="form-select" name="objetivoId" data-tipo="int">${opciones(cat.objetivos, e?.objetivoId ?? cat.objetivos[1]?.id)}</select></div>
      ${e ? `<div class="col-md-6 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="chk-activo" ${e.activo ? 'checked' : ''}>
        <label class="form-check-label" for="chk-activo">Estudiante activo</label></div></div>` : `
      <div class="col-12"><hr class="my-1"><div class="small fw-semibold" style="color:var(--snt-800)"><i class="bi bi-person-lock"></i> Cuenta de acceso (opcional)</div></div>
      <div class="col-md-6"><label class="form-label">Correo</label><input type="email" class="form-control" name="correo" data-nulo maxlength="150" placeholder="nombre.apellido@innovare.edu.bo"></div>
      <div class="col-md-6"><label class="form-label">Contraseña inicial</label><input type="text" class="form-control" name="password" data-nulo minlength="8" placeholder="Mín. 8, mayúscula, minúscula y número"></div>`}
    </div>`;

  abrirModal({
    titulo: e ? `Editar: ${e.nombreCompleto}` : 'Registrar estudiante', cuerpo, tamano: 'modal-lg',
    alGuardar: async (form) => {
      const datos = leerFormulario(form);
      if (e) datos.activo = form.querySelector('[name=activo]').checked;
      const r = e ? await api.put(`/api/estudiantes/${e.id}`, datos) : await api.post('/api/estudiantes', datos);
      toast(e ? 'Estudiante actualizado.' : `Estudiante ${r.nombreCompleto} registrado.`);
      await cargarEstudiantes(true);
      await alGuardar?.(r);
    }
  });
}
