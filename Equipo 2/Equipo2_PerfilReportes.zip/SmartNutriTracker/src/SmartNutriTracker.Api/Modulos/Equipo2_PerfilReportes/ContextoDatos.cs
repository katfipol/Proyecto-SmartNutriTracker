// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 2 – Perfil y Reportes dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<NivelActividad> NivelesActividad => Set<NivelActividad>();
    public DbSet<Curso> Cursos => Set<Curso>();
    public DbSet<Estudiante> Estudiantes => Set<Estudiante>();
    public DbSet<MedicionEstudiante> MedicionesEstudiante => Set<MedicionEstudiante>();

    partial void ConfigurarEquipo2(ModelBuilder mb)
    {
        mb.Entity<NivelActividad>(e =>
        {
            e.ToTable("NivelesActividad");
            e.Property(x => x.Factor).HasPrecision(4, 3);
        });
        mb.Entity<Curso>(e =>
        {
            e.ToTable("Cursos");
            e.HasOne(x => x.Docente).WithMany().HasForeignKey(x => x.DocenteId).OnDelete(DeleteBehavior.Restrict);
        });
        mb.Entity<Estudiante>(e =>
        {
            e.ToTable("Estudiantes");
            e.Property(x => x.Sexo).HasMaxLength(1).IsFixedLength().IsUnicode(false);
            e.HasOne(x => x.Usuario).WithMany().HasForeignKey(x => x.UsuarioId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Objetivo).WithMany().HasForeignKey(x => x.ObjetivoId).OnDelete(DeleteBehavior.Restrict);
            e.Ignore(x => x.NombreCompleto);
        });
        mb.Entity<MedicionEstudiante>().ToTable("MedicionesEstudiante");
    }
}
