// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IReportesService
{
    Task<ReporteSemanalDto> SemanalAsync(int estudianteId, DateOnly? hasta, CancellationToken ct = default);
    Task<DashboardDto> DashboardAsync(CancellationToken ct = default);
    Task<MiResumenDto> MiResumenAsync(CancellationToken ct = default);
}

public class ReportesService(
    SmartNutriDbContext db,
    IAccesoService acceso,
    IUsuarioActual usuario,
    INutricionService nutricion) : IReportesService
{
    public async Task<ReporteSemanalDto> SemanalAsync(int estudianteId, DateOnly? hasta, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(estudianteId, ct);
        var fin = hasta ?? DateOnly.FromDateTime(DateTime.Today);
        var inicio = fin.AddDays(-6);

        var e = await nutricion.CargarEstudianteAsync(estudianteId, ct);
        var calculo = await nutricion.CalcularEstudianteAsync(e, fin, ct: ct);
        var dias = await DiasAsync(estudianteId, inicio, fin, ct);
        var alertas = await db.Alertas.CountAsync(a => a.EstudianteId == estudianteId && a.Fecha >= inicio && a.Fecha <= fin, ct);

        var conConsumo = dias.Where(d => d.Calorias > 0).ToList();
        var conHabitos = dias.Where(d => d.AguaMl.HasValue).ToList();
        var promKcal = conConsumo.Count > 0 ? Math.Round(conConsumo.Average(d => d.Calorias), 0) : 0;
        var promAgua = conHabitos.Count > 0 ? Math.Round((decimal)conHabitos.Average(d => d.AguaMl!.Value), 0) : 0;
        var promSueno = conHabitos.Count > 0 ? Math.Round(conHabitos.Average(d => d.HorasSueno!.Value), 1) : 0;
        var promAct = conHabitos.Count > 0 ? Math.Round((decimal)conHabitos.Average(d => d.MinutosActividad!.Value), 0) : 0;
        var cumplimiento = calculo.CaloriasObjetivo > 0 ? Math.Round(promKcal / calculo.CaloriasObjetivo * 100, 1) : 0;
        var diasRegistro = dias.Count(d => d.Calorias > 0 || d.AguaMl.HasValue);

        var conclusiones = new List<string>();
        if (diasRegistro < 5) conclusiones.Add($"Registró datos solo {diasRegistro} de 7 días: se recomienda constancia en el registro.");
        if (conConsumo.Count > 0)
        {
            if (cumplimiento > 115) conclusiones.Add($"Consumo calórico promedio alto ({cumplimiento}% del objetivo).");
            else if (cumplimiento < 85) conclusiones.Add($"Consumo calórico promedio bajo ({cumplimiento}% del objetivo).");
            else conclusiones.Add($"Consumo calórico adecuado ({cumplimiento}% del objetivo).");
            var azucar = conConsumo.Average(d => d.Azucares);
            if (azucar > 50) conclusiones.Add($"Azúcar promedio elevada ({azucar:0} g/día).");
            var sodio = conConsumo.Average(d => d.SodioMg);
            if (sodio > 2300) conclusiones.Add($"Sodio promedio elevado ({sodio:0} mg/día).");
        }
        if (conHabitos.Count > 0)
        {
            if (promAgua < 1500) conclusiones.Add($"Hidratación insuficiente ({promAgua:0} ml/día en promedio).");
            if (promSueno < 7) conclusiones.Add($"Horas de sueño insuficientes ({promSueno} h en promedio).");
            if (promAct < 30) conclusiones.Add($"Actividad física baja ({promAct:0} min/día en promedio).");
        }
        if (conclusiones.Count == 0) conclusiones.Add("Sin observaciones: hábitos dentro de los rangos esperados.");

        return new ReporteSemanalDto(e.Id, e.NombreCompleto, e.Curso!.Nombre, inicio, fin, calculo.Imc, calculo.CategoriaImc,
            calculo.CaloriasObjetivo, dias, promKcal, promAgua, promSueno, promAct, cumplimiento, diasRegistro, alertas, conclusiones);
    }

    public async Task<DashboardDto> DashboardAsync(CancellationToken ct = default)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("El dashboard general es para el personal del colegio.");
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        var estudiantes = await acceso.EstudiantesVisibles().AsNoTracking().Where(e => e.Activo).Include(e => e.Curso).ToListAsync(ct);
        var ids = estudiantes.Select(e => e.Id).ToList();
        var reglas = await nutricion.ReglasAsync(ct);

        var conImc = estudiantes.Select(e =>
        {
            var imc = CalculadoraNutricional.CalcularImc(e.PesoKg, e.AlturaCm);
            return (Estudiante: e, Imc: imc, Categoria: reglas.FirstOrDefault(r => imc >= r.ImcMin && imc < r.ImcMax)?.Categoria ?? "Sin categoría");
        }).ToList();

        var registraronHoy = await db.RegistrosConsumo.Where(r => ids.Contains(r.EstudianteId) && r.Fecha == hoy).Select(r => r.EstudianteId)
            .Union(db.RegistrosHabitos.Where(h => ids.Contains(h.EstudianteId) && h.Fecha == hoy).Select(h => h.EstudianteId))
            .Distinct().CountAsync(ct);

        var pendientes = await db.Alertas.AsNoTracking().Where(a => ids.Contains(a.EstudianteId) && !a.Atendida)
            .Include(a => a.Estudiante).ThenInclude(e => e!.Curso).Include(a => a.TipoAlerta)
            .OrderByDescending(a => a.Fecha).ThenByDescending(a => a.Id).ToListAsync(ct);

        var ahora = DateTime.Now;
        var limite = ahora.AddDays(7);
        var citasQ = db.Citas.AsNoTracking().Where(c => ids.Contains(c.EstudianteId) && c.Estado == "Programada" && c.FechaHora >= ahora && c.FechaHora <= limite);
        if (usuario.EsNutricionista) { var uid = usuario.Id; citasQ = citasQ.Where(c => c.NutricionistaId == uid); }
        var citas = await citasQ.Include(c => c.Estudiante).Include(c => c.Nutricionista).OrderBy(c => c.FechaHora).Take(10).ToListAsync(ct);

        var orden = reglas.Select(r => r.Categoria).ToList();
        var porCategoria = conImc.GroupBy(x => x.Categoria)
            .Select(g => new ConteoDto(g.Key, g.Count()))
            .OrderBy(c => orden.IndexOf(c.Etiqueta) < 0 ? 99 : orden.IndexOf(c.Etiqueta)).ToList();
        var porTipo = pendientes.GroupBy(a => a.TipoAlerta!.Nombre).Select(g => new ConteoDto(g.Key, g.Count()))
            .OrderByDescending(c => c.Cantidad).ToList();

        var riesgo = conImc
            .Select(x => new EstudianteRiesgoDto(x.Estudiante.Id, x.Estudiante.NombreCompleto, x.Estudiante.Curso!.Nombre, x.Imc, x.Categoria,
                pendientes.Count(a => a.EstudianteId == x.Estudiante.Id)))
            .Where(x => x.AlertasPendientes > 0 || x.CategoriaImc is "Bajo peso" or "Obesidad")
            .OrderByDescending(x => x.AlertasPendientes).ThenBy(x => x.Estudiante)
            .Take(10).ToList();

        return new DashboardDto(estudiantes.Count, registraronHoy, pendientes.Count, citas.Count, porCategoria, porTipo,
            pendientes.Take(8).Select(Mapeos.ADto).ToList(), citas.Select(Mapeos.ADto).ToList(), riesgo);
    }

    public async Task<MiResumenDto> MiResumenAsync(CancellationToken ct = default)
    {
        var id = await acceso.EstudianteActualIdAsync(ct);
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        var e = await nutricion.CargarEstudianteAsync(id, ct);
        var calculo = await nutricion.CalcularEstudianteAsync(e, hoy, ct: ct);
        var dias = await DiasAsync(id, hoy.AddDays(-6), hoy, ct);
        var deHoy = dias.Last();

        var ultimaRec = await db.Recomendaciones.Where(r => r.EstudianteId == id)
            .OrderByDescending(r => r.Fecha).ThenByDescending(r => r.Id).Select(r => (int?)r.Id).FirstOrDefaultAsync(ct);
        var ahora = DateTime.Now;
        var cita = await db.Citas.AsNoTracking().Include(c => c.Estudiante).Include(c => c.Nutricionista)
            .Where(c => c.EstudianteId == id && c.Estado == "Programada" && c.FechaHora >= ahora)
            .OrderBy(c => c.FechaHora).FirstOrDefaultAsync(ct);
        var uid = usuario.Id;
        var noLeidas = await db.Notificaciones.CountAsync(n => n.UsuarioId == uid && !n.Leida, ct);
        var alertas = await db.Alertas.CountAsync(a => a.EstudianteId == id && !a.Atendida, ct);

        return new MiResumenDto(id, e.NombreCompleto, calculo.Imc, calculo.CategoriaImc, calculo.CaloriasObjetivo,
            deHoy.Calorias, deHoy.AguaMl ?? 0, deHoy.HorasSueno, deHoy.MinutosActividad, ultimaRec,
            cita is null ? null : Mapeos.ADto(cita), noLeidas, alertas, dias);
    }

    private async Task<List<DiaReporteDto>> DiasAsync(int estudianteId, DateOnly inicio, DateOnly fin, CancellationToken ct)
    {
        var consumo = await db.RegistrosConsumo.AsNoTracking()
            .Where(r => r.EstudianteId == estudianteId && r.Fecha >= inicio && r.Fecha <= fin)
            .Select(r => new
            {
                r.Fecha,
                Kcal = r.Alimento!.Calorias * r.Porciones,
                Prot = r.Alimento.Proteinas * r.Porciones,
                Carb = r.Alimento.Carbohidratos * r.Porciones,
                Gras = r.Alimento.Grasas * r.Porciones,
                Azu = r.Alimento.Azucares * r.Porciones,
                Sod = r.Alimento.SodioMg * r.Porciones
            })
            .GroupBy(x => x.Fecha)
            .Select(g => new
            {
                Fecha = g.Key,
                Calorias = g.Sum(x => x.Kcal),
                Proteinas = g.Sum(x => x.Prot),
                Carbohidratos = g.Sum(x => x.Carb),
                Grasas = g.Sum(x => x.Gras),
                Azucares = g.Sum(x => x.Azu),
                Sodio = g.Sum(x => x.Sod)
            }).ToListAsync(ct);
        var habitos = await db.RegistrosHabitos.AsNoTracking()
            .Where(h => h.EstudianteId == estudianteId && h.Fecha >= inicio && h.Fecha <= fin).ToListAsync(ct);

        var resultado = new List<DiaReporteDto>();
        for (var f = inicio; f <= fin; f = f.AddDays(1))
        {
            var c = consumo.FirstOrDefault(x => x.Fecha == f);
            var h = habitos.FirstOrDefault(x => x.Fecha == f);
            resultado.Add(new DiaReporteDto(f, Math.Round(c?.Calorias ?? 0, 0), Math.Round(c?.Proteinas ?? 0, 1),
                Math.Round(c?.Carbohidratos ?? 0, 1), Math.Round(c?.Grasas ?? 0, 1), Math.Round(c?.Azucares ?? 0, 1),
                Math.Round(c?.Sodio ?? 0, 0), h?.HorasSueno, h?.AguaMl, h?.MinutosActividad));
        }
        return resultado;
    }
}
