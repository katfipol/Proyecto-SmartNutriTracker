// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IEstudiantesService
{
    Task<IReadOnlyList<EstudianteResumenDto>> ListarAsync(string? buscar, int? cursoId, bool incluirInactivos, CancellationToken ct = default);
    Task<EstudiantePerfilDto> PerfilAsync(int id, CancellationToken ct = default);
    Task<EstudiantePerfilDto> MiPerfilAsync(CancellationToken ct = default);
    Task<EstudiantePerfilDto> CrearAsync(EstudianteRequest request, CancellationToken ct = default);
    Task<EstudiantePerfilDto> ActualizarAsync(int id, EstudianteRequest request, CancellationToken ct = default);
    Task<EstudiantePerfilDto> ActualizarDatosFisicosAsync(int id, DatosFisicosRequest request, CancellationToken ct = default);
    Task<EstudiantePerfilDto> ActualizarExcluidosAsync(int id, List<AlimentoExcluidoRequest> request, CancellationToken ct = default);
    Task DesactivarAsync(int id, CancellationToken ct = default);
}

public class EstudiantesService(
    SmartNutriDbContext db,
    IAccesoService acceso,
    IUsuarioActual usuario,
    INutricionService nutricion,
    IUsuariosService usuarios,
    IAlertasService alertas,
    IAuditoriaService auditoria) : IEstudiantesService
{
    public async Task<IReadOnlyList<EstudianteResumenDto>> ListarAsync(string? buscar, int? cursoId, bool incluirInactivos, CancellationToken ct = default)
    {
        var q = acceso.EstudiantesVisibles().AsNoTracking()
            .Include(e => e.Curso).Include(e => e.Objetivo).Include(e => e.Usuario).AsQueryable();
        if (!incluirInactivos) q = q.Where(e => e.Activo);
        if (cursoId.HasValue) q = q.Where(e => e.CursoId == cursoId);
        if (!string.IsNullOrWhiteSpace(buscar)) q = q.Where(e => (e.Nombres + " " + e.Apellidos).Contains(buscar));

        var lista = await q.OrderBy(e => e.Apellidos).ThenBy(e => e.Nombres).ToListAsync(ct);
        var reglas = await nutricion.ReglasAsync(ct);
        var hoy = DateOnly.FromDateTime(DateTime.Today);

        return lista.Select(e =>
        {
            var imc = CalculadoraNutricional.CalcularImc(e.PesoKg, e.AlturaCm);
            var cat = reglas.FirstOrDefault(r => imc >= r.ImcMin && imc < r.ImcMax)?.Categoria ?? "Sin categoría";
            return new EstudianteResumenDto(e.Id, e.NombreCompleto, e.Curso!.Nombre, CalculadoraNutricional.CalcularEdad(e.FechaNacimiento, hoy),
                e.Sexo, e.PesoKg, e.AlturaCm, imc, cat, e.Objetivo!.Nombre, e.Activo, e.Usuario?.Correo);
        }).ToList();
    }

    public async Task<EstudiantePerfilDto> PerfilAsync(int id, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(id, ct);
        var e = await nutricion.CargarEstudianteAsync(id, ct);
        var calculo = await nutricion.CalcularEstudianteAsync(e, DateOnly.FromDateTime(DateTime.Today), ct: ct);

        var mediciones = await db.MedicionesEstudiante.AsNoTracking().Where(m => m.EstudianteId == id)
            .OrderBy(m => m.Fecha).ToListAsync(ct);
        var excluidos = await db.AlimentosExcluidos.AsNoTracking().Where(x => x.EstudianteId == id)
            .Select(x => new AlimentoExcluidoDto(x.AlimentoId, x.Alimento!.Nombre, x.Motivo)).ToListAsync(ct);

        return new EstudiantePerfilDto(e.Id, e.Nombres, e.Apellidos, e.NombreCompleto, e.FechaNacimiento,
            CalculadoraNutricional.CalcularEdad(e.FechaNacimiento, DateOnly.FromDateTime(DateTime.Today)), e.Sexo,
            e.CursoId, e.Curso!.Nombre, e.PesoKg, e.AlturaCm, e.NivelActividadId, e.NivelActividad!.Nombre,
            e.ObjetivoId, e.Objetivo!.Nombre, e.Objetivo.Codigo, e.Activo, e.UsuarioId, e.Usuario?.Correo,
            Mapeos.ADto(calculo),
            mediciones.Select(m => new MedicionDto(m.Fecha, m.PesoKg, m.AlturaCm, CalculadoraNutricional.CalcularImc(m.PesoKg, m.AlturaCm))).ToList(),
            excluidos);
    }

    public async Task<EstudiantePerfilDto> MiPerfilAsync(CancellationToken ct = default) =>
        await PerfilAsync(await acceso.EstudianteActualIdAsync(ct), ct);

    public async Task<EstudiantePerfilDto> CrearAsync(EstudianteRequest request, CancellationToken ct = default)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("Los estudiantes no pueden registrar estudiantes.");
        await ValidarAsync(request, ct);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        int? usuarioId = null;
        if (!string.IsNullOrWhiteSpace(request.Correo))
        {
            if (string.IsNullOrWhiteSpace(request.Password))
                throw new ReglaNegocioException("Indique una contraseña para la cuenta del estudiante.");
            var cuenta = await usuarios.CrearEntidadAsync($"{request.Nombres} {request.Apellidos}", request.Correo, request.Password, Roles.Estudiante, ct);
            usuarioId = cuenta.Id;
        }

        var e = new Estudiante
        {
            UsuarioId = usuarioId,
            Nombres = request.Nombres.Trim(),
            Apellidos = request.Apellidos.Trim(),
            FechaNacimiento = request.FechaNacimiento,
            Sexo = request.Sexo,
            CursoId = request.CursoId,
            PesoKg = request.PesoKg,
            AlturaCm = request.AlturaCm,
            NivelActividadId = request.NivelActividadId,
            ObjetivoId = request.ObjetivoId,
            Activo = true,
            FechaRegistro = DateTime.UtcNow
        };
        db.Estudiantes.Add(e);
        await db.SaveChangesAsync(ct);
        await RegistrarMedicionAsync(e.Id, e.PesoKg, e.AlturaCm, ct);
        await tx.CommitAsync(ct);

        await auditoria.RegistrarAsync("CREAR", "Estudiante", e.Id, e.NombreCompleto, ct: ct);
        await alertas.EvaluarImcAsync(e.Id, ct);
        return await PerfilAsync(e.Id, ct);
    }

    public async Task<EstudiantePerfilDto> ActualizarAsync(int id, EstudianteRequest request, CancellationToken ct = default)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("Use la opción 'Mi perfil' para actualizar sus datos.");
        await acceso.VerificarEstudianteAsync(id, ct);
        await ValidarAsync(request, ct);

        var e = await db.Estudiantes.FirstAsync(x => x.Id == id, ct);
        var cambioFisico = e.PesoKg != request.PesoKg || e.AlturaCm != request.AlturaCm;
        e.Nombres = request.Nombres.Trim();
        e.Apellidos = request.Apellidos.Trim();
        e.FechaNacimiento = request.FechaNacimiento;
        e.Sexo = request.Sexo;
        e.CursoId = request.CursoId;
        e.PesoKg = request.PesoKg;
        e.AlturaCm = request.AlturaCm;
        e.NivelActividadId = request.NivelActividadId;
        e.ObjetivoId = request.ObjetivoId;
        e.Activo = request.Activo;
        await db.SaveChangesAsync(ct);
        if (cambioFisico) await RegistrarMedicionAsync(id, e.PesoKg, e.AlturaCm, ct);

        await auditoria.RegistrarAsync("ACTUALIZAR", "Estudiante", id, e.NombreCompleto, ct: ct);
        if (cambioFisico) await alertas.EvaluarImcAsync(id, ct);
        return await PerfilAsync(id, ct);
    }

    public async Task<EstudiantePerfilDto> ActualizarDatosFisicosAsync(int id, DatosFisicosRequest request, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(id, ct);
        if (!await db.NivelesActividad.AnyAsync(n => n.Id == request.NivelActividadId, ct))
            throw new ReglaNegocioException("Nivel de actividad no válido.");
        if (!await db.ObjetivosNutricionales.AnyAsync(o => o.Id == request.ObjetivoId, ct))
            throw new ReglaNegocioException("Objetivo no válido.");

        var e = await db.Estudiantes.FirstAsync(x => x.Id == id, ct);
        e.PesoKg = request.PesoKg;
        e.AlturaCm = request.AlturaCm;
        e.NivelActividadId = request.NivelActividadId;
        e.ObjetivoId = request.ObjetivoId;
        await db.SaveChangesAsync(ct);
        await RegistrarMedicionAsync(id, e.PesoKg, e.AlturaCm, ct);

        await auditoria.RegistrarAsync("ACTUALIZAR_DATOS_FISICOS", "Estudiante", id,
            $"Peso {request.PesoKg} kg, altura {request.AlturaCm} cm", ct: ct);
        await alertas.EvaluarImcAsync(id, ct);
        return await PerfilAsync(id, ct);
    }

    public async Task<EstudiantePerfilDto> ActualizarExcluidosAsync(int id, List<AlimentoExcluidoRequest> request, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(id, ct);
        var ids = request.Select(r => r.AlimentoId).Distinct().ToList();
        var existentes = await db.Alimentos.Where(a => ids.Contains(a.Id)).Select(a => a.Id).ToListAsync(ct);
        var faltantes = ids.Except(existentes).ToList();
        if (faltantes.Count > 0) throw new NoEncontradoException($"Alimentos no encontrados: {string.Join(", ", faltantes)}.");

        db.AlimentosExcluidos.RemoveRange(await db.AlimentosExcluidos.Where(x => x.EstudianteId == id).ToListAsync(ct));
        db.AlimentosExcluidos.AddRange(request.GroupBy(r => r.AlimentoId)
            .Select(g => new AlimentoExcluido { EstudianteId = id, AlimentoId = g.Key, Motivo = g.First().Motivo }));
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR_EXCLUIDOS", "Estudiante", id, $"{ids.Count} alimento(s) excluido(s)", ct: ct);
        return await PerfilAsync(id, ct);
    }

    public async Task DesactivarAsync(int id, CancellationToken ct = default)
    {
        var e = await db.Estudiantes.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Estudiante {id} no encontrado.");
        e.Activo = false;
        if (e.UsuarioId.HasValue)
        {
            var u = await db.Usuarios.FirstAsync(x => x.Id == e.UsuarioId, ct);
            u.Activo = false;
        }
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("DESACTIVAR", "Estudiante", id, e.NombreCompleto, ct: ct);
    }

    private async Task ValidarAsync(EstudianteRequest r, CancellationToken ct)
    {
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        var edad = CalculadoraNutricional.CalcularEdad(r.FechaNacimiento, hoy);
        if (edad is < 5 or > 25) throw new ReglaNegocioException("La edad del estudiante debe estar entre 5 y 25 años.");
        if (!await db.Cursos.AnyAsync(c => c.Id == r.CursoId, ct)) throw new ReglaNegocioException("Curso no válido.");
        if (usuario.EsDocente && !await db.Cursos.AnyAsync(c => c.Id == r.CursoId && c.DocenteId == usuario.Id, ct))
            throw new AccesoDenegadoException("Solo puede registrar estudiantes en sus propios cursos.");
        if (!await db.NivelesActividad.AnyAsync(n => n.Id == r.NivelActividadId, ct)) throw new ReglaNegocioException("Nivel de actividad no válido.");
        if (!await db.ObjetivosNutricionales.AnyAsync(o => o.Id == r.ObjetivoId, ct)) throw new ReglaNegocioException("Objetivo no válido.");
    }

    private async Task RegistrarMedicionAsync(int estudianteId, decimal peso, decimal altura, CancellationToken ct)
    {
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        var m = await db.MedicionesEstudiante.FirstOrDefaultAsync(x => x.EstudianteId == estudianteId && x.Fecha == hoy, ct);
        if (m is null) db.MedicionesEstudiante.Add(new MedicionEstudiante { EstudianteId = estudianteId, Fecha = hoy, PesoKg = peso, AlturaCm = altura });
        else { m.PesoKg = peso; m.AlturaCm = altura; }
        await db.SaveChangesAsync(ct);
    }
}
