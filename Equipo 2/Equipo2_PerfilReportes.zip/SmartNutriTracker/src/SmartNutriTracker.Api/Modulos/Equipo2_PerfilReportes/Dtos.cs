// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

public sealed record EstudianteResumenDto(
    int Id, string NombreCompleto, string Curso, int Edad, string Sexo, decimal PesoKg, decimal AlturaCm,
    decimal Imc, string CategoriaImc, string Objetivo, bool Activo, string? Correo);

public sealed record MedicionDto(DateOnly Fecha, decimal PesoKg, decimal AlturaCm, decimal Imc);

public sealed record EstudiantePerfilDto(
    int Id, string Nombres, string Apellidos, string NombreCompleto, DateOnly FechaNacimiento, int Edad, string Sexo,
    int CursoId, string Curso, decimal PesoKg, decimal AlturaCm, int NivelActividadId, string NivelActividad,
    int ObjetivoId, string Objetivo, string ObjetivoCodigo, bool Activo, int? UsuarioId, string? Correo,
    CalculoNutricionalDto Calculo, IReadOnlyList<MedicionDto> Mediciones, IReadOnlyList<AlimentoExcluidoDto> AlimentosExcluidos);

public sealed class EstudianteRequest
{
    [Required, MaxLength(100)] public string Nombres { get; set; } = string.Empty;
    [Required, MaxLength(100)] public string Apellidos { get; set; } = string.Empty;
    [Required] public DateOnly FechaNacimiento { get; set; }
    [Required, RegularExpression("^[MF]$", ErrorMessage = "Sexo debe ser 'M' o 'F'.")] public string Sexo { get; set; } = "M";
    [Required, Range(1, int.MaxValue)] public int CursoId { get; set; }
    [Required, Range(10, 300)] public decimal PesoKg { get; set; }
    [Required, Range(80, 230)] public decimal AlturaCm { get; set; }
    [Required, Range(1, int.MaxValue)] public int NivelActividadId { get; set; }
    [Required, Range(1, int.MaxValue)] public int ObjetivoId { get; set; }
    public bool Activo { get; set; } = true;
    /// <summary>Opcional al crear: crea la cuenta de acceso del estudiante.</summary>
    [EmailAddress, MaxLength(150)] public string? Correo { get; set; }
    [MaxLength(100)] public string? Password { get; set; }
}

/// <summary>HU-10 – El estudiante actualiza sus datos físicos y objetivo.</summary>
public sealed class DatosFisicosRequest
{
    [Required, Range(10, 300)] public decimal PesoKg { get; set; }
    [Required, Range(80, 230)] public decimal AlturaCm { get; set; }
    [Required, Range(1, int.MaxValue)] public int NivelActividadId { get; set; }
    [Required, Range(1, int.MaxValue)] public int ObjetivoId { get; set; }
}

public sealed record DiaReporteDto(DateOnly Fecha, decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas,
    decimal Azucares, decimal SodioMg, decimal? HorasSueno, int? AguaMl, int? MinutosActividad);

public sealed record ReporteSemanalDto(
    int EstudianteId, string Estudiante, string Curso, DateOnly Desde, DateOnly Hasta,
    decimal Imc, string CategoriaImc, decimal CaloriasObjetivo,
    IReadOnlyList<DiaReporteDto> Dias,
    decimal PromedioCalorias, decimal PromedioAguaMl, decimal PromedioSueno, decimal PromedioActividad,
    decimal PorcentajeCumplimiento, int DiasConRegistro, int AlertasSemana, IReadOnlyList<string> Conclusiones);

public sealed record ConteoDto(string Etiqueta, int Cantidad);

public sealed record DashboardDto(
    int TotalEstudiantes, int RegistraronHoy, int AlertasPendientes, int CitasProximas,
    IReadOnlyList<ConteoDto> PorCategoriaImc, IReadOnlyList<ConteoDto> AlertasPorTipo,
    IReadOnlyList<AlertaDto> UltimasAlertas, IReadOnlyList<CitaDto> ProximasCitas,
    IReadOnlyList<EstudianteRiesgoDto> EstudiantesRiesgo);

public sealed record EstudianteRiesgoDto(int Id, string Estudiante, string Curso, decimal Imc, string CategoriaImc, int AlertasPendientes);

public sealed record MiResumenDto(
    int EstudianteId, string Nombre, decimal Imc, string CategoriaImc, decimal CaloriasObjetivo,
    decimal CaloriasHoy, int AguaHoyMl, decimal? SuenoHoy, int? ActividadHoy,
    int? UltimaRecomendacionId, CitaDto? ProximaCita, int NotificacionesNoLeidas, int AlertasPendientes,
    IReadOnlyList<DiaReporteDto> UltimosDias);
