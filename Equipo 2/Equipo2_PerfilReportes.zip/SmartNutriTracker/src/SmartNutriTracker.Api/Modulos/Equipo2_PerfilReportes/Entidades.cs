// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Data.Entities;

public class NivelActividad
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public decimal Factor { get; set; }
}

public class Curso
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public int? DocenteId { get; set; }

    public Usuario? Docente { get; set; }
}

public class Estudiante
{
    public int Id { get; set; }
    public int? UsuarioId { get; set; }
    public string Nombres { get; set; } = string.Empty;
    public string Apellidos { get; set; } = string.Empty;
    public DateOnly FechaNacimiento { get; set; }
    public string Sexo { get; set; } = "M";
    public int CursoId { get; set; }
    public decimal PesoKg { get; set; }
    public decimal AlturaCm { get; set; }
    public int NivelActividadId { get; set; }
    public int ObjetivoId { get; set; }
    public bool Activo { get; set; } = true;
    public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;

    public Usuario? Usuario { get; set; }
    public Curso? Curso { get; set; }
    public NivelActividad? NivelActividad { get; set; }
    public ObjetivoNutricional? Objetivo { get; set; }

    public string NombreCompleto => $"{Nombres} {Apellidos}";
}

public class MedicionEstudiante
{
    public int Id { get; set; }
    public int EstudianteId { get; set; }
    public DateOnly Fecha { get; set; }
    public decimal PesoKg { get; set; }
    public decimal AlturaCm { get; set; }
}
