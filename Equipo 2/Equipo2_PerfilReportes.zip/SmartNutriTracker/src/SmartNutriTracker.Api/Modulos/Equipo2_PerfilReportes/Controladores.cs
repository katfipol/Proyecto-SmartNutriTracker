// EQUIPO 2 – Perfil y Reportes
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 2 – HU-08 a HU-10: estudiantes y perfil nutricional.</summary>
[ApiController]
[Route("api/estudiantes")]
[Authorize]
[Produces("application/json")]
public class EstudiantesController(IEstudiantesService servicio) : ControllerBase
{
    [HttpGet]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<IReadOnlyList<EstudianteResumenDto>>> Listar(
        [FromQuery] string? buscar, [FromQuery] int? cursoId, [FromQuery] bool incluirInactivos = false, CancellationToken ct = default) =>
        Ok(await servicio.ListarAsync(buscar, cursoId, incluirInactivos, ct));

    /// <summary>HU-09 – Perfil del estudiante autenticado.</summary>
    [HttpGet("mi-perfil")]
    [Authorize(Roles = Roles.Estudiante)]
    public async Task<ActionResult<EstudiantePerfilDto>> MiPerfil(CancellationToken ct) => Ok(await servicio.MiPerfilAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<EstudiantePerfilDto>> Perfil(int id, CancellationToken ct) => Ok(await servicio.PerfilAsync(id, ct));

    /// <summary>HU-08 – Registrar estudiante (opcionalmente con su cuenta de acceso).</summary>
    [HttpPost]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<EstudiantePerfilDto>> Crear([FromBody] EstudianteRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.CrearAsync(request, ct));

    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<EstudiantePerfilDto>> Actualizar(int id, [FromBody] EstudianteRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarAsync(id, request, ct));

    /// <summary>HU-10 – Actualizar datos físicos y objetivo.</summary>
    [HttpPut("{id:int}/datos-fisicos")]
    public async Task<ActionResult<EstudiantePerfilDto>> DatosFisicos(int id, [FromBody] DatosFisicosRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarDatosFisicosAsync(id, request, ct));

    /// <summary>HU-25 – Alimentos que el estudiante no consume (alergias, gustos).</summary>
    [HttpPut("{id:int}/excluidos")]
    public async Task<ActionResult<EstudiantePerfilDto>> Excluidos(int id, [FromBody] List<AlimentoExcluidoRequest> request, CancellationToken ct) =>
        Ok(await servicio.ActualizarExcluidosAsync(id, request, ct));

    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Desactivar(int id, CancellationToken ct)
    {
        await servicio.DesactivarAsync(id, ct);
        return NoContent();
    }
}

/// <summary>EQUIPO 2 – HU-11 / HU-12: reportes y dashboard.</summary>
[ApiController]
[Route("api/reportes")]
[Authorize]
[Produces("application/json")]
public class ReportesController(IReportesService servicio) : ControllerBase
{
    /// <summary>HU-11 – Reporte de los 7 días que terminan en 'hasta' (por defecto hoy).</summary>
    [HttpGet("estudiante/{estudianteId:int}/semanal")]
    public async Task<ActionResult<ReporteSemanalDto>> Semanal(int estudianteId, [FromQuery] DateOnly? hasta, CancellationToken ct) =>
        Ok(await servicio.SemanalAsync(estudianteId, hasta, ct));

    /// <summary>HU-12 – Dashboard general (personal del colegio).</summary>
    [HttpGet("dashboard")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<DashboardDto>> Dashboard(CancellationToken ct) => Ok(await servicio.DashboardAsync(ct));

    /// <summary>Resumen del día para el estudiante autenticado.</summary>
    [HttpGet("mi-resumen")]
    [Authorize(Roles = Roles.Estudiante)]
    public async Task<ActionResult<MiResumenDto>> MiResumen(CancellationToken ct) => Ok(await servicio.MiResumenAsync(ct));
}
