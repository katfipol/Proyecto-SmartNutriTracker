// NÚCLEO COMÚN (lo comparten todos los equipos)
// SmartNutriTracker · Colegio Innovare
// Aporte original: Equipo 1
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface ICatalogosService
{
    Task<CatalogosDto> ObtenerAsync(CancellationToken ct = default);
    /// <summary>Estudiantes que el usuario puede ver (para los selectores de todas las pantallas).</summary>
    Task<IReadOnlyList<EstudianteOpcionDto>> EstudiantesAsync(CancellationToken ct = default);
    /// <summary>Alimentos activos (para registros, menús y alimentos excluidos).</summary>
    Task<IReadOnlyList<AlimentoDto>> AlimentosAsync(CancellationToken ct = default);
}

public class CatalogosService(SmartNutriDbContext db, IAccesoService acceso) : ICatalogosService
{
    public async Task<IReadOnlyList<EstudianteOpcionDto>> EstudiantesAsync(CancellationToken ct = default) =>
        await acceso.EstudiantesVisibles().AsNoTracking().Where(e => e.Activo)
            .OrderBy(e => e.Apellidos).ThenBy(e => e.Nombres)
            .Select(e => new EstudianteOpcionDto(e.Id, e.Nombres + " " + e.Apellidos, e.Curso!.Nombre))
            .ToListAsync(ct);

    public async Task<IReadOnlyList<AlimentoDto>> AlimentosAsync(CancellationToken ct = default) =>
        (await db.Alimentos.AsNoTracking().Include(a => a.CategoriaAlimento).Where(a => a.Activo).OrderBy(a => a.Nombre).ToListAsync(ct))
            .Select(Mapeos.ADto).ToList();

    public async Task<CatalogosDto> ObtenerAsync(CancellationToken ct = default)
    {
        var cursos = await db.Cursos.AsNoTracking().OrderBy(c => c.Nombre)
            .Select(c => new CursoDto(c.Id, c.Nombre, c.DocenteId, c.Docente != null ? c.Docente.Nombre : null)).ToListAsync(ct);
        var niveles = await db.NivelesActividad.AsNoTracking().OrderBy(n => n.Factor)
            .Select(n => new NivelActividadDto(n.Id, n.Codigo, n.Nombre, n.Factor)).ToListAsync(ct);
        var objetivos = await db.ObjetivosNutricionales.AsNoTracking().OrderBy(o => o.Id)
            .Select(o => new OpcionDto(o.Id, o.Nombre, o.Codigo)).ToListAsync(ct);
        var categorias = await db.CategoriasAlimento.AsNoTracking().OrderBy(c => c.Nombre)
            .Select(c => new OpcionDto(c.Id, c.Nombre, c.Codigo)).ToListAsync(ct);
        var tipos = await db.TiposComida.AsNoTracking().OrderBy(t => t.Orden)
            .Select(t => new TipoComidaDto(t.Id, t.Nombre, t.Orden, t.PorcentajeCalorias)).ToListAsync(ct);
        var nutricionistas = await db.Usuarios.AsNoTracking().Where(u => u.Activo && u.Rol!.Nombre == Roles.Nutricionista)
            .OrderBy(u => u.Nombre).Select(u => new OpcionDto(u.Id, u.Nombre, null)).ToListAsync(ct);
        var docentes = await db.Usuarios.AsNoTracking().Where(u => u.Activo && u.Rol!.Nombre == Roles.Docente)
            .OrderBy(u => u.Nombre).Select(u => new OpcionDto(u.Id, u.Nombre, null)).ToListAsync(ct);

        return new CatalogosDto(Roles.Lista, cursos, niveles, objetivos, categorias, tipos, nutricionistas, docentes);
    }
}
