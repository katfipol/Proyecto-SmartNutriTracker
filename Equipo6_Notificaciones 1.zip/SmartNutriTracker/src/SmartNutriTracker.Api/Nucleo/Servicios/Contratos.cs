// NÚCLEO COMÚN (lo comparten todos los equipos)
// SmartNutriTracker · Colegio Innovare
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Services;

// =====================================================================
// Contratos entre módulos. Permiten que un módulo use a otro SIN depender
// de que esté instalado: si falta, se usa la implementación por defecto.
// =====================================================================

/// <summary>
/// Evaluación de alertas de hábitos (la implementa el Equipo 6).
/// Por defecto no hace nada: los Equipos 2 y 4 funcionan aunque el Equipo 6 no esté.
/// </summary>
public interface IEvaluadorAlertas
{
    Task<int> EvaluarDiaAsync(int estudianteId, DateOnly fecha, bool diaCerrado, CancellationToken ct = default);
    Task<int> EvaluarImcAsync(int estudianteId, CancellationToken ct = default);
}

public sealed class EvaluadorAlertasInactivo : IEvaluadorAlertas
{
    public Task<int> EvaluarDiaAsync(int estudianteId, DateOnly fecha, bool diaCerrado, CancellationToken ct = default) => Task.FromResult(0);
    public Task<int> EvaluarImcAsync(int estudianteId, CancellationToken ct = default) => Task.FromResult(0);
}

/// <summary>Envía notificaciones internas (tabla Notificaciones). La usan los Equipos 5 y 6.</summary>
public interface INotificador
{
    Task CrearAsync(IEnumerable<int> usuarioIds, string titulo, string mensaje, string tipo, CancellationToken ct = default);
}

public class Notificador(SmartNutriDbContext db) : INotificador
{
    public async Task CrearAsync(IEnumerable<int> usuarioIds, string titulo, string mensaje, string tipo, CancellationToken ct = default)
    {
        var ids = usuarioIds.Distinct().ToList();
        if (ids.Count == 0) return;
        db.Notificaciones.AddRange(ids.Select(id => new Notificacion
        {
            UsuarioId = id,
            Titulo = titulo.Length > 100 ? titulo[..100] : titulo,
            Mensaje = mensaje.Length > 400 ? mensaje[..400] : mensaje,
            Tipo = tipo,
            Leida = false,
            FechaCreacion = DateTime.UtcNow
        }));
        await db.SaveChangesAsync(ct);
    }
}
