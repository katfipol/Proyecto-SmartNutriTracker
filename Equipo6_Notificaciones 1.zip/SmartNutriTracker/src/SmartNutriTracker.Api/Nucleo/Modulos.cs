// NÚCLEO COMÚN (lo comparten todos los equipos)
// SmartNutriTracker · Colegio Innovare
using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ActionConstraints;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace SmartNutriTracker.Api.Common;

/// <summary>
/// Contrato que implementa cada módulo (Modulos/EquipoN/Modulo.cs).
/// Program.cs busca todas las clases que lo implementan y las registra: si la carpeta
/// de un equipo no está, su módulo simplemente no se carga y el resto sigue funcionando.
/// </summary>
public interface IModulo
{
    int Numero { get; }
    string Nombre { get; }
    string HistoriasUsuario { get; }
    void RegistrarServicios(IServiceCollection servicios, IConfiguration configuracion);
}

/// <summary>Marca a qué módulo pertenece un controlador (0 = núcleo).</summary>
[AttributeUsage(AttributeTargets.Class)]
public sealed class ModuloAttribute(int numero) : Attribute
{
    public int Numero { get; } = numero;
}

public static class CargadorModulos
{
    /// <summary>Encuentra los módulos presentes en el proyecto, en orden.</summary>
    public static IReadOnlyList<IModulo> Descubrir() =>
        typeof(CargadorModulos).Assembly.GetTypes()
            .Where(t => typeof(IModulo).IsAssignableFrom(t) && t is { IsClass: true, IsAbstract: false })
            .Select(t => (IModulo)Activator.CreateInstance(t)!)
            .OrderBy(m => m.Numero)
            .ToList();
}

public sealed record EndpointDto(string Metodo, string Ruta);
public sealed record ModuloDto(int Numero, string Nombre, string HistoriasUsuario, IReadOnlyList<EndpointDto> Endpoints);

/// <summary>Módulos instalados y sus endpoints: lo usa el frontend para armar el menú y la pantalla de avance.</summary>
[ApiController]
[Route("api/modulos")]
[Authorize]
[Modulo(0)]
[Produces("application/json")]
public class ModulosController(IEnumerable<IModulo> modulos, IActionDescriptorCollectionProvider acciones) : ControllerBase
{
    [HttpGet]
    public ActionResult<IReadOnlyList<ModuloDto>> Listar()
    {
        var endpoints = acciones.ActionDescriptors.Items.OfType<ControllerActionDescriptor>()
            .Select(a => new
            {
                Modulo = a.ControllerTypeInfo.GetCustomAttribute<ModuloAttribute>()?.Numero ?? 0,
                Endpoint = new EndpointDto(
                    a.ActionConstraints?.OfType<HttpMethodActionConstraint>().FirstOrDefault()?.HttpMethods.FirstOrDefault() ?? "GET",
                    "/" + (a.AttributeRouteInfo?.Template ?? string.Empty).Replace(":int", string.Empty))
            })
            .ToList();

        var lista = new List<ModuloDto>
        {
            new(0, "Núcleo común", "Login, roles, base de datos y estructura",
                endpoints.Where(e => e.Modulo == 0).Select(e => e.Endpoint).OrderBy(e => e.Ruta).ToList())
        };
        lista.AddRange(modulos.Select(m => new ModuloDto(m.Numero, m.Nombre, m.HistoriasUsuario,
            endpoints.Where(e => e.Modulo == m.Numero).Select(e => e.Endpoint).OrderBy(e => e.Ruta).ToList())));
        return Ok(lista);
    }
}
