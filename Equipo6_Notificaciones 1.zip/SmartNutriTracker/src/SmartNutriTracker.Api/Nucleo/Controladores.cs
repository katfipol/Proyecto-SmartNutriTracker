// NÚCLEO COMÚN (lo comparten todos los equipos)
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 1 – HU-02 / HU-03: inicio de sesión y token JWT.</summary>
[ApiController]
[Route("api/auth")]
[Modulo(0)]
[Produces("application/json")]
public class AuthController(IAuthService servicio) : ControllerBase
{
    /// <summary>Inicia sesión con correo y contraseña. Devuelve el token JWT.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting("login")]
    [ProducesResponseType<LoginResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request, CancellationToken ct) =>
        Ok(await servicio.LoginAsync(request, ct));

    /// <summary>Datos del usuario autenticado.</summary>
    [HttpGet("perfil")]
    [Authorize]
    public async Task<ActionResult<UsuarioActualDto>> Perfil(CancellationToken ct) => Ok(await servicio.PerfilAsync(ct));

    /// <summary>Cambia la contraseña del usuario autenticado.</summary>
    [HttpPost("cambiar-password")]
    [Authorize]
    public async Task<ActionResult<MensajeDto>> CambiarPassword([FromBody] CambiarPasswordRequest request, CancellationToken ct)
    {
        await servicio.CambiarPasswordAsync(request, ct);
        return Ok(new MensajeDto("Contraseña actualizada correctamente."));
    }
}

/// <summary>Catálogos para los formularios.</summary>
[ApiController]
[Route("api/catalogos")]
[Modulo(0)]
[Authorize]
[Produces("application/json")]
public class CatalogosController(ICatalogosService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CatalogosDto>> Obtener(CancellationToken ct) => Ok(await servicio.ObtenerAsync(ct));

    /// <summary>Estudiantes visibles para el usuario (selectores).</summary>
    [HttpGet("estudiantes")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<IReadOnlyList<EstudianteOpcionDto>>> Estudiantes(CancellationToken ct) => Ok(await servicio.EstudiantesAsync(ct));

    /// <summary>Alimentos activos (selectores de registro, menús y exclusiones).</summary>
    [HttpGet("alimentos")]
    public async Task<ActionResult<IReadOnlyList<AlimentoDto>>> Alimentos(CancellationToken ct) => Ok(await servicio.AlimentosAsync(ct));
}
