// NÚCLEO COMÚN (lo comparten todos los equipos)
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

// Aporte del Equipo 3
public sealed record AlimentoDto(
    int Id, string Nombre, int CategoriaAlimentoId, string Categoria, string CategoriaCodigo, string PorcionDescripcion,
    decimal PorcionGramos, decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas,
    decimal Fibra, decimal Azucares, decimal SodioMg, bool Activo);

// Aporte del Equipo 3
public sealed record ItemComidaDto(int Id, int AlimentoId, string Alimento, string Categoria, string Porcion, decimal Porciones,
    decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas);

// Aporte del Equipo 3
public sealed record ComidaDto(int TipoComidaId, string TipoComida, int Orden, decimal Calorias, decimal Proteinas,
    decimal Carbohidratos, decimal Grasas, IReadOnlyList<ItemComidaDto> Items);

// Aporte del Equipo 3
public sealed record ResumenNutricionalDto(decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas,
    decimal PctProteina, decimal PctCarbohidratos, decimal PctGrasas, string Evaluacion);

// Aporte del Equipo 5
public sealed record CalculoNutricionalDto(
    decimal Imc, string CategoriaImc, decimal Tmb, decimal FactorActividad, decimal GastoEnergeticoTotal,
    string ObjetivoSolicitado, string ObjetivoAplicado, decimal CaloriasObjetivo, decimal ProteinasG,
    decimal CarbohidratosG, decimal GrasasG, IReadOnlyList<string> Observaciones);

// Aporte del Equipo 5
public sealed record AlimentoExcluidoDto(int AlimentoId, string Alimento, string? Motivo);

// Aporte del Equipo 6
public sealed record AlertaDto(int Id, int EstudianteId, string Estudiante, string Curso, string Tipo, string Codigo, string Nivel,
    DateOnly Fecha, decimal ValorRegistrado, string Mensaje, bool Atendida, string? AtendidaPor, DateTime? FechaAtencion);

// Aporte del Equipo 6
public sealed record CitaDto(int Id, int EstudianteId, string Estudiante, int NutricionistaId, string Nutricionista,
    DateTime FechaHora, int DuracionMinutos, string Motivo, string Estado, string? Notas);
