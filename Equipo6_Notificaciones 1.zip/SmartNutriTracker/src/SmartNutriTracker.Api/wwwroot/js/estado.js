// NÚCLEO – Estado compartido de la aplicación
import { api } from './api.js';
import { esc, opciones } from './ui.js';

export const estado = {
  usuario: null,       // { id, nombre, correo, rol, estudianteId }
  catalogos: null,     // CatalogosDto
  modulos: [],         // ModuloDto[] instalados (incluye el núcleo, numero 0)
  estudiantes: null,   // EstudianteOpcionDto[] (solo personal)
  /** ¿Está instalado el módulo del equipo n en esta copia del proyecto? */
  tieneModulo(n) { return this.modulos.some(m => m.numero === n); }
};

/** Los 6 módulos del proyecto (pantalla "Estado del proyecto"). Las HU con * están implementadas en el núcleo. */
export const MODULOS = [
  { numero: 1, nombre: 'Autenticación y Seguridad', hu: ['HU-01 Registrar usuarios', '*HU-02 Iniciar sesión', '*HU-03 Sesión JWT', '*HU-04 Gestión de roles', 'HU-05 Auditoría'] },
  { numero: 2, nombre: 'Perfil y Reportes', hu: ['HU-08 Registro de estudiantes', 'HU-09 Ver perfil', 'HU-10 Editar perfil', 'HU-11 Reporte semanal', 'HU-12 Dashboard general'] },
  { numero: 3, nombre: 'Gestión de Alimentos', hu: ['HU-14 Registro de alimentos', 'HU-15 Editar/eliminar alimentos', 'HU-16 Crear menú diario', 'HU-17 Resumen nutricional'] },
  { numero: 4, nombre: 'Registro de Hábitos', hu: ['HU-19 Consumo real', 'HU-20 Hábitos diarios', 'HU-21 Historial', 'HU-22 Actualizar registro'] },
  { numero: 5, nombre: 'Recomendaciones Inteligentes', hu: ['HU-23 Recomendación de menú', 'HU-24 Modelo según IMC', 'HU-25 Ajuste por objetivos', '*HU-26 Cálculo nutricional'] },
  { numero: 6, nombre: 'Notificaciones y Testing', hu: ['HU-27 Alertas de hábitos', 'HU-28 Notificaciones y recordatorios', '*HU-29 Logs globales', '*HU-32 Swagger', 'HU-30/31 Pruebas y CI/CD'] }
];

export const esRol = (...roles) => roles.includes(estado.usuario?.rol);
export const esPersonal = () => esRol('Admin', 'Docente', 'Nutricionista');
export const esSalud = () => esRol('Admin', 'Nutricionista');

export async function cargarEstudiantes(forzar = false) {
  if (!esPersonal()) return [];
  if (!estado.estudiantes || forzar) estado.estudiantes = await api.get('/api/catalogos/estudiantes');
  return estado.estudiantes;
}

const CLAVE_SEL = 'snt_estudiante_sel';

/**
 * Devuelve el id de estudiante a usar en la vista:
 * el propio (rol Estudiante) o el seleccionado (personal).
 */
export function estudianteSeleccionado(params) {
  if (estado.usuario.rol === 'Estudiante') return estado.usuario.estudianteId;
  const deRuta = params?.get?.('estudiante');
  if (deRuta) { sessionStorage.setItem(CLAVE_SEL, deRuta); return parseInt(deRuta, 10); }
  const guardado = sessionStorage.getItem(CLAVE_SEL);
  if (guardado && estado.estudiantes?.some(e => String(e.id) === guardado)) return parseInt(guardado, 10);
  return estado.estudiantes?.[0]?.id ?? null;
}

export function recordarEstudiante(id) { sessionStorage.setItem(CLAVE_SEL, String(id)); }

/** HTML del selector de estudiante (solo personal). */
export function htmlSelectorEstudiante(id) {
  if (estado.usuario.rol === 'Estudiante') return '';
  const lista = (estado.estudiantes || []).map(e => ({ id: e.id, nombre: `${e.nombreCompleto} · ${e.curso}` }));
  return `<div class="d-flex align-items-center gap-2">
    <label class="form-label mb-0 text-nowrap" for="sel-estudiante"><i class="bi bi-person"></i> Estudiante</label>
    <select class="form-select form-select-sm" id="sel-estudiante" style="min-width:260px">${opciones(lista, id)}</select></div>`;
}

export function engancharSelector(raiz, alCambiar) {
  const sel = raiz.querySelector('#sel-estudiante');
  sel?.addEventListener('change', () => { recordarEstudiante(sel.value); alCambiar(parseInt(sel.value, 10)); });
}

export const nombreEstudiante = (id) => esc(estado.estudiantes?.find(e => e.id === id)?.nombreCompleto ?? '');
