// NÚCLEO – Estado del proyecto: qué módulos están instalados en esta copia, sus HU, pantallas y endpoints.
// Sirve para que cada equipo vea su avance y, al juntar las partes, el avance de todo el sistema.
import { api } from '../api.js';
import { estado, MODULOS } from '../estado.js';
import { RUTAS_APP, rutasDisponibles } from '../app.js';
import { esc } from '../ui.js';

const COLOR_METODO = { GET: 'b-verde', POST: 'b-lima', PUT: 'b-ambar', PATCH: 'b-ambar', DELETE: 'b-coral' };

export async function render({ el }) {
  let salud = null;
  try { salud = await api.get('/api/salud'); } catch { /* sin conexión */ }

  const instalados = MODULOS.filter(m => estado.tieneModulo(m.numero));
  const nucleo = estado.modulos.find(m => m.numero === 0);
  const totalEndpoints = estado.modulos.reduce((s, m) => s + m.endpoints.length, 0);
  const pct = Math.round(instalados.length / MODULOS.length * 100);
  const disponibles = new Set(rutasDisponibles().map(r => r.ruta));

  const endpoints = (lista) => lista.length ? `
    <details class="mt-2"><summary class="small fw-semibold" style="cursor:pointer;color:var(--snt-800)">${lista.length} endpoint(s) de la API</summary>
      <div class="mt-2" style="max-height:220px;overflow:auto">${lista.map(e =>
        `<div class="small py-1 d-flex gap-2"><span class="badge ${COLOR_METODO[e.metodo] || 'b-gris'}" style="min-width:58px">${esc(e.metodo)}</span><code>${esc(e.ruta)}</code></div>`).join('')}
      </div></details>` : '';

  const tarjeta = (m) => {
    const inst = estado.tieneModulo(m.numero);
    const datos = estado.modulos.find(x => x.numero === m.numero);
    const pantallas = RUTAS_APP.filter(r => r.modulo === m.numero && r.seccion);
    return `
      <div class="col-md-6 col-xl-4"><div class="tarjeta h-100 ${inst ? '' : 'opacity-75'}" style="${inst ? 'border-top:4px solid var(--snt-600)' : 'border-top:4px solid #cfd8d3'}">
        <div class="cuerpo pt-3">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div><div class="small muted">Equipo ${m.numero}</div><h5 class="fw-bold mb-0">${esc(m.nombre)}</h5></div>
            ${inst ? '<span class="badge b-verde"><i class="bi bi-check-circle me-1"></i>Instalado</span>' : '<span class="badge b-gris">No incluido</span>'}
          </div>
          <div class="small fw-semibold mt-3 mb-1" style="color:var(--snt-900)">Historias de usuario</div>
          ${m.hu.map(h => {
            const enNucleo = h.startsWith('*');
            const lista = inst || enNucleo;
            return `<div class="small"><i class="bi ${lista ? 'bi-check2-square' : 'bi-square'} me-1" style="color:${lista ? 'var(--snt-700)' : '#9aa9a1'}"></i>${esc(h.replace('*', ''))}${enNucleo ? ' <span class="badge b-oscuro" style="font-size:.62rem">núcleo</span>' : ''}</div>`;
          }).join('')}
          ${pantallas.length ? `<div class="small fw-semibold mt-3 mb-1" style="color:var(--snt-900)">Pantallas</div>
            <div class="d-flex flex-wrap gap-1">${pantallas.map(r => inst && disponibles.has(r.ruta)
              ? `<a href="#/${r.ruta}" class="badge b-lima text-decoration-none"><i class="bi ${r.icono} me-1"></i>${esc(r.titulo)}</a>`
              : `<span class="badge b-gris"><i class="bi ${r.icono} me-1"></i>${esc(r.titulo)}</span>`).join('')}</div>` : ''}
          ${inst ? endpoints(datos.endpoints) : '<div class="small muted mt-3">Para incluirlo, copie la carpeta <code>Modulos/Equipo' + m.numero + '_…</code> y sus vistas: el sistema lo detecta solo.</div>'}
        </div></div></div>`;
  };

  el.innerHTML = `
    <div class="tarjeta p-4 mb-4" style="background:linear-gradient(135deg,var(--snt-900),var(--snt-700));color:#fff;border:none">
      <div class="row g-3 align-items-center">
        <div class="col-lg-7">
          <h3 class="fw-bold mb-1"><i class="bi bi-kanban me-2"></i>Estado del proyecto</h3>
          <div style="color:var(--snt-100)">Esta copia de SmartNutriTracker tiene <strong>${instalados.length} de ${MODULOS.length}</strong> módulos instalados
            ${instalados.length ? `(${instalados.map(m => 'Equipo ' + m.numero).join(', ')})` : '(solo el núcleo)'}.</div>
          <div class="progreso mt-3" style="background:rgba(255,255,255,.2);height:12px"><div style="width:${pct}%;background:var(--snt-lima)"></div></div>
          <div class="small mt-1" style="color:var(--snt-200)">${pct}% de los módulos · ${totalEndpoints} endpoints activos</div>
        </div>
        <div class="col-lg-5">
          <div class="d-flex flex-column gap-2 small">
            <div><i class="bi bi-database me-2"></i>Base de datos: ${salud?.baseDeDatos ? '<span class="badge b-lima">Conectada</span>' : '<span class="badge b-coral">Sin conexión</span>'}</div>
            <div><i class="bi bi-person-badge me-2"></i>Sesión: ${esc(estado.usuario.nombre)} (${esc(estado.usuario.rol)})</div>
            <div><i class="bi bi-file-earmark-code me-2"></i>Documentación de la API: <a href="/swagger" target="_blank" class="link-light">/swagger</a></div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-6 col-xl-4"><div class="tarjeta h-100" style="border-top:4px solid var(--snt-900)"><div class="cuerpo pt-3">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <div><div class="small muted">Base compartida</div><h5 class="fw-bold mb-0">Núcleo común</h5></div>
          <span class="badge b-oscuro">Siempre incluido</span></div>
        <div class="small">Lo tienen todos los ZIP. Incluye el login y los roles, la base de datos completa, el cálculo nutricional, los catálogos, los logs y la estructura del frontend.</div>
        ${endpoints(nucleo?.endpoints ?? [])}
      </div></div></div>
      ${MODULOS.map(tarjeta).join('')}
    </div>`;
}
