// NÚCLEO – Aplicación principal: sesión, menú según los módulos instalados y enrutador
// Cada pantalla se carga bajo demanda (import dinámico): si el módulo de un equipo no está
// en esta copia del proyecto, sus opciones simplemente no aparecen en el menú.
import { api, sesion } from './api.js';
import { estado, MODULOS } from './estado.js';
import { cargando, errorHtml, esc, iniciales, destruirGraficos } from './ui.js';

const TODOS = ['Admin', 'Docente', 'Nutricionista', 'Estudiante'];
const PERSONAL = ['Admin', 'Docente', 'Nutricionista'];

// ruta · título · icono · roles · módulo (0 = núcleo) · archivo de la vista · sección del menú (null = oculta)
const RUTAS = [
  { ruta: 'inicio', titulo: 'Inicio', icono: 'bi-house', roles: TODOS, modulo: 2, archivo: 'inicio.js', seccion: 'General' },
  { ruta: 'registro', titulo: 'Registro diario', tituloEst: 'Mi registro diario', icono: 'bi-journal-check', roles: TODOS, modulo: 4, archivo: 'registro.js', seccion: 'General' },
  { ruta: 'perfil', titulo: 'Mi perfil', icono: 'bi-person-heart', roles: ['Estudiante'], modulo: 2, archivo: 'perfil.js', seccion: 'General' },
  { ruta: 'recomendaciones', titulo: 'Recomendaciones', tituloEst: 'Mis recomendaciones', icono: 'bi-stars', roles: TODOS, modulo: 5, archivo: 'recomendaciones.js', seccion: 'General' },
  { ruta: 'reportes', titulo: 'Reporte semanal', tituloEst: 'Mi reporte semanal', icono: 'bi-graph-up', roles: TODOS, modulo: 2, archivo: 'reportes.js', seccion: 'General' },
  { ruta: 'citas', titulo: 'Citas', tituloEst: 'Mis citas', icono: 'bi-calendar2-heart', roles: TODOS, modulo: 6, archivo: 'citas.js', seccion: 'General' },
  { ruta: 'estudiantes', titulo: 'Estudiantes', icono: 'bi-people', roles: PERSONAL, modulo: 2, archivo: 'estudiantes.js', seccion: 'Seguimiento' },
  { ruta: 'alertas', titulo: 'Alertas', icono: 'bi-exclamation-triangle', roles: PERSONAL, modulo: 6, archivo: 'alertas.js', seccion: 'Seguimiento' },
  { ruta: 'alimentos', titulo: 'Alimentos', icono: 'bi-basket', roles: TODOS, modulo: 3, archivo: 'alimentos.js', seccion: 'Nutrición' },
  { ruta: 'menus', titulo: 'Menús diarios', icono: 'bi-card-list', roles: PERSONAL, modulo: 3, archivo: 'menus.js', seccion: 'Nutrición' },
  { ruta: 'reglas', titulo: 'Reglas nutricionales', icono: 'bi-sliders', roles: PERSONAL, modulo: 5, archivo: 'reglas.js', seccion: 'Configuración' },
  { ruta: 'usuarios', titulo: 'Usuarios', icono: 'bi-person-gear', roles: ['Admin'], modulo: 1, archivo: 'usuarios.js', seccion: 'Configuración' },
  { ruta: 'auditoria', titulo: 'Auditoría', icono: 'bi-shield-check', roles: ['Admin'], modulo: 1, archivo: 'auditoria.js', seccion: 'Configuración' },
  { ruta: 'proyecto', titulo: 'Estado del proyecto', icono: 'bi-kanban', roles: TODOS, modulo: 0, archivo: 'proyecto.js', seccion: 'Proyecto' },
  { ruta: 'notificaciones', titulo: 'Notificaciones', icono: 'bi-bell', roles: TODOS, modulo: 6, archivo: 'notificaciones.js', seccion: null },
  { ruta: 'cuenta', titulo: 'Cambiar contraseña', icono: 'bi-key', roles: TODOS, modulo: 0, archivo: 'cuenta.js', seccion: null },
  { ruta: 'estudiante', titulo: 'Perfil del estudiante', icono: 'bi-person', roles: PERSONAL, modulo: 2, archivo: 'perfil.js', seccion: null }
];
export const RUTAS_APP = RUTAS;

const vista = document.getElementById('vista');
const titulo = document.getElementById('titulo');

async function iniciar() {
  if (!sesion.valida()) { window.location.replace('index.html'); return; }
  vista.innerHTML = cargando('Preparando tu espacio...');
  try {
    estado.usuario = await api.get('/api/auth/perfil');
    estado.catalogos = await api.get('/api/catalogos');
    estado.modulos = await api.get('/api/modulos');
  } catch (e) {
    vista.innerHTML = errorHtml(e.message);
    return;
  }

  document.getElementById('nombre-usuario').textContent = estado.usuario.nombre;
  document.getElementById('rol-usuario').textContent = estado.usuario.rol;
  document.getElementById('avatar').textContent = iniciales(estado.usuario.nombre);
  document.querySelector('.sidebar .pie').textContent =
    `Colegio Innovare · ${estado.modulos.length - 1} de ${MODULOS.length} módulos`;
  construirMenu();

  const hayNotificaciones = estado.tieneModulo(6);
  document.querySelector('.campana').classList.toggle('d-none', !hayNotificaciones);

  document.getElementById('btn-salir').addEventListener('click', (ev) => {
    ev.preventDefault();
    sesion.cerrar();
    window.location.replace('index.html');
  });
  document.getElementById('btn-menu').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('abierto'));

  window.addEventListener('hashchange', navegar);
  if (hayNotificaciones) {
    window.addEventListener('snt:notificaciones', actualizarContador);
    actualizarContador();
    setInterval(actualizarContador, 60000);
  }
  await navegar();
}

/** Rutas permitidas para el rol y cuyo módulo está instalado. */
export function rutasDisponibles() {
  return RUTAS.filter(r => r.roles.includes(estado.usuario.rol) && (r.modulo === 0 || estado.tieneModulo(r.modulo)));
}

function construirMenu() {
  const esEst = estado.usuario.rol === 'Estudiante';
  let html = '';
  let seccionActual = null;
  rutasDisponibles().filter(r => r.seccion).forEach(r => {
    if (r.seccion !== seccionActual) { html += `<div class="seccion">${esc(r.seccion)}</div>`; seccionActual = r.seccion; }
    html += `<a class="item" href="#/${r.ruta}" data-ruta="${r.ruta}"><i class="bi ${r.icono}"></i>${esc(esEst && r.tituloEst ? r.tituloEst : r.titulo)}</a>`;
  });
  document.getElementById('menu').innerHTML = html;
}

async function navegar() {
  const inicio = estado.tieneModulo(2) ? 'inicio' : 'proyecto';
  const hash = location.hash.replace(/^#\/?/, '') || inicio;
  const [camino, consulta] = hash.split('?');
  const [nombre, id] = camino.split('/');
  const params = new URLSearchParams(consulta || '');
  const def = rutasDisponibles().find(r => r.ruta === nombre);

  document.getElementById('sidebar').classList.remove('abierto');
  document.querySelectorAll('#menu a.item').forEach(a =>
    a.classList.toggle('activo', a.dataset.ruta === (nombre === 'estudiante' ? 'estudiantes' : nombre)));

  destruirGraficos();
  if (!def) {
    const existe = RUTAS.find(r => r.ruta === nombre);
    titulo.textContent = 'No disponible';
    vista.innerHTML = existe && existe.modulo && !estado.tieneModulo(existe.modulo)
      ? errorHtml(`Esta pantalla pertenece al módulo del Equipo ${existe.modulo}, que no está incluido en esta copia del proyecto.`)
      : errorHtml('La página no existe o no tiene permisos para verla.');
    return;
  }
  const esEst = estado.usuario.rol === 'Estudiante';
  titulo.textContent = esEst && def.tituloEst ? def.tituloEst : def.titulo;
  document.title = `${titulo.textContent} · SmartNutriTracker`;
  vista.innerHTML = cargando();
  try {
    const modulo = await import(`./vistas/${def.archivo}`);
    await modulo.render({ el: vista, id: id ? parseInt(id, 10) : null, params, titulo: (t) => { titulo.textContent = t; } });
  } catch (e) {
    console.error(e);
    vista.innerHTML = errorHtml(e.message || 'Ocurrió un error al cargar la vista.');
  }
}

async function actualizarContador() {
  try {
    const { noLeidas } = await api.get('/api/notificaciones/contador');
    const el = document.getElementById('contador-notif');
    el.textContent = noLeidas > 99 ? '99+' : noLeidas;
    el.classList.toggle('d-none', noLeidas === 0);
  } catch { /* silencioso */ }
}

iniciar();
