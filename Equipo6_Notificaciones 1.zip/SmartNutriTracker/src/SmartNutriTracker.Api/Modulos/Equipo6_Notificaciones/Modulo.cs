// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Modulos;

/// <summary>
/// Registro del módulo del EQUIPO 6 – Notificaciones y Testing. Program.cs lo encuentra automáticamente:
/// si esta carpeta no está en el proyecto, el módulo no se carga y el resto del sistema sigue funcionando.
/// </summary>
public sealed class Modulo6 : IModulo
{
    public int Numero => 6;
    public string Nombre => "Notificaciones y Testing";
    public string HistoriasUsuario => "HU-27 a HU-29, HU-32";

    public void RegistrarServicios(IServiceCollection servicios, IConfiguration configuracion)
    {
        // Reemplaza el evaluador de alertas "inactivo" del núcleo por el real
        servicios.AddScoped<AlertasService>();
        servicios.AddScoped<IAlertasService>(sp => sp.GetRequiredService<AlertasService>());
        servicios.AddScoped<IEvaluadorAlertas>(sp => sp.GetRequiredService<AlertasService>());
        servicios.AddScoped<INotificacionesService, NotificacionesService>();
        servicios.AddScoped<ICitasService, CitasService>();
        servicios.Configure<RecordatoriosOptions>(configuracion.GetSection("Recordatorios"));
        servicios.AddHostedService<RecordatoriosBackgroundService>();
    }
}
