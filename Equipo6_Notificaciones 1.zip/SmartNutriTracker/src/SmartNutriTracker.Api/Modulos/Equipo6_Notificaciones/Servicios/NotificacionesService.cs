// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface INotificacionesService
{
    Task<IReadOnlyList<NotificacionDto>> ListarAsync(bool soloNoLeidas, CancellationToken ct = default);
    Task<ContadorDto> ContadorAsync(CancellationToken ct = default);
    Task MarcarLeidaAsync(int id, CancellationToken ct = default);
    Task MarcarTodasAsync(CancellationToken ct = default);
}

public class NotificacionesService(SmartNutriDbContext db, IUsuarioActual usuario) : INotificacionesService
{
    public async Task<IReadOnlyList<NotificacionDto>> ListarAsync(bool soloNoLeidas, CancellationToken ct = default)
    {
        var uid = usuario.Id;
        var q = db.Notificaciones.AsNoTracking().Where(n => n.UsuarioId == uid);
        if (soloNoLeidas) q = q.Where(n => !n.Leida);
        return await q.OrderByDescending(n => n.FechaCreacion).Take(100)
            .Select(n => new NotificacionDto(n.Id, n.Titulo, n.Mensaje, n.Tipo, n.Leida, n.FechaCreacion))
            .ToListAsync(ct);
    }

    public async Task<ContadorDto> ContadorAsync(CancellationToken ct = default)
    {
        var uid = usuario.Id;
        return new ContadorDto(await db.Notificaciones.CountAsync(n => n.UsuarioId == uid && !n.Leida, ct));
    }

    public async Task MarcarLeidaAsync(int id, CancellationToken ct = default)
    {
        var uid = usuario.Id;
        var n = await db.Notificaciones.FirstOrDefaultAsync(x => x.Id == id && x.UsuarioId == uid, ct)
                ?? throw new NoEncontradoException($"Notificación {id} no encontrada.");
        n.Leida = true;
        await db.SaveChangesAsync(ct);
    }

    public async Task MarcarTodasAsync(CancellationToken ct = default)
    {
        var uid = usuario.Id;
        var pendientes = await db.Notificaciones.Where(x => x.UsuarioId == uid && !x.Leida).ToListAsync(ct);
        pendientes.ForEach(n => n.Leida = true);
        await db.SaveChangesAsync(ct);
    }
}
