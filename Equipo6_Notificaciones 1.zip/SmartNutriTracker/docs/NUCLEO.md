# SmartNutriTracker · Núcleo común

El **núcleo** viene en los 6 ZIP y es idéntico en todos. Contiene lo que cualquier módulo necesita para ejecutarse:

- **Solución y proyecto:** `SmartNutriTracker.slnx`, `.csproj`, `Program.cs`, `appsettings.json`.
- **Seguridad:** login con JWT, roles, PBKDF2, bloqueo de cuenta, rate limiting, control de acceso por dato y auditoría.
- **Base de datos:** `SmartNutriDbContext` con las 26 tablas y el script completo `database/SmartNutriTracker_BD.sql`.
- **Lógica compartida:** cálculo nutricional, catálogos, notificador y logs.
- **Frontend:** login, estructura, estilos verdes, Bootstrap y Chart.js locales, y la pantalla **Estado del proyecto**.
- **Pruebas:** el proyecto de pruebas, con las del cálculo y las contraseñas.

## Cómo se integran los módulos
1. **Registro automático:** cada módulo tiene un `Modulos/EquipoN_…/Modulo.cs` que implementa `IModulo`. `Program.cs` los busca al iniciar y registra solo los que existen.
2. **Identificación de controladores:** los controladores llevan `[Modulo(N)]`, y `GET /api/modulos` informa qué módulos y endpoints están activos.
3. **Contratos entre módulos:** los módulos se comunican a través de contratos del núcleo, nunca directamente.
   - `IEvaluadorAlertas`: si el Equipo 6 no está, se usa `EvaluadorAlertasInactivo`, que no hace nada.
   - `INotificador`, `INutricionService`, `ICatalogosService`: siempre están en el núcleo.
4. **Frontend:** carga cada pantalla bajo demanda y muestra en el menú solo las de los módulos instalados.

## Endpoints del núcleo
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/api/auth/login` | Público | Inicia sesión con correo y contraseña. Devuelve el token JWT. |
| GET | `/api/auth/perfil` |  | Datos del usuario autenticado. |
| POST | `/api/auth/cambiar-password` |  | Cambia la contraseña del usuario autenticado. |
| GET | `/api/catalogos` | Autenticado | Obtener por id |
| GET | `/api/catalogos/estudiantes` | Admin, Docente, Nutricionista | Estudiantes visibles para el usuario (selectores). |
| GET | `/api/catalogos/alimentos` | Autenticado | Alimentos activos (selectores de registro, menús y exclusiones). |
| GET | `/api/modulos` | Autenticado | Módulos instalados y sus endpoints (Estado del proyecto) |
| GET | `/api/salud` | Público | Estado de la API y de la base de datos |

## Usuarios de prueba (contraseña `Innovare2026!`)

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |

## Archivos del núcleo
- `.github/workflows/ci.yml`
- `.gitignore`
- `README.md`
- `SmartNutriTracker.slnx`
- `database/Normalizacion_3FN.md`
- `database/SmartNutriTracker_BD.sql`
- `database/SmartNutriTracker_Esquema_Diagrama.sql`
- `src/SmartNutriTracker.Api/Nucleo/Comunes.cs`
- `src/SmartNutriTracker.Api/Nucleo/Contratos/Dtos.Compartidos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Contratos/Dtos.Seguridad.cs`
- `src/SmartNutriTracker.Api/Nucleo/Controladores.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo1.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo2.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo3.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo4.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo5.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo6.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/SmartNutriDbContext.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo1.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo2.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo3.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo4.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo5.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo6.cs`
- `src/SmartNutriTracker.Api/Nucleo/Dominio/CalculadoraNutricional.cs`
- `src/SmartNutriTracker.Api/Nucleo/Dominio/ModelosDominio.cs`
- `src/SmartNutriTracker.Api/Nucleo/Logs/ArchivoLogger.cs`
- `src/SmartNutriTracker.Api/Nucleo/Logs/ManejoErroresMiddleware.cs`
- `src/SmartNutriTracker.Api/Nucleo/Modulos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/AuditoriaService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/AuthService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/CatalogosService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/Contratos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/Mapeos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/NutricionService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/UsuarioActualYAcceso.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/UsuariosService.cs`
- `src/SmartNutriTracker.Api/Program.cs`
- `src/SmartNutriTracker.Api/Properties/launchSettings.json`
- `src/SmartNutriTracker.Api/SmartNutriTracker.Api.csproj`
- `src/SmartNutriTracker.Api/appsettings.Development.json`
- `src/SmartNutriTracker.Api/appsettings.json`
- `src/SmartNutriTracker.Api/wwwroot/app.html`
- `src/SmartNutriTracker.Api/wwwroot/css/app.css`
- `src/SmartNutriTracker.Api/wwwroot/img/logo.svg`
- `src/SmartNutriTracker.Api/wwwroot/index.html`
- `src/SmartNutriTracker.Api/wwwroot/js/api.js`
- `src/SmartNutriTracker.Api/wwwroot/js/app.js`
- `src/SmartNutriTracker.Api/wwwroot/js/estado.js`
- `src/SmartNutriTracker.Api/wwwroot/js/login.js`
- `src/SmartNutriTracker.Api/wwwroot/js/ui.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/cuenta.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/proyecto.js`
- `tests/SmartNutriTracker.Tests/CalculadoraNutricionalTests.cs`
- `tests/SmartNutriTracker.Tests/DatosPrueba.cs`
- `tests/SmartNutriTracker.Tests/PasswordHasherTests.cs`
- `tests/SmartNutriTracker.Tests/SmartNutriTracker.Tests.csproj`
- `src/SmartNutriTracker.Api/wwwroot/lib/` (Bootstrap, iconos y Chart.js locales)
