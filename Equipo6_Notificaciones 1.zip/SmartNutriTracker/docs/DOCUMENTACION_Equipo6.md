# SmartNutriTracker · Equipo 6 – Notificaciones y Testing

**Historias de usuario:** HU-27, HU-28, HU-29, HU-32 (+ HU-30 y HU-31)  
**Contenido del ZIP:** núcleo común + módulo del Equipo 6. **Se ejecuta solo**: no necesita los ZIP de los otros equipos.

---

## 1. Cómo ejecutar y ver el avance
1. **Base de datos:** en SSMS ejecute completo `database/SmartNutriTracker_BD.sql`, que crea la base con todas las tablas y los datos de prueba.
   - La base es compartida por todos los equipos.
   - Su parte del script está aparte en `database/por_equipo/6_Equipo6_Notificaciones.sql`.
2. **Conexión:** ajuste `ConnectionStrings:SmartNutriDb` en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
3. **Ejecutar:** abra **`SmartNutriTracker.slnx`** en Visual Studio y presione **F5**, o desde la carpeta raíz:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
4. **Abrir:** http://localhost:5200, e inicie sesión (por ejemplo `admin@innovare.edu.bo` / `Innovare2026!`).
5. **Ver el avance:** en el menú, **Proyecto → Estado del proyecto** muestra el módulo del equipo como **Instalado**, con sus HU, pantallas y endpoints.

**Qué verá con solo este ZIP:** Verá **Alertas**, **Citas** y **Notificaciones** (campana con contador). A los 10 segundos de iniciar, el servicio en segundo plano evalúa el día anterior y genera alertas con los datos de prueba.

**Pruebas:** ejecute `dotnet test`. Corren las del núcleo y las de este equipo.

## 2. Historias de usuario

| HU | Descripción | Implementación |
|---|---|---|
| HU-27 | Alertas de hábitos no saludables | `ReglasAlertas` + `AlertasService` (implementa `IEvaluadorAlertas` del núcleo) · pantalla Alertas · umbrales en `/api/reglas/alertas` |
| HU-28 | Notificaciones y recordatorios | Pantalla Notificaciones y campana, `RecordatoriosBackgroundService` (recordatorio diario y de citas) y pantalla Citas |
| HU-29 | Logs globales | `Nucleo/Logs/` (autoría del Equipo 6): archivo diario en `logs/` y errores en formato ProblemDetails |
| HU-32 | Swagger | Comentarios XML en los controladores, visibles en `/swagger` |
| HU-30/31 | Pruebas y CI/CD | `tests/` (casos de alertas aquí; el proyecto de pruebas está en el núcleo) y `.github/workflows/ci.yml` |

**Relación con el núcleo:** Los **logs globales** y el manejo de errores (`Nucleo/Logs/`) son autoría de este equipo. Al instalarse, su módulo **reemplaza** el `EvaluadorAlertasInactivo` del núcleo por el real.

## 3. Base de datos
**Script del equipo:** `database/por_equipo/6_Equipo6_Notificaciones.sql`. Para el sistema completo, los scripts se ejecutan en orden 1→6.

**Tablas del equipo:**
- `TiposAlerta`
- `Alertas`
- `Notificaciones`
- `Citas`

La justificación de la 3FN está en `database/Normalizacion_3FN.md`.

## 4. API del módulo
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/api/alertas` | Autenticado | Listar |
| PATCH | `/api/alertas/{id}/atender` | Admin, Docente, Nutricionista | Atender alerta |
| POST | `/api/alertas/evaluar` | Admin, Nutricionista | Evalúa las reglas para todos los estudiantes en una fecha (por defecto ayer, día cerrado). |
| GET | `/api/notificaciones` | Autenticado | Listar |
| GET | `/api/notificaciones/contador` | Autenticado | Notificaciones sin leer |
| PATCH | `/api/notificaciones/{id}/leer` | Autenticado | Marcar como leída |
| PATCH | `/api/notificaciones/leer-todas` | Autenticado | Marcar todas como leídas |
| GET | `/api/citas` | Autenticado | Listar |
| POST | `/api/citas` | Admin, Docente, Nutricionista | Crear |
| PUT | `/api/citas/{id}` | Admin, Docente, Nutricionista | Actualizar |
| PATCH | `/api/citas/{id}/estado` | Admin, Docente, Nutricionista | Cambiar estado |
| GET | `/api/reglas/alertas` | Admin, Docente, Nutricionista | Listar umbrales de alertas |
| PUT | `/api/reglas/alertas/{id}` | Admin, Nutricionista | Editar umbral de alerta |

Para probarla en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 5. Integración con los otros equipos
Al juntarse con los **Equipos 2 y 4**, las alertas se generan al momento, al registrar comidas o hábitos y al cambiar el peso.

**Para juntar el sistema completo:** descomprima los 6 ZIP en la misma carpeta. El núcleo es idéntico en todos, así que no hay conflictos. El sistema detecta los módulos solo.

## 6. Archivos propios del equipo
- `database/por_equipo/6_Equipo6_Notificaciones.sql`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Dominio/ReglasAlertas.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Modulo.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/AlertasService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/CitasService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/NotificacionesService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/RecordatoriosBackgroundService.cs`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/alertas.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/citas.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/notificaciones.js`
- `tests/SmartNutriTracker.Tests/ReglasAlertasTests.cs`

El resto del ZIP es el **núcleo común**, descrito en `docs/NUCLEO.md`.
