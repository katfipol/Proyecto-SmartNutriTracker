# SmartNutriTracker · Núcleo común

El **núcleo** viene en los 6 ZIP y es idéntico en todos. Contiene lo que cualquier módulo necesita para ejecutarse:

- **Solución y proyecto:** `SmartNutriTracker.slnx`, `.csproj`, `Program.cs`, `appsettings.json`.
- **Seguridad:** login con JWT, roles, PBKDF2, bloqueo de cuenta, rate limiting, control de acceso por dato y auditoría.
- **Base de datos:** `SmartNutriDbContext` con las 26 tablas y el script completo `database/SmartNutriTracker_BD.sql`.
- **Lógica compartida:** cálculo nutricional, catálogos, notificador y logs.
- **Frontend:** login, estructura responsiva y semántica, estilos verdes, Bootstrap y Chart.js locales, la página de **Inicio** básica (si falta el Equipo 2), **Cambiar contraseña** y las imágenes de los alimentos (`img/alimentos/`).
- **Pruebas:** el proyecto de pruebas, con las del cálculo y las contraseñas.

## Cómo se integran los módulos
1. **Registro automático:** cada módulo tiene un `Modulos/EquipoN_…/Modulo.cs` que implementa `IModulo`. `Program.cs` los busca al iniciar y registra solo los que existen.
2. **Identificación de controladores:** los controladores llevan `[Modulo(N)]`, y `GET /api/modulos` informa qué módulos y endpoints están activos.
3. **Contratos entre módulos:** los módulos se comunican a través de contratos del núcleo, nunca directamente.
   - `IEvaluadorAlertas`: si el Equipo 6 no está, se usa `EvaluadorAlertasInactivo`, que no hace nada.
   - `INotificador`, `INutricionService`, `ICatalogosService`: siempre están en el núcleo.
4. **Frontend:** carga cada pantalla bajo demanda y muestra en el menú solo las de los módulos instalados.

## Endpoints del núcleo
| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/api/auth/login` | Público | Inicia sesión con correo y contraseña. Devuelve el token JWT. |
| GET | `/api/auth/perfil` |  | Datos del usuario autenticado. |
| POST | `/api/auth/cambiar-password` |  | Cambia la contraseña del usuario autenticado. |
| GET | `/api/catalogos` | Autenticado | Obtener por id |
| GET | `/api/catalogos/estudiantes` | Admin, Docente, Nutricionista | Estudiantes visibles para el usuario (selectores). |
| GET | `/api/catalogos/alimentos` | Autenticado | Alimentos activos (selectores de registro, menús y exclusiones). |
| GET | `/api/modulos` | Autenticado | Módulos instalados (el menú muestra solo sus pantallas) |
| GET | `/api/salud` | Público | Estado de la API y de la base de datos |

## Usuarios de prueba (contraseña `Innovare2026!`)

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |

## Archivos del núcleo
- `.github/workflows/ci.yml`
- `.gitignore`
- `README.md`
- `SmartNutriTracker.slnx`
- `database/Normalizacion_3FN.md`
- `database/SmartNutriTracker_BD.sql`
- `src/SmartNutriTracker.Api/Nucleo/Comunes.cs`
- `src/SmartNutriTracker.Api/Nucleo/Contratos/Dtos.Compartidos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Contratos/Dtos.Seguridad.cs`
- `src/SmartNutriTracker.Api/Nucleo/Controladores.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo1.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo2.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo3.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo4.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo5.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Entidades.Equipo6.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/SmartNutriDbContext.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo1.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo2.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo3.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo4.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo5.cs`
- `src/SmartNutriTracker.Api/Nucleo/Datos/Tablas.Equipo6.cs`
- `src/SmartNutriTracker.Api/Nucleo/Dominio/CalculadoraNutricional.cs`
- `src/SmartNutriTracker.Api/Nucleo/Dominio/ModelosDominio.cs`
- `src/SmartNutriTracker.Api/Nucleo/Logs/ArchivoLogger.cs`
- `src/SmartNutriTracker.Api/Nucleo/Logs/ManejoErroresMiddleware.cs`
- `src/SmartNutriTracker.Api/Nucleo/Modulos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/AuditoriaService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/AuthService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/CatalogosService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/Contratos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/Mapeos.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/NutricionService.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/UsuarioActualYAcceso.cs`
- `src/SmartNutriTracker.Api/Nucleo/Servicios/UsuariosService.cs`
- `src/SmartNutriTracker.Api/Program.cs`
- `src/SmartNutriTracker.Api/Properties/launchSettings.json`
- `src/SmartNutriTracker.Api/SmartNutriTracker.Api.csproj`
- `src/SmartNutriTracker.Api/appsettings.Development.json`
- `src/SmartNutriTracker.Api/appsettings.json`
- `src/SmartNutriTracker.Api/wwwroot/app.html`
- `src/SmartNutriTracker.Api/wwwroot/css/app.css`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/LEEME.txt`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/almendras.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/api-de-maiz-morado.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/arroz-blanco-cocido.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/atun-en-agua.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/avena-cocida.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/brocoli-al-vapor.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/carne-de-res-magra.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/ensalada-mixta.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/fideo-integral-cocido.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/frutilla.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/gaseosa.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/huevo-duro.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/leche-con-quinua.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/leche-semidescremada.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/lentejas-guisadas.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/mandarina.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/mani-tostado-sin-sal.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/manzana.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/marraqueta.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/naranja.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/palta.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/pan-integral.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/papa-cocida.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/papas-fritas-de-bolsa.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/papaya.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/pechuga-de-pollo-a-la-plancha.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/platano.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/queso-fresco.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/quinua-cocida.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/saltena.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/sopa-de-verduras.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/trucha-al-horno.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/vainitas-salteadas.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/yogur-natural.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/alimentos/zanahoria-cocida.webp`
- `src/SmartNutriTracker.Api/wwwroot/img/logo.svg`
- `src/SmartNutriTracker.Api/wwwroot/index.html`
- `src/SmartNutriTracker.Api/wwwroot/js/api.js`
- `src/SmartNutriTracker.Api/wwwroot/js/app.js`
- `src/SmartNutriTracker.Api/wwwroot/js/estado.js`
- `src/SmartNutriTracker.Api/wwwroot/js/login.js`
- `src/SmartNutriTracker.Api/wwwroot/js/ui.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/bienvenida.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/cuenta.js`
- `tests/SmartNutriTracker.Tests/CalculadoraNutricionalTests.cs`
- `tests/SmartNutriTracker.Tests/DatosPrueba.cs`
- `tests/SmartNutriTracker.Tests/PasswordHasherTests.cs`
- `tests/SmartNutriTracker.Tests/SmartNutriTracker.Tests.csproj`
- `src/SmartNutriTracker.Api/wwwroot/lib/` (Bootstrap, iconos y Chart.js locales)
