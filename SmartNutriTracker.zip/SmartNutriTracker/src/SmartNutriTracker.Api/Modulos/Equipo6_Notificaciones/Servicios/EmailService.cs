// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using System.Net;
using System.Net.Http.Json;
using Microsoft.Extensions.Options;

namespace SmartNutriTracker.Api.Services;

/// <summary>Configuración de Brevo (sección "Brevo" de appsettings.json).</summary>
public sealed class BrevoOptions
{
    public bool Habilitado { get; set; }
    public string ApiKey { get; set; } = string.Empty;
    /// <summary>Remitente (por ejemplo, la cuenta de Gmail del colegio). Debe estar verificado en Brevo.</summary>
    public string RemitenteCorreo { get; set; } = string.Empty;
    public string RemitenteNombre { get; set; } = "SmartNutriTracker";
    public string UrlApi { get; set; } = "https://api.brevo.com/v3/smtp/email";
}

public interface IEmailService
{
    /// <summary>Envía un correo HTML. Nunca lanza excepciones: devuelve false si no se pudo enviar.</summary>
    Task<bool> EnviarAsync(string destinatarioCorreo, string destinatarioNombre, string asunto, string html, CancellationToken ct = default);
}

public class BrevoEmailService(HttpClient http, IOptions<BrevoOptions> opciones, ILogger<BrevoEmailService> logger) : IEmailService
{
    public async Task<bool> EnviarAsync(string destinatarioCorreo, string destinatarioNombre, string asunto, string html, CancellationToken ct = default)
    {
        var op = opciones.Value;
        if (!op.Habilitado)
        {
            logger.LogInformation("Brevo deshabilitado: no se envía correo a {Correo}", destinatarioCorreo);
            return false;
        }
        if (string.IsNullOrWhiteSpace(op.ApiKey) || string.IsNullOrWhiteSpace(op.RemitenteCorreo))
        {
            logger.LogWarning("Brevo habilitado pero falta Brevo:ApiKey o Brevo:RemitenteCorreo en appsettings.json");
            return false;
        }

        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, op.UrlApi);
            req.Headers.Add("api-key", op.ApiKey);
            req.Headers.Add("accept", "application/json");
            req.Content = JsonContent.Create(new
            {
                sender = new { name = op.RemitenteNombre, email = op.RemitenteCorreo },
                to = new[] { new { email = destinatarioCorreo, name = destinatarioNombre } },
                subject = asunto,
                htmlContent = html
            });

            using var resp = await http.SendAsync(req, ct);
            if (resp.IsSuccessStatusCode)
            {
                logger.LogInformation("Correo enviado vía Brevo a {Correo}: {Asunto}", destinatarioCorreo, asunto);
                return true;
            }

            var cuerpo = await resp.Content.ReadAsStringAsync(ct);
            logger.LogError("Brevo respondió {Codigo} al enviar a {Correo}: {Cuerpo}", (int)resp.StatusCode, destinatarioCorreo, cuerpo);
            return false;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogError(ex, "Error al enviar correo vía Brevo a {Correo}", destinatarioCorreo);
            return false;
        }
    }
}
