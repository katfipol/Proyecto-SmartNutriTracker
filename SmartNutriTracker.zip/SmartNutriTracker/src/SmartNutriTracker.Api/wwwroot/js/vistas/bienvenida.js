// NÚCLEO – Página de bienvenida: se usa como inicio cuando el módulo de Inicio (Equipo 2) no está instalado.
import { estado } from '../estado.js';
import { rutasDisponibles } from '../app.js';
import { esc } from '../ui.js';

export async function render({ el }) {
  const accesos = rutasDisponibles().filter(r => (r.seccion && r.ruta !== 'bienvenida') || r.ruta === 'cuenta');
  const esEst = estado.usuario.rol === 'Estudiante';
  el.innerHTML = `
    <section class="tarjeta p-4 mb-4 bienvenida" aria-labelledby="t-bienvenida">
      <h2 id="t-bienvenida" class="fw-bold mb-1">¡Hola, ${esc(estado.usuario.nombre.split(' ')[0])}!</h2>
      <p class="mb-0">Bienvenido a SmartNutriTracker del Colegio Innovare. Elige una opción para comenzar.</p>
    </section>
    <nav aria-label="Accesos rápidos">
      <ul class="accesos list-unstyled mb-0">${accesos.map(r => `
        <li><a class="tarjeta acceso" href="#/${r.ruta}">
          <span class="icono ic-verde" aria-hidden="true"><i class="bi ${r.icono}" aria-hidden="true"></i></span>
          <span class="fw-semibold">${esc(esEst && r.tituloEst ? r.tituloEst : r.titulo)}</span>
        </a></li>`).join('')}
      </ul>
    </nav>`;
}
