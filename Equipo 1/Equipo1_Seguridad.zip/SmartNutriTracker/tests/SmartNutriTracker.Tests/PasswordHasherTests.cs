using SmartNutriTracker.Api.Common;

namespace SmartNutriTracker.Tests;

/// <summary>HU-01 / HU-02 – Seguridad de contraseñas.</summary>
public class PasswordHasherTests
{
    [Fact]
    public void Hash_YVerificar_Correcto()
    {
        var hash = PasswordHasher.Hash("Innovare2026!");
        Assert.StartsWith("PBKDF2$100000$", hash);
        Assert.True(PasswordHasher.Verificar("Innovare2026!", hash));
        Assert.False(PasswordHasher.Verificar("otra", hash));
    }

    [Fact]
    public void Hash_UsaSalAleatoria() =>
        Assert.NotEqual(PasswordHasher.Hash("Innovare2026!"), PasswordHasher.Hash("Innovare2026!"));

    [Fact]
    public void Verificar_HashDeLaBaseDeDatos()
    {
        // Mismo hash que cargan los datos semilla del script SQL
        const string semilla = "PBKDF2$100000$XcjD+560bsFwhPsHUi+XFg==$J/6Oqwph6Hz8GZtsTAjHnEZ669vaemtAqcFmqFbrGxA=";
        Assert.True(PasswordHasher.Verificar("Innovare2026!", semilla));
    }

    [Theory]
    [InlineData("corta1A")]
    [InlineData("sinmayuscula1")]
    [InlineData("SINMINUSCULA1")]
    [InlineData("SinNumeros")]
    public void Politica_RechazaContrasenasDebiles(string password) =>
        Assert.Throws<ReglaNegocioException>(() => PasswordHasher.ValidarPolitica(password));

    [Fact]
    public void Verificar_FormatoInvalido_DevuelveFalse() =>
        Assert.False(PasswordHasher.Verificar("x", "no-es-un-hash"));
}
