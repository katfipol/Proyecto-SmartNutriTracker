CREATE TABLE Roles (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE Usuarios (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Correo NVARCHAR(150) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(300) NOT NULL,
    RolId INT NOT NULL,
    Activo BIT NOT NULL,
    IntentosFallidos INT NOT NULL,
    BloqueadoHasta DATETIME2 NULL,
    UltimoAcceso DATETIME2 NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (RolId) REFERENCES Roles(Id)
);

CREATE TABLE LogsAuditoria (
    Id BIGINT IDENTITY(1,1) NULL PRIMARY KEY,
    UsuarioId INT NULL,
    Accion NVARCHAR(50) NOT NULL,
    Entidad NVARCHAR(50) NOT NULL,
    EntidadId NVARCHAR(50) NULL,
    Detalle NVARCHAR(1000) NULL,
    DireccionIp NVARCHAR(45) NULL,
    Fecha DATETIME2 NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id)
);

CREATE TABLE NivelesActividad (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Codigo NVARCHAR(20) NOT NULL UNIQUE,
    Nombre NVARCHAR(60) NOT NULL,
    Factor DECIMAL(4,3) NOT NULL
);

CREATE TABLE ObjetivosNutricionales (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Codigo NVARCHAR(20) NOT NULL UNIQUE,
    Nombre NVARCHAR(60) NOT NULL,
    AjustePorcentaje DECIMAL(5,2) NOT NULL,
    PctProteina DECIMAL(5,2) NOT NULL,
    PctCarbohidratos DECIMAL(5,2) NOT NULL,
    PctGrasas DECIMAL(5,2) NOT NULL,
    Descripcion NVARCHAR(300) NULL
);

CREATE TABLE CategoriasImc (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(40) NOT NULL UNIQUE,
    ImcMin DECIMAL(5,2) NOT NULL,
    ImcMax DECIMAL(5,2) NOT NULL,
    ObjetivoSugeridoId INT NOT NULL,
    Mensaje NVARCHAR(300) NOT NULL,
    Activo BIT NOT NULL,
    FOREIGN KEY (ObjetivoSugeridoId) REFERENCES ObjetivosNutricionales(Id)
);

CREATE TABLE CategoriaImcObjetivos (
    CategoriaImcId INT NOT NULL,
    ObjetivoId INT NOT NULL,
    PRIMARY KEY (CategoriaImcId, ObjetivoId),
    FOREIGN KEY (CategoriaImcId) REFERENCES CategoriasImc(Id),
    FOREIGN KEY (ObjetivoId) REFERENCES ObjetivosNutricionales(Id)
);

CREATE TABLE CategoriasAlimento (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Codigo NVARCHAR(30) NOT NULL UNIQUE,
    Nombre NVARCHAR(60) NOT NULL
);

CREATE TABLE TiposComida (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(30) NOT NULL UNIQUE,
    Orden INT NOT NULL,
    PorcentajeCalorias DECIMAL(5,2) NOT NULL
);

CREATE TABLE TipoComidaCategorias (
    TipoComidaId INT NOT NULL,
    CategoriaAlimentoId INT NOT NULL,
    Orden INT NOT NULL,
    PRIMARY KEY (TipoComidaId, CategoriaAlimentoId),
    FOREIGN KEY (TipoComidaId) REFERENCES TiposComida(Id),
    FOREIGN KEY (CategoriaAlimentoId) REFERENCES CategoriasAlimento(Id)
);

CREATE TABLE Cursos (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(50) NOT NULL UNIQUE,
    DocenteId INT NULL,
    FOREIGN KEY (DocenteId) REFERENCES Usuarios(Id)
);

CREATE TABLE Estudiantes (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    UsuarioId INT NULL,
    Nombres NVARCHAR(100) NOT NULL,
    Apellidos NVARCHAR(100) NOT NULL,
    FechaNacimiento DATE NOT NULL,
    Sexo CHAR(1) NOT NULL,
    CursoId INT NOT NULL,
    PesoKg DECIMAL(5,2) NOT NULL,
    AlturaCm DECIMAL(5,2) NOT NULL,
    NivelActividadId INT NOT NULL,
    ObjetivoId INT NOT NULL,
    Activo BIT NOT NULL,
    FechaRegistro DATETIME2 NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id),
    FOREIGN KEY (CursoId) REFERENCES Cursos(Id),
    FOREIGN KEY (NivelActividadId) REFERENCES NivelesActividad(Id),
    FOREIGN KEY (ObjetivoId) REFERENCES ObjetivosNutricionales(Id)
);

CREATE TABLE MedicionesEstudiante (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    Fecha DATE NOT NULL,
    PesoKg DECIMAL(5,2) NOT NULL,
    AlturaCm DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id)
);

CREATE TABLE Alimentos (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(120) NOT NULL UNIQUE,
    CategoriaAlimentoId INT NOT NULL,
    PorcionDescripcion NVARCHAR(60) NOT NULL,
    PorcionGramos DECIMAL(7,2) NOT NULL,
    Calorias DECIMAL(7,2) NOT NULL,
    Proteinas DECIMAL(7,2) NOT NULL,
    Carbohidratos DECIMAL(7,2) NOT NULL,
    Grasas DECIMAL(7,2) NOT NULL,
    Fibra DECIMAL(7,2) NOT NULL,
    Azucares DECIMAL(7,2) NOT NULL,
    SodioMg DECIMAL(7,2) NOT NULL,
    Activo BIT NOT NULL,
    FOREIGN KEY (CategoriaAlimentoId) REFERENCES CategoriasAlimento(Id)
);

CREATE TABLE MenusDiarios (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Fecha DATE NULL,
    Descripcion NVARCHAR(300) NULL,
    CreadoPorId INT NOT NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (CreadoPorId) REFERENCES Usuarios(Id)
);

CREATE TABLE MenuDetalles (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    MenuId INT NOT NULL,
    TipoComidaId INT NOT NULL,
    AlimentoId INT NOT NULL,
    Porciones DECIMAL(4,2) NOT NULL,
    FOREIGN KEY (MenuId) REFERENCES MenusDiarios(Id),
    FOREIGN KEY (TipoComidaId) REFERENCES TiposComida(Id),
    FOREIGN KEY (AlimentoId) REFERENCES Alimentos(Id)
);

CREATE TABLE RegistrosConsumo (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    Fecha DATE NOT NULL,
    TipoComidaId INT NOT NULL,
    AlimentoId INT NOT NULL,
    Porciones DECIMAL(4,2) NOT NULL,
    FechaRegistro DATETIME2 NOT NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (TipoComidaId) REFERENCES TiposComida(Id),
    FOREIGN KEY (AlimentoId) REFERENCES Alimentos(Id)
);

CREATE TABLE RegistrosHabitos (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    Fecha DATE NOT NULL,
    HorasSueno DECIMAL(4,2) NOT NULL,
    AguaMl INT NOT NULL,
    MinutosActividad INT NOT NULL,
    Observaciones NVARCHAR(300) NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id)
);

CREATE TABLE AlimentosExcluidos (
    EstudianteId INT NOT NULL,
    AlimentoId INT NOT NULL,
    Motivo NVARCHAR(150) NULL,
    PRIMARY KEY (EstudianteId, AlimentoId),
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (AlimentoId) REFERENCES Alimentos(Id)
);

CREATE TABLE Recomendaciones (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    Fecha DATE NOT NULL,
    PesoKg DECIMAL(5,2) NOT NULL,
    AlturaCm DECIMAL(5,2) NOT NULL,
    Edad INT NOT NULL,
    FactorActividad DECIMAL(4,3) NOT NULL,
    CategoriaImcId INT NOT NULL,
    ObjetivoSolicitadoId INT NOT NULL,
    ObjetivoAplicadoId INT NOT NULL,
    CaloriasObjetivo DECIMAL(8,2) NOT NULL,
    ProteinasObjetivoG DECIMAL(7,2) NOT NULL,
    CarbohidratosObjetivoG DECIMAL(7,2) NOT NULL,
    GrasasObjetivoG DECIMAL(7,2) NOT NULL,
    Estado NVARCHAR(20) NOT NULL,
    ComentarioEstado NVARCHAR(300) NULL,
    Semilla INT NOT NULL,
    CreadoPorId INT NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (CategoriaImcId) REFERENCES CategoriasImc(Id),
    FOREIGN KEY (ObjetivoSolicitadoId) REFERENCES ObjetivosNutricionales(Id),
    FOREIGN KEY (ObjetivoAplicadoId) REFERENCES ObjetivosNutricionales(Id),
    FOREIGN KEY (CreadoPorId) REFERENCES Usuarios(Id)
);

CREATE TABLE RecomendacionDetalles (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    RecomendacionId INT NOT NULL,
    TipoComidaId INT NOT NULL,
    AlimentoId INT NOT NULL,
    Porciones DECIMAL(4,2) NOT NULL,
    FOREIGN KEY (RecomendacionId) REFERENCES Recomendaciones(Id),
    FOREIGN KEY (TipoComidaId) REFERENCES TiposComida(Id),
    FOREIGN KEY (AlimentoId) REFERENCES Alimentos(Id)
);

CREATE TABLE RecomendacionObservaciones (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    RecomendacionId INT NOT NULL,
    Orden INT NOT NULL,
    Texto NVARCHAR(400) NOT NULL,
    FOREIGN KEY (RecomendacionId) REFERENCES Recomendaciones(Id)
);

CREATE TABLE TiposAlerta (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    Codigo NVARCHAR(30) NOT NULL UNIQUE,
    Nombre NVARCHAR(80) NOT NULL,
    Descripcion NVARCHAR(300) NULL,
    Umbral DECIMAL(10,2) NOT NULL,
    Unidad NVARCHAR(20) NOT NULL,
    Nivel NVARCHAR(10) NOT NULL,
    Activo BIT NOT NULL
);

CREATE TABLE Alertas (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    TipoAlertaId INT NOT NULL,
    Fecha DATE NOT NULL,
    ValorRegistrado DECIMAL(10,2) NOT NULL,
    Mensaje NVARCHAR(400) NOT NULL,
    Atendida BIT NOT NULL,
    AtendidaPorId INT NULL,
    FechaAtencion DATETIME2 NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (TipoAlertaId) REFERENCES TiposAlerta(Id),
    FOREIGN KEY (AtendidaPorId) REFERENCES Usuarios(Id)
);

CREATE TABLE Notificaciones (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    UsuarioId INT NOT NULL,
    Titulo NVARCHAR(100) NOT NULL,
    Mensaje NVARCHAR(400) NOT NULL,
    Tipo NVARCHAR(20) NOT NULL,
    Leida BIT NOT NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id)
);

CREATE TABLE Citas (
    Id INT IDENTITY(1,1) NULL PRIMARY KEY,
    EstudianteId INT NOT NULL,
    NutricionistaId INT NOT NULL,
    FechaHora DATETIME2 NOT NULL,
    DuracionMinutos INT NOT NULL,
    Motivo NVARCHAR(200) NOT NULL,
    Estado NVARCHAR(20) NOT NULL,
    Notas NVARCHAR(500) NULL,
    RecordatorioEnviado BIT NOT NULL,
    FechaCreacion DATETIME2 NOT NULL,
    FOREIGN KEY (EstudianteId) REFERENCES Estudiantes(Id),
    FOREIGN KEY (NutricionistaId) REFERENCES Usuarios(Id)
);
