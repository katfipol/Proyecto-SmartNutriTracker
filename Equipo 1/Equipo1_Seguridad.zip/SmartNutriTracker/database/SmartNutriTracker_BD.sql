/* =====================================================================
   SmartNutriTracker - Colegio "Innovare"
   BASE DE DATOS COMPLETA (Equipos 1 a 6) - Normalizada hasta 3FN
   Motor: SQL Server 2019+ / SQL Server Express

   ATENCIÓN: este script ELIMINA y vuelve a crear la base de datos
   SmartNutriTrackerDB. Ejecútelo completo con F5 en SSMS.

   Contraseña de TODOS los usuarios de prueba: Innovare2026!
   ===================================================================== */

USE master;
GO

IF DB_ID(N'SmartNutriTrackerDB') IS NOT NULL
BEGIN
    ALTER DATABASE SmartNutriTrackerDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE SmartNutriTrackerDB;
END
GO

CREATE DATABASE SmartNutriTrackerDB;
GO

USE SmartNutriTrackerDB;
GO

/* =====================================================================
   EQUIPO 1 - AUTENTICACIÓN Y SEGURIDAD (HU-01 a HU-05)
   ===================================================================== */
CREATE TABLE dbo.Roles
(
    Id      INT IDENTITY(1,1) CONSTRAINT PK_Roles PRIMARY KEY,
    Nombre  NVARCHAR(30) NOT NULL CONSTRAINT UQ_Roles_Nombre UNIQUE
);

CREATE TABLE dbo.Usuarios
(
    Id                INT IDENTITY(1,1) CONSTRAINT PK_Usuarios PRIMARY KEY,
    Nombre            NVARCHAR(100) NOT NULL,
    Correo            NVARCHAR(150) NOT NULL CONSTRAINT UQ_Usuarios_Correo UNIQUE,
    PasswordHash      NVARCHAR(300) NOT NULL,
    RolId             INT NOT NULL CONSTRAINT FK_Usuarios_Roles REFERENCES dbo.Roles(Id),
    Activo            BIT NOT NULL CONSTRAINT DF_Usuarios_Activo DEFAULT (1),
    IntentosFallidos  INT NOT NULL CONSTRAINT DF_Usuarios_Intentos DEFAULT (0),
    BloqueadoHasta    DATETIME2 NULL,
    UltimoAcceso      DATETIME2 NULL,
    FechaCreacion     DATETIME2 NOT NULL CONSTRAINT DF_Usuarios_Fecha DEFAULT (SYSUTCDATETIME())
);

CREATE TABLE dbo.LogsAuditoria
(
    Id           BIGINT IDENTITY(1,1) CONSTRAINT PK_LogsAuditoria PRIMARY KEY,
    UsuarioId    INT NULL CONSTRAINT FK_LogsAuditoria_Usuarios REFERENCES dbo.Usuarios(Id),
    Accion       NVARCHAR(50)   NOT NULL,
    Entidad      NVARCHAR(50)   NOT NULL,
    EntidadId    NVARCHAR(50)   NULL,
    Detalle      NVARCHAR(1000) NULL,
    DireccionIp  NVARCHAR(45)   NULL,
    Fecha        DATETIME2 NOT NULL CONSTRAINT DF_LogsAuditoria_Fecha DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_LogsAuditoria_Fecha ON dbo.LogsAuditoria (Fecha DESC);

/* =====================================================================
   CATÁLOGOS (evitan dependencias transitivas y valores repetidos)
   ===================================================================== */
CREATE TABLE dbo.NivelesActividad
(
    Id      INT IDENTITY(1,1) CONSTRAINT PK_NivelesActividad PRIMARY KEY,
    Codigo  NVARCHAR(20) NOT NULL CONSTRAINT UQ_NivelesActividad_Codigo UNIQUE,
    Nombre  NVARCHAR(60) NOT NULL,
    Factor  DECIMAL(4,3) NOT NULL CONSTRAINT CK_NivelesActividad_Factor CHECK (Factor BETWEEN 1 AND 2.5)
);

CREATE TABLE dbo.ObjetivosNutricionales
(
    Id                INT IDENTITY(1,1) CONSTRAINT PK_ObjetivosNutricionales PRIMARY KEY,
    Codigo            NVARCHAR(20)  NOT NULL CONSTRAINT UQ_Objetivos_Codigo UNIQUE,
    Nombre            NVARCHAR(60)  NOT NULL,
    AjustePorcentaje  DECIMAL(5,2)  NOT NULL CONSTRAINT CK_Objetivos_Ajuste CHECK (AjustePorcentaje BETWEEN -30 AND 30),
    PctProteina       DECIMAL(5,2)  NOT NULL,
    PctCarbohidratos  DECIMAL(5,2)  NOT NULL,
    PctGrasas         DECIMAL(5,2)  NOT NULL,
    Descripcion       NVARCHAR(300) NULL,
    CONSTRAINT CK_Objetivos_SumaMacros CHECK (PctProteina + PctCarbohidratos + PctGrasas = 100)
);

CREATE TABLE dbo.CategoriasImc
(
    Id                  INT IDENTITY(1,1) CONSTRAINT PK_CategoriasImc PRIMARY KEY,
    Nombre              NVARCHAR(40)  NOT NULL CONSTRAINT UQ_CategoriasImc_Nombre UNIQUE,
    ImcMin              DECIMAL(5,2)  NOT NULL,
    ImcMax              DECIMAL(5,2)  NOT NULL,
    ObjetivoSugeridoId  INT NOT NULL CONSTRAINT FK_CategoriasImc_Objetivo REFERENCES dbo.ObjetivosNutricionales(Id),
    Mensaje             NVARCHAR(300) NOT NULL,
    Activo              BIT NOT NULL CONSTRAINT DF_CategoriasImc_Activo DEFAULT (1),
    CONSTRAINT CK_CategoriasImc_Rango CHECK (ImcMin < ImcMax)
);

-- Relación N:M -> objetivos permitidos por categoría de IMC (1FN: sin listas en una columna)
CREATE TABLE dbo.CategoriaImcObjetivos
(
    CategoriaImcId  INT NOT NULL CONSTRAINT FK_CatImcObj_Categoria REFERENCES dbo.CategoriasImc(Id) ON DELETE CASCADE,
    ObjetivoId      INT NOT NULL CONSTRAINT FK_CatImcObj_Objetivo REFERENCES dbo.ObjetivosNutricionales(Id),
    CONSTRAINT PK_CategoriaImcObjetivos PRIMARY KEY (CategoriaImcId, ObjetivoId)
);

CREATE TABLE dbo.CategoriasAlimento
(
    Id      INT IDENTITY(1,1) CONSTRAINT PK_CategoriasAlimento PRIMARY KEY,
    Codigo  NVARCHAR(30) NOT NULL CONSTRAINT UQ_CategoriasAlimento_Codigo UNIQUE,
    Nombre  NVARCHAR(60) NOT NULL
);

CREATE TABLE dbo.TiposComida
(
    Id                  INT IDENTITY(1,1) CONSTRAINT PK_TiposComida PRIMARY KEY,
    Nombre              NVARCHAR(30) NOT NULL CONSTRAINT UQ_TiposComida_Nombre UNIQUE,
    Orden               INT NOT NULL,
    PorcentajeCalorias  DECIMAL(5,2) NOT NULL CONSTRAINT CK_TiposComida_Pct CHECK (PorcentajeCalorias > 0 AND PorcentajeCalorias <= 100)
);

-- Plantilla del motor de recomendaciones: categorías que lleva cada comida
CREATE TABLE dbo.TipoComidaCategorias
(
    TipoComidaId         INT NOT NULL CONSTRAINT FK_TCC_TipoComida REFERENCES dbo.TiposComida(Id) ON DELETE CASCADE,
    CategoriaAlimentoId  INT NOT NULL CONSTRAINT FK_TCC_Categoria REFERENCES dbo.CategoriasAlimento(Id),
    Orden                INT NOT NULL,
    CONSTRAINT PK_TipoComidaCategorias PRIMARY KEY (TipoComidaId, CategoriaAlimentoId)
);

/* =====================================================================
   EQUIPO 2 - PERFIL Y REPORTES (HU-08 a HU-12)
   ===================================================================== */
CREATE TABLE dbo.Cursos
(
    Id         INT IDENTITY(1,1) CONSTRAINT PK_Cursos PRIMARY KEY,
    Nombre     NVARCHAR(50) NOT NULL CONSTRAINT UQ_Cursos_Nombre UNIQUE,
    DocenteId  INT NULL CONSTRAINT FK_Cursos_Docente REFERENCES dbo.Usuarios(Id)
);

CREATE TABLE dbo.Estudiantes
(
    Id                INT IDENTITY(1,1) CONSTRAINT PK_Estudiantes PRIMARY KEY,
    UsuarioId         INT NULL CONSTRAINT FK_Estudiantes_Usuarios REFERENCES dbo.Usuarios(Id),
    Nombres           NVARCHAR(100) NOT NULL,
    Apellidos         NVARCHAR(100) NOT NULL,
    FechaNacimiento   DATE NOT NULL,
    Sexo              CHAR(1) NOT NULL CONSTRAINT CK_Estudiantes_Sexo CHECK (Sexo IN ('M','F')),
    CursoId           INT NOT NULL CONSTRAINT FK_Estudiantes_Cursos REFERENCES dbo.Cursos(Id),
    PesoKg            DECIMAL(5,2) NOT NULL CONSTRAINT CK_Estudiantes_Peso CHECK (PesoKg BETWEEN 10 AND 300),
    AlturaCm          DECIMAL(5,2) NOT NULL CONSTRAINT CK_Estudiantes_Altura CHECK (AlturaCm BETWEEN 80 AND 230),
    NivelActividadId  INT NOT NULL CONSTRAINT FK_Estudiantes_Nivel REFERENCES dbo.NivelesActividad(Id),
    ObjetivoId        INT NOT NULL CONSTRAINT FK_Estudiantes_Objetivo REFERENCES dbo.ObjetivosNutricionales(Id),
    Activo            BIT NOT NULL CONSTRAINT DF_Estudiantes_Activo DEFAULT (1),
    FechaRegistro     DATETIME2 NOT NULL CONSTRAINT DF_Estudiantes_Fecha DEFAULT (SYSUTCDATETIME())
);
-- Un usuario solo puede estar vinculado a un estudiante
CREATE UNIQUE INDEX UX_Estudiantes_Usuario ON dbo.Estudiantes (UsuarioId) WHERE UsuarioId IS NOT NULL;

-- Historial de peso y talla (progreso físico)
CREATE TABLE dbo.MedicionesEstudiante
(
    Id            INT IDENTITY(1,1) CONSTRAINT PK_MedicionesEstudiante PRIMARY KEY,
    EstudianteId  INT NOT NULL CONSTRAINT FK_Mediciones_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    Fecha         DATE NOT NULL,
    PesoKg        DECIMAL(5,2) NOT NULL,
    AlturaCm      DECIMAL(5,2) NOT NULL,
    CONSTRAINT UQ_Mediciones_EstudianteFecha UNIQUE (EstudianteId, Fecha)
);

/* =====================================================================
   EQUIPO 3 - GESTIÓN DE ALIMENTOS Y MENÚS (HU-14 a HU-17)
   ===================================================================== */
CREATE TABLE dbo.Alimentos
(
    Id                   INT IDENTITY(1,1) CONSTRAINT PK_Alimentos PRIMARY KEY,
    Nombre               NVARCHAR(120) NOT NULL CONSTRAINT UQ_Alimentos_Nombre UNIQUE,
    CategoriaAlimentoId  INT NOT NULL CONSTRAINT FK_Alimentos_Categoria REFERENCES dbo.CategoriasAlimento(Id),
    PorcionDescripcion   NVARCHAR(60) NOT NULL,
    PorcionGramos        DECIMAL(7,2) NOT NULL CONSTRAINT CK_Alimentos_Gramos CHECK (PorcionGramos > 0),
    Calorias             DECIMAL(7,2) NOT NULL CONSTRAINT CK_Alimentos_Calorias CHECK (Calorias >= 0),
    Proteinas            DECIMAL(7,2) NOT NULL CONSTRAINT CK_Alimentos_Prot CHECK (Proteinas >= 0),
    Carbohidratos        DECIMAL(7,2) NOT NULL CONSTRAINT CK_Alimentos_Carb CHECK (Carbohidratos >= 0),
    Grasas               DECIMAL(7,2) NOT NULL CONSTRAINT CK_Alimentos_Gras CHECK (Grasas >= 0),
    Fibra                DECIMAL(7,2) NOT NULL CONSTRAINT DF_Alimentos_Fibra DEFAULT (0),
    Azucares             DECIMAL(7,2) NOT NULL CONSTRAINT DF_Alimentos_Azucar DEFAULT (0),
    SodioMg              DECIMAL(7,2) NOT NULL CONSTRAINT DF_Alimentos_Sodio DEFAULT (0),
    Activo               BIT NOT NULL CONSTRAINT DF_Alimentos_Activo DEFAULT (1)
);

CREATE TABLE dbo.MenusDiarios
(
    Id             INT IDENTITY(1,1) CONSTRAINT PK_MenusDiarios PRIMARY KEY,
    Nombre         NVARCHAR(100) NOT NULL,
    Fecha          DATE NULL,
    Descripcion    NVARCHAR(300) NULL,
    CreadoPorId    INT NOT NULL CONSTRAINT FK_Menus_Usuarios REFERENCES dbo.Usuarios(Id),
    FechaCreacion  DATETIME2 NOT NULL CONSTRAINT DF_Menus_Fecha DEFAULT (SYSUTCDATETIME())
);

CREATE TABLE dbo.MenuDetalles
(
    Id            INT IDENTITY(1,1) CONSTRAINT PK_MenuDetalles PRIMARY KEY,
    MenuId        INT NOT NULL CONSTRAINT FK_MenuDetalles_Menus REFERENCES dbo.MenusDiarios(Id) ON DELETE CASCADE,
    TipoComidaId  INT NOT NULL CONSTRAINT FK_MenuDetalles_TipoComida REFERENCES dbo.TiposComida(Id),
    AlimentoId    INT NOT NULL CONSTRAINT FK_MenuDetalles_Alimentos REFERENCES dbo.Alimentos(Id),
    Porciones     DECIMAL(4,2) NOT NULL CONSTRAINT CK_MenuDetalles_Porciones CHECK (Porciones > 0)
);

/* =====================================================================
   EQUIPO 4 - REGISTRO DE HÁBITOS (HU-19 a HU-22)
   ===================================================================== */
CREATE TABLE dbo.RegistrosConsumo
(
    Id             INT IDENTITY(1,1) CONSTRAINT PK_RegistrosConsumo PRIMARY KEY,
    EstudianteId   INT NOT NULL CONSTRAINT FK_Consumo_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    Fecha          DATE NOT NULL,
    TipoComidaId   INT NOT NULL CONSTRAINT FK_Consumo_TipoComida REFERENCES dbo.TiposComida(Id),
    AlimentoId     INT NOT NULL CONSTRAINT FK_Consumo_Alimentos REFERENCES dbo.Alimentos(Id),
    Porciones      DECIMAL(4,2) NOT NULL CONSTRAINT CK_Consumo_Porciones CHECK (Porciones > 0 AND Porciones <= 10),
    FechaRegistro  DATETIME2 NOT NULL CONSTRAINT DF_Consumo_Fecha DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_Consumo_EstudianteFecha ON dbo.RegistrosConsumo (EstudianteId, Fecha);

CREATE TABLE dbo.RegistrosHabitos
(
    Id                INT IDENTITY(1,1) CONSTRAINT PK_RegistrosHabitos PRIMARY KEY,
    EstudianteId      INT NOT NULL CONSTRAINT FK_Habitos_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    Fecha             DATE NOT NULL,
    HorasSueno        DECIMAL(4,2) NOT NULL CONSTRAINT CK_Habitos_Sueno CHECK (HorasSueno BETWEEN 0 AND 24),
    AguaMl            INT NOT NULL CONSTRAINT CK_Habitos_Agua CHECK (AguaMl BETWEEN 0 AND 10000),
    MinutosActividad  INT NOT NULL CONSTRAINT CK_Habitos_Actividad CHECK (MinutosActividad BETWEEN 0 AND 1440),
    Observaciones     NVARCHAR(300) NULL,
    CONSTRAINT UQ_Habitos_EstudianteFecha UNIQUE (EstudianteId, Fecha)
);

/* =====================================================================
   EQUIPO 5 - RECOMENDACIONES INTELIGENTES (HU-23 a HU-26)
   ===================================================================== */
CREATE TABLE dbo.AlimentosExcluidos
(
    EstudianteId  INT NOT NULL CONSTRAINT FK_Excluidos_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    AlimentoId    INT NOT NULL CONSTRAINT FK_Excluidos_Alimentos REFERENCES dbo.Alimentos(Id),
    Motivo        NVARCHAR(150) NULL,
    CONSTRAINT PK_AlimentosExcluidos PRIMARY KEY (EstudianteId, AlimentoId)
);

-- Se guardan los datos de entrada del cálculo (foto histórica). IMC, TMB, gasto
-- energético y totales del menú NO se guardan: se calculan (evita datos derivados).
CREATE TABLE dbo.Recomendaciones
(
    Id                      INT IDENTITY(1,1) CONSTRAINT PK_Recomendaciones PRIMARY KEY,
    EstudianteId            INT NOT NULL CONSTRAINT FK_Recomendaciones_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    Fecha                   DATE NOT NULL,
    PesoKg                  DECIMAL(5,2) NOT NULL,
    AlturaCm                DECIMAL(5,2) NOT NULL,
    Edad                    INT NOT NULL,
    FactorActividad         DECIMAL(4,3) NOT NULL,
    CategoriaImcId          INT NOT NULL CONSTRAINT FK_Recomendaciones_CatImc REFERENCES dbo.CategoriasImc(Id),
    ObjetivoSolicitadoId    INT NOT NULL CONSTRAINT FK_Recomendaciones_ObjSol REFERENCES dbo.ObjetivosNutricionales(Id),
    ObjetivoAplicadoId      INT NOT NULL CONSTRAINT FK_Recomendaciones_ObjApl REFERENCES dbo.ObjetivosNutricionales(Id),
    CaloriasObjetivo        DECIMAL(8,2) NOT NULL,
    ProteinasObjetivoG      DECIMAL(7,2) NOT NULL,
    CarbohidratosObjetivoG  DECIMAL(7,2) NOT NULL,
    GrasasObjetivoG         DECIMAL(7,2) NOT NULL,
    Estado                  NVARCHAR(20) NOT NULL CONSTRAINT DF_Recomendaciones_Estado DEFAULT (N'Generada')
                                CONSTRAINT CK_Recomendaciones_Estado CHECK (Estado IN (N'Generada', N'Aceptada', N'Rechazada')),
    ComentarioEstado        NVARCHAR(300) NULL,
    Semilla                 INT NOT NULL,
    CreadoPorId             INT NULL CONSTRAINT FK_Recomendaciones_Usuarios REFERENCES dbo.Usuarios(Id),
    FechaCreacion           DATETIME2 NOT NULL CONSTRAINT DF_Recomendaciones_Fecha DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_Recomendaciones_EstudianteFecha ON dbo.Recomendaciones (EstudianteId, Fecha DESC);

CREATE TABLE dbo.RecomendacionDetalles
(
    Id               INT IDENTITY(1,1) CONSTRAINT PK_RecomendacionDetalles PRIMARY KEY,
    RecomendacionId  INT NOT NULL CONSTRAINT FK_RecDetalles_Recomendaciones REFERENCES dbo.Recomendaciones(Id) ON DELETE CASCADE,
    TipoComidaId     INT NOT NULL CONSTRAINT FK_RecDetalles_TipoComida REFERENCES dbo.TiposComida(Id),
    AlimentoId       INT NOT NULL CONSTRAINT FK_RecDetalles_Alimentos REFERENCES dbo.Alimentos(Id),
    Porciones        DECIMAL(4,2) NOT NULL CONSTRAINT CK_RecDetalles_Porciones CHECK (Porciones > 0)
);

-- Observaciones como filas (1FN: nada de textos separados por comas)
CREATE TABLE dbo.RecomendacionObservaciones
(
    Id               INT IDENTITY(1,1) CONSTRAINT PK_RecomendacionObservaciones PRIMARY KEY,
    RecomendacionId  INT NOT NULL CONSTRAINT FK_RecObs_Recomendaciones REFERENCES dbo.Recomendaciones(Id) ON DELETE CASCADE,
    Orden            INT NOT NULL,
    Texto            NVARCHAR(400) NOT NULL
);

/* =====================================================================
   EQUIPO 6 - NOTIFICACIONES, ALERTAS Y CITAS (HU-27, HU-28 + alcance)
   ===================================================================== */
CREATE TABLE dbo.TiposAlerta
(
    Id           INT IDENTITY(1,1) CONSTRAINT PK_TiposAlerta PRIMARY KEY,
    Codigo       NVARCHAR(30)  NOT NULL CONSTRAINT UQ_TiposAlerta_Codigo UNIQUE,
    Nombre       NVARCHAR(80)  NOT NULL,
    Descripcion  NVARCHAR(300) NULL,
    Umbral       DECIMAL(10,2) NOT NULL,
    Unidad       NVARCHAR(20)  NOT NULL,
    Nivel        NVARCHAR(10)  NOT NULL CONSTRAINT CK_TiposAlerta_Nivel CHECK (Nivel IN (N'Baja', N'Media', N'Alta')),
    Activo       BIT NOT NULL CONSTRAINT DF_TiposAlerta_Activo DEFAULT (1)
);

CREATE TABLE dbo.Alertas
(
    Id               INT IDENTITY(1,1) CONSTRAINT PK_Alertas PRIMARY KEY,
    EstudianteId     INT NOT NULL CONSTRAINT FK_Alertas_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    TipoAlertaId     INT NOT NULL CONSTRAINT FK_Alertas_Tipo REFERENCES dbo.TiposAlerta(Id),
    Fecha            DATE NOT NULL,
    ValorRegistrado  DECIMAL(10,2) NOT NULL,
    Mensaje          NVARCHAR(400) NOT NULL,
    Atendida         BIT NOT NULL CONSTRAINT DF_Alertas_Atendida DEFAULT (0),
    AtendidaPorId    INT NULL CONSTRAINT FK_Alertas_Usuarios REFERENCES dbo.Usuarios(Id),
    FechaAtencion    DATETIME2 NULL,
    FechaCreacion    DATETIME2 NOT NULL CONSTRAINT DF_Alertas_Fecha DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_Alertas_EstudianteTipoFecha UNIQUE (EstudianteId, TipoAlertaId, Fecha)
);

CREATE TABLE dbo.Notificaciones
(
    Id             INT IDENTITY(1,1) CONSTRAINT PK_Notificaciones PRIMARY KEY,
    UsuarioId      INT NOT NULL CONSTRAINT FK_Notificaciones_Usuarios REFERENCES dbo.Usuarios(Id) ON DELETE CASCADE,
    Titulo         NVARCHAR(100) NOT NULL,
    Mensaje        NVARCHAR(400) NOT NULL,
    Tipo           NVARCHAR(20)  NOT NULL CONSTRAINT CK_Notificaciones_Tipo CHECK (Tipo IN (N'Recordatorio', N'Alerta', N'Cita', N'Sistema')),
    Leida          BIT NOT NULL CONSTRAINT DF_Notificaciones_Leida DEFAULT (0),
    FechaCreacion  DATETIME2 NOT NULL CONSTRAINT DF_Notificaciones_Fecha DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_Notificaciones_Usuario ON dbo.Notificaciones (UsuarioId, Leida, FechaCreacion DESC);

CREATE TABLE dbo.Citas
(
    Id                   INT IDENTITY(1,1) CONSTRAINT PK_Citas PRIMARY KEY,
    EstudianteId         INT NOT NULL CONSTRAINT FK_Citas_Estudiantes REFERENCES dbo.Estudiantes(Id) ON DELETE CASCADE,
    NutricionistaId      INT NOT NULL CONSTRAINT FK_Citas_Nutricionista REFERENCES dbo.Usuarios(Id),
    FechaHora            DATETIME2 NOT NULL,
    DuracionMinutos      INT NOT NULL CONSTRAINT DF_Citas_Duracion DEFAULT (30) CONSTRAINT CK_Citas_Duracion CHECK (DuracionMinutos BETWEEN 10 AND 240),
    Motivo               NVARCHAR(200) NOT NULL,
    Estado               NVARCHAR(20)  NOT NULL CONSTRAINT DF_Citas_Estado DEFAULT (N'Programada')
                             CONSTRAINT CK_Citas_Estado CHECK (Estado IN (N'Programada', N'Completada', N'Cancelada')),
    Notas                NVARCHAR(500) NULL,
    RecordatorioEnviado  BIT NOT NULL CONSTRAINT DF_Citas_Recordatorio DEFAULT (0),
    FechaCreacion        DATETIME2 NOT NULL CONSTRAINT DF_Citas_Fecha DEFAULT (SYSUTCDATETIME())
);
CREATE INDEX IX_Citas_FechaHora ON dbo.Citas (FechaHora);
GO

/* =====================================================================
   VISTAS DE APOYO (reportes rápidos desde SQL)
   ===================================================================== */
CREATE VIEW dbo.vw_ConsumoDiario
AS
SELECT  rc.EstudianteId,
        rc.Fecha,
        SUM(a.Calorias      * rc.Porciones) AS Calorias,
        SUM(a.Proteinas     * rc.Porciones) AS Proteinas,
        SUM(a.Carbohidratos * rc.Porciones) AS Carbohidratos,
        SUM(a.Grasas        * rc.Porciones) AS Grasas,
        SUM(a.Azucares      * rc.Porciones) AS Azucares,
        SUM(a.SodioMg       * rc.Porciones) AS SodioMg
FROM dbo.RegistrosConsumo rc
INNER JOIN dbo.Alimentos a ON a.Id = rc.AlimentoId
GROUP BY rc.EstudianteId, rc.Fecha;
GO

CREATE VIEW dbo.vw_EstudiantesImc
AS
SELECT  e.Id AS EstudianteId,
        e.Nombres + N' ' + e.Apellidos AS Estudiante,
        c.Nombre AS Curso,
        CAST(e.PesoKg / POWER(e.AlturaCm / 100.0, 2) AS DECIMAL(5,2)) AS Imc,
        ci.Nombre AS CategoriaImc
FROM dbo.Estudiantes e
INNER JOIN dbo.Cursos c ON c.Id = e.CursoId
LEFT JOIN dbo.CategoriasImc ci
       ON ci.Activo = 1
      AND e.PesoKg / POWER(e.AlturaCm / 100.0, 2) >= ci.ImcMin
      AND e.PesoKg / POWER(e.AlturaCm / 100.0, 2) <  ci.ImcMax
WHERE e.Activo = 1;
GO

/* =====================================================================
   DATOS SEMILLA
   ===================================================================== */
INSERT INTO dbo.Roles (Nombre) VALUES (N'Admin'), (N'Docente'), (N'Nutricionista'), (N'Estudiante');

-- Contraseña de todos: Innovare2026!  (PBKDF2-SHA256, 100.000 iteraciones)
DECLARE @hash NVARCHAR(300) = N'PBKDF2$100000$XcjD+560bsFwhPsHUi+XFg==$J/6Oqwph6Hz8GZtsTAjHnEZ669vaemtAqcFmqFbrGxA=';

INSERT INTO dbo.Usuarios (Nombre, Correo, PasswordHash, RolId)
SELECT s.Nombre, s.Correo, @hash, r.Id
FROM (VALUES
    (1,  N'Administrador del Sistema', N'admin@innovare.edu.bo',          N'Admin'),
    (2,  N'Lic. María Rojas',          N'nutricion@innovare.edu.bo',      N'Nutricionista'),
    (3,  N'Prof. Jorge Vargas',        N'jvargas@innovare.edu.bo',        N'Docente'),
    (4,  N'Prof. Lucía Torrez',        N'ltorrez@innovare.edu.bo',        N'Docente'),
    (5,  N'Ana Mamani',                N'ana.mamani@innovare.edu.bo',     N'Estudiante'),
    (6,  N'Luis Quispe',               N'luis.quispe@innovare.edu.bo',    N'Estudiante'),
    (7,  N'Carla Flores',              N'carla.flores@innovare.edu.bo',   N'Estudiante'),
    (8,  N'Diego Choque',              N'diego.choque@innovare.edu.bo',   N'Estudiante'),
    (9,  N'Sofía Gutiérrez',           N'sofia.gutierrez@innovare.edu.bo', N'Estudiante'),
    (10, N'Mateo Condori',             N'mateo.condori@innovare.edu.bo',  N'Estudiante')
) AS s (Orden, Nombre, Correo, Rol)
INNER JOIN dbo.Roles r ON r.Nombre = s.Rol
ORDER BY s.Orden;

INSERT INTO dbo.Cursos (Nombre, DocenteId) VALUES
    (N'5to Secundaria A', (SELECT Id FROM dbo.Usuarios WHERE Correo = N'jvargas@innovare.edu.bo')),
    (N'6to Secundaria A', (SELECT Id FROM dbo.Usuarios WHERE Correo = N'ltorrez@innovare.edu.bo'));

INSERT INTO dbo.NivelesActividad (Codigo, Nombre, Factor) VALUES
    (N'SEDENTARIO', N'Sedentario (poco o nada de ejercicio)', 1.200),
    (N'LIGERO',     N'Ligero (1-3 días por semana)',          1.375),
    (N'MODERADO',   N'Moderado (3-5 días por semana)',        1.550),
    (N'ACTIVO',     N'Activo (6-7 días por semana)',          1.725),
    (N'MUY_ACTIVO', N'Muy activo (entrenamiento diario)',     1.900);

INSERT INTO dbo.ObjetivosNutricionales (Codigo, Nombre, AjustePorcentaje, PctProteina, PctCarbohidratos, PctGrasas, Descripcion) VALUES
    (N'BAJAR',    N'Bajar de peso',  -15, 25, 45, 30, N'Déficit calórico moderado con más proteína para conservar masa muscular.'),
    (N'MANTENER', N'Mantener peso',    0, 20, 50, 30, N'Calorías iguales al gasto energético total.'),
    (N'GANAR',    N'Ganar peso',      10, 20, 55, 25, N'Superávit moderado con énfasis en carbohidratos complejos.');

INSERT INTO dbo.CategoriasImc (Nombre, ImcMin, ImcMax, ObjetivoSugeridoId, Mensaje)
SELECT s.Nombre, s.ImcMin, s.ImcMax, o.Id, s.Mensaje
FROM (VALUES
    (1, N'Bajo peso',  0.00, 18.50, N'GANAR',    N'IMC bajo: no se recomienda déficit calórico; se prioriza ganar o mantener peso.'),
    (2, N'Normal',    18.50, 25.00, N'MANTENER', N'IMC dentro del rango saludable.'),
    (3, N'Sobrepeso', 25.00, 30.00, N'BAJAR',    N'IMC elevado: no se recomienda superávit calórico.'),
    (4, N'Obesidad',  30.00, 99.99, N'BAJAR',    N'IMC muy elevado: reducción gradual y seguimiento con el nutricionista.')
) AS s (Orden, Nombre, ImcMin, ImcMax, Objetivo, Mensaje)
INNER JOIN dbo.ObjetivosNutricionales o ON o.Codigo = s.Objetivo
ORDER BY s.Orden;

INSERT INTO dbo.CategoriaImcObjetivos (CategoriaImcId, ObjetivoId)
SELECT c.Id, o.Id
FROM (VALUES
    (N'Bajo peso', N'GANAR'), (N'Bajo peso', N'MANTENER'),
    (N'Normal', N'BAJAR'), (N'Normal', N'MANTENER'), (N'Normal', N'GANAR'),
    (N'Sobrepeso', N'BAJAR'), (N'Sobrepeso', N'MANTENER'),
    (N'Obesidad', N'BAJAR')
) AS s (Categoria, Objetivo)
INNER JOIN dbo.CategoriasImc c ON c.Nombre = s.Categoria
INNER JOIN dbo.ObjetivosNutricionales o ON o.Codigo = s.Objetivo;

INSERT INTO dbo.CategoriasAlimento (Codigo, Nombre) VALUES
    (N'LACTEO',          N'Lácteos y bebidas lácteas'),
    (N'CEREAL',          N'Cereales y tubérculos'),
    (N'FRUTA',           N'Frutas'),
    (N'VERDURA',         N'Verduras'),
    (N'PROTEINA',        N'Carnes, huevos y legumbres'),
    (N'GRASA_SALUDABLE', N'Grasas saludables y frutos secos'),
    (N'BEBIDA',          N'Bebidas'),
    (N'SNACK',           N'Comida rápida y snacks');

INSERT INTO dbo.TiposComida (Nombre, Orden, PorcentajeCalorias) VALUES
    (N'Desayuno',        1, 25),
    (N'Merienda mañana', 2, 10),
    (N'Almuerzo',        3, 35),
    (N'Merienda tarde',  4, 10),
    (N'Cena',            5, 20);

INSERT INTO dbo.TipoComidaCategorias (TipoComidaId, CategoriaAlimentoId, Orden)
SELECT t.Id, c.Id, s.Orden
FROM (VALUES
    (N'Desayuno', N'LACTEO', 1), (N'Desayuno', N'CEREAL', 2), (N'Desayuno', N'FRUTA', 3),
    (N'Merienda mañana', N'FRUTA', 1), (N'Merienda mañana', N'GRASA_SALUDABLE', 2),
    (N'Almuerzo', N'PROTEINA', 1), (N'Almuerzo', N'CEREAL', 2), (N'Almuerzo', N'VERDURA', 3), (N'Almuerzo', N'FRUTA', 4),
    (N'Merienda tarde', N'LACTEO', 1), (N'Merienda tarde', N'FRUTA', 2),
    (N'Cena', N'PROTEINA', 1), (N'Cena', N'VERDURA', 2), (N'Cena', N'CEREAL', 3)
) AS s (TipoComida, Categoria, Orden)
INNER JOIN dbo.TiposComida t ON t.Nombre = s.TipoComida
INNER JOIN dbo.CategoriasAlimento c ON c.Codigo = s.Categoria;

INSERT INTO dbo.Alimentos (Nombre, CategoriaAlimentoId, PorcionDescripcion, PorcionGramos, Calorias, Proteinas, Carbohidratos, Grasas, Fibra, Azucares, SodioMg)
SELECT s.Nombre, c.Id, s.Porcion, s.Gramos, s.Kcal, s.Prot, s.Carb, s.Gras, s.Fibra, s.Azucar, s.Sodio
FROM (VALUES
    (N'Leche semidescremada',          N'LACTEO', N'1 taza (240 ml)',          240, 120,  8.0, 12.0,  4.5,  0.0, 12.0, 105),
    (N'Yogur natural',                 N'LACTEO', N'1 vaso (200 g)',           200, 122,  7.0, 14.0,  4.0,  0.0, 14.0,  92),
    (N'Queso fresco',                  N'LACTEO', N'2 rebanadas (50 g)',        50, 132,  9.0,  1.5, 10.0,  0.0,  0.5, 230),
    (N'Api de maíz morado',            N'LACTEO', N'1 vaso (250 ml)',          250, 160,  4.0, 32.0,  2.0,  1.0, 18.0,  40),
    (N'Leche con quinua',              N'LACTEO', N'1 taza (250 ml)',          250, 180,  8.5, 26.0,  4.5,  1.5, 14.0, 110),
    (N'Pan integral',                  N'CEREAL', N'2 rebanadas (60 g)',        60, 150,  6.0, 26.0,  2.0,  4.0,  3.0, 270),
    (N'Avena cocida',                  N'CEREAL', N'1 taza (240 g)',           240, 160,  6.0, 27.0,  3.0,  4.0,  1.0,  10),
    (N'Arroz blanco cocido',           N'CEREAL', N'1 taza (160 g)',           160, 205,  4.3, 45.0,  0.4,  0.6,  0.0,   2),
    (N'Quinua cocida',                 N'CEREAL', N'1 taza (185 g)',           185, 222,  8.0, 39.0,  3.5,  5.0,  1.6,  13),
    (N'Papa cocida',                   N'CEREAL', N'1 unidad mediana (150 g)', 150, 130,  3.0, 30.0,  0.2,  2.5,  1.3,   8),
    (N'Fideo integral cocido',         N'CEREAL', N'1 taza (140 g)',           140, 174,  7.5, 37.0,  0.8,  6.0,  1.0,   4),
    (N'Marraqueta',                    N'CEREAL', N'1 unidad (70 g)',           70, 190,  6.0, 38.0,  1.5,  1.5,  1.5, 380),
    (N'Manzana',                       N'FRUTA',  N'1 unidad mediana (180 g)', 180,  95,  0.5, 25.0,  0.3,  4.4, 19.0,   2),
    (N'Plátano',                       N'FRUTA',  N'1 unidad mediana (120 g)', 120, 105,  1.3, 27.0,  0.4,  3.1, 14.0,   1),
    (N'Naranja',                       N'FRUTA',  N'1 unidad mediana (130 g)', 130,  62,  1.2, 15.0,  0.2,  3.1, 12.0,   0),
    (N'Papaya',                        N'FRUTA',  N'1 taza en cubos (145 g)',  145,  62,  0.7, 16.0,  0.4,  2.5, 11.0,  12),
    (N'Mandarina',                     N'FRUTA',  N'2 unidades (150 g)',       150,  80,  1.2, 20.0,  0.5,  2.7, 16.0,   3),
    (N'Frutilla',                      N'FRUTA',  N'1 taza (150 g)',           150,  48,  1.0, 11.5,  0.5,  3.0,  7.0,   2),
    (N'Ensalada mixta',                N'VERDURA', N'1 plato (150 g)',         150,  30,  1.5,  6.0,  0.3,  2.0,  3.5,  15),
    (N'Brócoli al vapor',              N'VERDURA', N'1 taza (150 g)',          150,  52,  4.2, 10.0,  0.6,  5.0,  2.0,  48),
    (N'Zanahoria cocida',              N'VERDURA', N'1 taza (150 g)',          150,  54,  1.2, 12.5,  0.3,  4.5,  5.0,  90),
    (N'Vainitas salteadas',            N'VERDURA', N'1 taza (125 g)',          125,  44,  2.4,  9.8,  0.3,  4.0,  2.0,   6),
    (N'Sopa de verduras',              N'VERDURA', N'1 plato (300 ml)',        300,  90,  3.0, 15.0,  2.0,  3.5,  4.0, 450),
    (N'Pechuga de pollo a la plancha', N'PROTEINA', N'1 filete (120 g)',       120, 198, 37.0,  0.0,  4.3,  0.0,  0.0,  88),
    (N'Huevo duro',                    N'PROTEINA', N'2 unidades (100 g)',     100, 155, 13.0,  1.1, 10.6,  0.0,  1.1, 124),
    (N'Carne de res magra',            N'PROTEINA', N'1 porción (110 g)',      110, 200, 29.0,  0.0,  9.0,  0.0,  0.0,  66),
    (N'Trucha al horno',               N'PROTEINA', N'1 filete (120 g)',       120, 170, 25.0,  0.0,  7.5,  0.0,  0.0,  62),
    (N'Lentejas guisadas',             N'PROTEINA', N'1 taza (200 g)',         200, 230, 18.0, 40.0,  0.8, 15.6,  3.6,   8),
    (N'Atún en agua',                  N'PROTEINA', N'1 lata escurrida (120 g)', 120, 140, 30.0, 0.0, 1.2,  0.0,  0.0, 380),
    (N'Maní tostado sin sal',          N'GRASA_SALUDABLE', N'1 puñado (30 g)', 30, 170,  7.0,  6.0, 14.0,  2.5,  1.2,   2),
    (N'Almendras',                     N'GRASA_SALUDABLE', N'1 puñado (28 g)', 28, 164,  6.0,  6.0, 14.0,  3.5,  1.2,   0),
    (N'Palta',                         N'GRASA_SALUDABLE', N'1/2 unidad (70 g)', 70, 112, 1.4,  6.0, 10.3,  4.7,  0.5,   5),
    -- Alimentos poco saludables (para probar alertas)
    (N'Salteña',                       N'SNACK',  N'1 unidad (150 g)',         150, 380, 12.0, 40.0, 19.0,  1.5,  6.0, 650),
    (N'Gaseosa',                       N'BEBIDA', N'1 vaso (500 ml)',          500, 210,  0.0, 53.0,  0.0,  0.0, 53.0,  45),
    (N'Papas fritas de bolsa',         N'SNACK',  N'1 bolsa (60 g)',            60, 320,  4.0, 32.0, 20.0,  2.5,  0.5, 380)
) AS s (Nombre, Categoria, Porcion, Gramos, Kcal, Prot, Carb, Gras, Fibra, Azucar, Sodio)
INNER JOIN dbo.CategoriasAlimento c ON c.Codigo = s.Categoria;

-- BEBIDA y SNACK no están en la plantilla de comidas, así que el motor de
-- recomendaciones nunca los sugiere; solo sirven para registrar el consumo real.

INSERT INTO dbo.Estudiantes (UsuarioId, Nombres, Apellidos, FechaNacimiento, Sexo, CursoId, PesoKg, AlturaCm, NivelActividadId, ObjetivoId)
SELECT u.Id, s.Nombres, s.Apellidos, s.FechaNacimiento, s.Sexo, c.Id, s.Peso, s.Altura, n.Id, o.Id
FROM (VALUES
    (1, N'ana.mamani@innovare.edu.bo',      N'Ana',   N'Mamani',    CAST('2010-05-10' AS DATE), 'F', N'5to Secundaria A', 45.0, 165.0, N'LIGERO',     N'MANTENER'),
    (2, N'luis.quispe@innovare.edu.bo',     N'Luis',  N'Quispe',    CAST('2009-08-22' AS DATE), 'M', N'6to Secundaria A', 65.0, 172.0, N'ACTIVO',     N'MANTENER'),
    (3, N'carla.flores@innovare.edu.bo',    N'Carla', N'Flores',    CAST('2011-02-14' AS DATE), 'F', N'5to Secundaria A', 70.0, 160.0, N'SEDENTARIO', N'BAJAR'),
    (4, N'diego.choque@innovare.edu.bo',    N'Diego', N'Choque',    CAST('2010-11-30' AS DATE), 'M', N'5to Secundaria A', 95.0, 170.0, N'MODERADO',   N'GANAR'),
    (5, N'sofia.gutierrez@innovare.edu.bo', N'Sofía', N'Gutiérrez', CAST('2009-03-03' AS DATE), 'F', N'6to Secundaria A', 55.0, 162.0, N'MODERADO',   N'MANTENER'),
    (6, N'mateo.condori@innovare.edu.bo',   N'Mateo', N'Condori',   CAST('2009-12-12' AS DATE), 'M', N'6to Secundaria A', 72.0, 178.0, N'MUY_ACTIVO', N'GANAR')
) AS s (Orden, Correo, Nombres, Apellidos, FechaNacimiento, Sexo, Curso, Peso, Altura, Nivel, Objetivo)
INNER JOIN dbo.Usuarios u ON u.Correo = s.Correo
INNER JOIN dbo.Cursos c ON c.Nombre = s.Curso
INNER JOIN dbo.NivelesActividad n ON n.Codigo = s.Nivel
INNER JOIN dbo.ObjetivosNutricionales o ON o.Codigo = s.Objetivo
ORDER BY s.Orden;

-- Historial de mediciones (hace 60 días, 30 días y hoy)
INSERT INTO dbo.MedicionesEstudiante (EstudianteId, Fecha, PesoKg, AlturaCm)
SELECT e.Id, DATEADD(DAY, -d.Dias, CAST(GETDATE() AS DATE)), e.PesoKg + d.Delta, e.AlturaCm
FROM dbo.Estudiantes e
CROSS JOIN (VALUES (60, 1.5), (30, 0.8), (0, 0.0)) AS d (Dias, Delta);

INSERT INTO dbo.AlimentosExcluidos (EstudianteId, AlimentoId, Motivo)
SELECT e.Id, a.Id, N'Alergia'
FROM dbo.Estudiantes e CROSS JOIN dbo.Alimentos a
WHERE e.Nombres = N'Carla' AND a.Nombre = N'Maní tostado sin sal';

INSERT INTO dbo.TiposAlerta (Codigo, Nombre, Descripcion, Umbral, Unidad, Nivel) VALUES
    (N'CALORIAS_EXCESO', N'Exceso de calorías',     N'Consumo del día por encima del % indicado del objetivo calórico.', 130,  N'%',   N'Media'),
    (N'CALORIAS_DEFICIT', N'Déficit de calorías',   N'Consumo del día por debajo del % indicado del objetivo calórico.',  50,  N'%',   N'Media'),
    (N'AZUCAR_EXCESO',   N'Exceso de azúcar',       N'Azúcares del día por encima del límite.',                          50,  N'g',   N'Alta'),
    (N'SODIO_EXCESO',    N'Exceso de sodio',        N'Sodio del día por encima del límite.',                           2300,  N'mg',  N'Media'),
    (N'AGUA_BAJA',       N'Consumo de agua bajo',   N'Agua del día por debajo del mínimo.',                            1500,  N'ml',  N'Baja'),
    (N'SUENO_BAJO',      N'Pocas horas de sueño',   N'Horas de sueño por debajo del mínimo.',                             7,  N'h',   N'Media'),
    (N'ACTIVIDAD_BAJA',  N'Actividad física baja',  N'Minutos de actividad por debajo del mínimo.',                      30,  N'min', N'Baja'),
    (N'IMC_RIESGO',      N'IMC en zona de riesgo',  N'IMC en categoría Bajo peso u Obesidad.',                            0,  N'IMC', N'Alta');

-- Registros de los últimos 7 días para Luis, Carla y Diego (para ver reportes y dashboard)
;WITH Dias AS (SELECT n FROM (VALUES (1),(2),(3),(4),(5),(6),(7)) AS t(n))
INSERT INTO dbo.RegistrosConsumo (EstudianteId, Fecha, TipoComidaId, AlimentoId, Porciones)
SELECT e.Id, DATEADD(DAY, -d.n, CAST(GETDATE() AS DATE)), t.Id, a.Id, p.Porciones
FROM Dias d
CROSS JOIN (VALUES
    (N'Luis',  N'Desayuno', N'Leche semidescremada', 2.0), (N'Luis', N'Desayuno', N'Avena cocida', 2.0),
    (N'Luis',  N'Almuerzo', N'Pechuga de pollo a la plancha', 2.0), (N'Luis', N'Almuerzo', N'Quinua cocida', 2.0),
    (N'Luis',  N'Merienda tarde', N'Plátano', 1.0), (N'Luis', N'Cena', N'Trucha al horno', 1.5),
    (N'Luis',  N'Cena', N'Arroz blanco cocido', 1.5),
    (N'Carla', N'Desayuno', N'Marraqueta', 2.0), (N'Carla', N'Desayuno', N'Gaseosa', 1.0),
    (N'Carla', N'Merienda mañana', N'Salteña', 1.0), (N'Carla', N'Almuerzo', N'Carne de res magra', 1.5),
    (N'Carla', N'Almuerzo', N'Arroz blanco cocido', 2.0), (N'Carla', N'Merienda tarde', N'Papas fritas de bolsa', 1.0),
    (N'Diego', N'Desayuno', N'Pan integral', 1.0), (N'Diego', N'Almuerzo', N'Lentejas guisadas', 1.0),
    (N'Diego', N'Cena', N'Ensalada mixta', 1.0)
) AS p (Estudiante, TipoComida, Alimento, Porciones)
INNER JOIN dbo.Estudiantes e ON e.Nombres = p.Estudiante
INNER JOIN dbo.TiposComida t ON t.Nombre = p.TipoComida
INNER JOIN dbo.Alimentos a ON a.Nombre = p.Alimento;

;WITH Dias AS (SELECT n FROM (VALUES (1),(2),(3),(4),(5),(6),(7)) AS t(n))
INSERT INTO dbo.RegistrosHabitos (EstudianteId, Fecha, HorasSueno, AguaMl, MinutosActividad, Observaciones)
SELECT e.Id, DATEADD(DAY, -d.n, CAST(GETDATE() AS DATE)),
       h.Sueno + (d.n % 2) * 0.5, h.Agua + (d.n % 3) * 150, h.Actividad + (d.n % 2) * 10, NULL
FROM Dias d
CROSS JOIN (VALUES
    (N'Luis',  8.0, 2200, 60),
    (N'Carla', 6.0, 900,  10),
    (N'Diego', 7.0, 1600, 30)
) AS h (Estudiante, Sueno, Agua, Actividad)
INNER JOIN dbo.Estudiantes e ON e.Nombres = h.Estudiante;

-- Menú diario de ejemplo creado por la nutricionista (HU-16)
INSERT INTO dbo.MenusDiarios (Nombre, Fecha, Descripcion, CreadoPorId)
VALUES (N'Menú escolar balanceado', CAST(GETDATE() AS DATE), N'Menú base del comedor escolar.',
        (SELECT Id FROM dbo.Usuarios WHERE Correo = N'nutricion@innovare.edu.bo'));

INSERT INTO dbo.MenuDetalles (MenuId, TipoComidaId, AlimentoId, Porciones)
SELECT m.Id, t.Id, a.Id, s.Porciones
FROM (VALUES
    (N'Desayuno', N'Leche con quinua', 1.0), (N'Desayuno', N'Pan integral', 1.0), (N'Desayuno', N'Papaya', 1.0),
    (N'Almuerzo', N'Sopa de verduras', 1.0), (N'Almuerzo', N'Pechuga de pollo a la plancha', 1.0),
    (N'Almuerzo', N'Arroz blanco cocido', 1.0), (N'Almuerzo', N'Ensalada mixta', 1.0),
    (N'Merienda tarde', N'Yogur natural', 1.0), (N'Merienda tarde', N'Manzana', 1.0)
) AS s (TipoComida, Alimento, Porciones)
CROSS JOIN (SELECT TOP (1) Id FROM dbo.MenusDiarios ORDER BY Id) AS m
INNER JOIN dbo.TiposComida t ON t.Nombre = s.TipoComida
INNER JOIN dbo.Alimentos a ON a.Nombre = s.Alimento;

-- Cita nutricional de ejemplo (mañana a las 10:00)
INSERT INTO dbo.Citas (EstudianteId, NutricionistaId, FechaHora, DuracionMinutos, Motivo)
SELECT e.Id, u.Id, DATEADD(HOUR, 10, CAST(DATEADD(DAY, 1, CAST(GETDATE() AS DATE)) AS DATETIME2)), 30, N'Control de hábitos y revisión de alimentación'
FROM dbo.Estudiantes e CROSS JOIN dbo.Usuarios u
WHERE e.Nombres = N'Carla' AND u.Correo = N'nutricion@innovare.edu.bo';

INSERT INTO dbo.Notificaciones (UsuarioId, Titulo, Mensaje, Tipo)
SELECT Id, N'Bienvenido a SmartNutriTracker', N'Registra tus comidas y hábitos cada día para recibir recomendaciones.', N'Sistema'
FROM dbo.Usuarios;

INSERT INTO dbo.LogsAuditoria (UsuarioId, Accion, Entidad, Detalle)
VALUES (NULL, N'INSTALACION', N'Sistema', N'Base de datos creada con datos de prueba.');
GO

/* Verificación */
SELECT 'Usuarios' AS Tabla, COUNT(*) AS Filas FROM dbo.Usuarios UNION ALL
SELECT 'Estudiantes', COUNT(*) FROM dbo.Estudiantes UNION ALL
SELECT 'Alimentos', COUNT(*) FROM dbo.Alimentos UNION ALL
SELECT 'CategoriasImc', COUNT(*) FROM dbo.CategoriasImc UNION ALL
SELECT 'TiposComida', COUNT(*) FROM dbo.TiposComida UNION ALL
SELECT 'RegistrosConsumo', COUNT(*) FROM dbo.RegistrosConsumo UNION ALL
SELECT 'RegistrosHabitos', COUNT(*) FROM dbo.RegistrosHabitos UNION ALL
SELECT 'TiposAlerta', COUNT(*) FROM dbo.TiposAlerta;
GO
