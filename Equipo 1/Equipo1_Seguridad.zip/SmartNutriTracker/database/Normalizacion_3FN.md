# Normalización de la base de datos SmartNutriTrackerDB (hasta 3FN)

La base tiene **26 tablas**. Todas cumplen la Primera, Segunda y Tercera Forma Normal.

## Tablas por módulo

| Módulo | Tablas |
|---|---|
| Equipo 1 · Seguridad | `Roles`, `Usuarios`, `LogsAuditoria` |
| Catálogos | `NivelesActividad`, `ObjetivosNutricionales`, `CategoriasImc`, `CategoriaImcObjetivos`, `CategoriasAlimento`, `TiposComida`, `TipoComidaCategorias` |
| Equipo 2 · Perfil | `Cursos`, `Estudiantes`, `MedicionesEstudiante` |
| Equipo 3 · Alimentos | `Alimentos`, `MenusDiarios`, `MenuDetalles` |
| Equipo 4 · Hábitos | `RegistrosConsumo`, `RegistrosHabitos` |
| Equipo 5 · Recomendaciones | `AlimentosExcluidos`, `Recomendaciones`, `RecomendacionDetalles`, `RecomendacionObservaciones` |
| Equipo 6 · Alertas y citas | `TiposAlerta`, `Alertas`, `Notificaciones`, `Citas` |

## 1FN – Valores atómicos, sin grupos repetidos

| Problema que se evitó | Solución |
|---|---|
| Guardar "objetivos permitidos" como `"BAJAR,MANTENER"` en una sola columna | Tabla puente `CategoriaImcObjetivos (CategoriaImcId, ObjetivoId)` |
| Guardar las observaciones de una recomendación separadas por `|` | Tabla `RecomendacionObservaciones` (una fila por observación) |
| Columnas `Alimento1`, `Alimento2`… en un menú | Tablas detalle `MenuDetalles` y `RecomendacionDetalles` |
| Varios pesos del estudiante en la misma fila | Tabla `MedicionesEstudiante` (una fila por fecha) |

Todas las tablas tienen clave primaria y sus columnas guardan un único valor.

## 2FN – Sin dependencias parciales

Las tablas con **clave compuesta** son `CategoriaImcObjetivos`, `TipoComidaCategorias` y `AlimentosExcluidos`.
En ellas, todos los atributos que no son clave dependen de la clave completa:

- `TipoComidaCategorias.Orden` depende de (TipoComida, Categoría), no de solo una de las dos.
- `AlimentosExcluidos.Motivo` depende de (Estudiante, Alimento).

El resto de tablas usa una clave simple (`Id`), así que no puede haber dependencias parciales.

## 3FN – Sin dependencias transitivas

| Dependencia transitiva evitada | Cómo se resolvió |
|---|---|
| `Estudiante → NivelActividad → Factor` | `Estudiantes.NivelActividadId` (FK). El factor se guarda solo en `NivelesActividad`. |
| `Estudiante → Objetivo → % de macros` | `Estudiantes.ObjetivoId` (FK a `ObjetivosNutricionales`). |
| `Estudiante → Curso → Docente` | `Estudiantes.CursoId` y `Cursos.DocenteId`. |
| `Alimento → Categoría → nombre de la categoría` | `Alimentos.CategoriaAlimentoId` (FK a `CategoriasAlimento`). |
| `Usuario → Rol → nombre del rol` | `Usuarios.RolId` (FK a `Roles`). |
| `Alerta → Tipo → umbral / nivel` | `Alertas.TipoAlertaId`. El umbral y el nivel viven en `TiposAlerta`. |
| Registro y menú: `Detalle → Alimento → calorías` | Los detalles guardan solo `AlimentoId` y `Porciones`. Las calorías y los macros **se calculan**: `Alimento.Calorias × Porciones`. |

### Datos derivados que NO se guardan (se calculan)

- **IMC**: se obtiene de peso y talla. Hay una vista `vw_EstudiantesImc` para consultarlo.
- **TMB y gasto energético**: se obtienen con Mifflin-St Jeor a partir del peso, la talla, la edad, el sexo y el factor.
- **Totales de menús, consumos y recomendaciones**: se calculan sumando los detalles. Hay una vista `vw_ConsumoDiario`.
- **Edad**: se obtiene de `FechaNacimiento`.

### Decisión de diseño: la "foto" de la recomendación

`Recomendaciones` guarda `PesoKg`, `AlturaCm`, `Edad`, `FactorActividad`, `CategoriaImcId` y las calorías y macros objetivo.
**Esto no viola la 3FN**: no son copias de otra tabla, sino **hechos históricos** de esa recomendación.
Esos valores dependen únicamente del `Id` de la recomendación:

- Si mañana el estudiante cambia de peso, la recomendación de hoy debe seguir mostrando con qué datos se calculó.
- Si el nutricionista modifica los rangos de IMC o los porcentajes de un objetivo, las recomendaciones antiguas no deben cambiar.

Lo mismo aplica a `Alertas.ValorRegistrado`: es el valor medido el día de la alerta.

## Integridad

- **Claves foráneas** en todas las relaciones (39 FK).
  - `ON DELETE CASCADE` solo en las tablas que pertenecen por completo a su padre: los registros del estudiante y los detalles de menús y recomendaciones.
- **CHECK** para dominios cerrados:
  - Sexo `M/F`.
  - Rangos de peso, talla, porciones, agua, sueño y factor de actividad.
  - Estados permitidos de recomendaciones y citas.
  - Niveles de alerta.
  - La suma de % de macros debe ser 100.
- **UNIQUE** donde corresponde:
  - Correo de usuario y nombre de alimento.
  - Un registro de hábitos por estudiante y día.
  - Una alerta por tipo, estudiante y día.
  - Un usuario vinculado como máximo a un estudiante (índice filtrado).
