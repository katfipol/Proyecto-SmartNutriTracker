# SmartNutriTracker · Equipo 1 – Autenticación y Seguridad

**Historias de usuario:** HU-01 a HU-05  
**Proyecto:** SmartNutriTracker – Colegio "Innovare" · Programación Web III  
**Tecnologías:** .NET 10 · ASP.NET Core Web API · Entity Framework Core 10 · SQL Server · HTML + JS + Bootstrap 5

Este ZIP contiene **solo la parte del Equipo 1**, con las mismas rutas del proyecto completo.
Para tener el sistema funcionando, **descomprima los 6 ZIP en la misma carpeta**: los archivos no se pisan.

---

## 1. Historias de usuario implementadas

| HU | Descripción | Implementación |
|---|---|---|
| HU-01 | Registrar usuarios con roles | `UsuariosService.CrearAsync` · `POST /api/usuarios` · pantalla Usuarios |
| HU-02 | Iniciar sesión con correo y contraseña | `AuthService.LoginAsync` · `POST /api/auth/login` · `index.html` |
| HU-03 | Sesión segura con JWT | Token HMAC-SHA256 de 8 h (`AuthService.GenerarToken`), validación en `Program.cs` |
| HU-04 | Gestión de roles | Roles Admin/Docente/Nutricionista/Estudiante (`Common/Comunes.cs`), `[Authorize(Roles=…)]`, control por dato en `AccesoService` |
| HU-05 | Logger de auditoría | `AuditoriaService` guarda en `LogsAuditoria` cada acción sensible con IP · `GET /api/auditoria` |

### Además, este equipo entrega la BASE del sistema
Estos archivos los necesitan todos los equipos:
- `Program.cs`: registro de servicios, JWT, Swagger, rate limiting y frontend.
- `SmartNutriDbContext.cs` (parcial).
- `Common/Comunes.cs`: roles, excepciones, PBKDF2 y cabeceras de seguridad.
- `CatalogosService`.
- La estructura del frontend: `api.js`, `ui.js`, `estado.js`, `app.js`, CSS con la paleta verde y las librerías locales.

### Seguridad implementada
- **Contraseñas:** PBKDF2-SHA256 con 100.000 iteraciones y sal aleatoria. Política: 8 caracteres o más, con mayúscula, minúscula y número.
- **Protección del login:**
  - Bloqueo de 5 minutos tras 5 intentos fallidos.
  - Rate limiting de 10 intentos por minuto por IP.
  - Mensajes genéricos que no revelan si el correo existe.
- **Control de acceso por dato:** el estudiante solo ve lo suyo y el docente solo ve sus cursos.
- **Cabeceras de seguridad:** CSP sin scripts en línea, `X-Frame-Options` y `nosniff`.

## 2. Base de datos

**Script del equipo:** `database/por_equipo/1_Equipo1_Seguridad.sql`

Orden de ejecución en SSMS (base nueva): **Equipo 1 → 2 → 3 → 4 → 5 → 6**.
- El script del Equipo 1 crea la base desde cero.
- Cada script comprueba que ya se ejecutaron los anteriores.

### Tablas del equipo
- `Roles`
- `Usuarios`
- `LogsAuditoria`

### Normalización (3FN)
- `Usuarios.RolId` es una FK a `Roles`: el nombre del rol no se repite en cada usuario (3FN).
- `LogsAuditoria` guarda solo `UsuarioId` (FK), no el correo ni el nombre del usuario.
- Restricciones `UNIQUE` en `Usuarios.Correo` y `Roles.Nombre`.

## 3. API REST (endpoints del equipo)

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/api/auth/login` | Público | Inicia sesión con correo y contraseña. Devuelve el token JWT. |
| GET | `/api/auth/perfil` | Cualquier usuario autenticado | Datos del usuario autenticado. |
| POST | `/api/auth/cambiar-password` | Cualquier usuario autenticado | Cambia la contraseña del usuario autenticado. |
| GET | `/api/usuarios` | Admin | Listar |
| POST | `/api/usuarios` | Admin | Crear |
| PUT | `/api/usuarios/{id}` | Admin | Actualizar |
| POST | `/api/usuarios/{id}/reset-password` | Admin | Restablecer contraseña |
| POST | `/api/usuarios/{id}/desbloquear` | Admin | Desbloquear cuenta |
| GET | `/api/auditoria` | Admin | Consultar el log de auditoría (filtros y paginación) |
| GET | `/api/catalogos` | Cualquier usuario autenticado | Catálogos para formularios (cursos, niveles, objetivos, categorías, tiempos de comida) |

Todas las rutas (salvo el login) requieren el encabezado `Authorization: Bearer <token>`.
Para probarlas en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 4. Frontend (pantallas del equipo)
- Inicio de sesión (`index.html`)
- Estructura de la aplicación: menú por rol, barra superior y campana (`app.html`, `app.js`)
- Usuarios (`vistas/usuarios.js`)
- Auditoría (`vistas/auditoria.js`)
- Cambiar contraseña (`vistas/cuenta.js`)

## 5. Archivos del equipo

**Backend**
- `src/SmartNutriTracker.Api/Common/Comunes.cs`
- `src/SmartNutriTracker.Api/Data/SmartNutriDbContext.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/ContextoDatos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Entidades.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Servicios/AuditoriaService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Servicios/AuthService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Servicios/CatalogosService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Servicios/UsuarioActualYAcceso.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo1_Seguridad/Servicios/UsuariosService.cs`
- `src/SmartNutriTracker.Api/Program.cs`

**Frontend**
- `src/SmartNutriTracker.Api/wwwroot/app.html`
- `src/SmartNutriTracker.Api/wwwroot/css/app.css`
- `src/SmartNutriTracker.Api/wwwroot/img/logo.svg`
- `src/SmartNutriTracker.Api/wwwroot/index.html`
- `src/SmartNutriTracker.Api/wwwroot/js/api.js`
- `src/SmartNutriTracker.Api/wwwroot/js/app.js`
- `src/SmartNutriTracker.Api/wwwroot/js/estado.js`
- `src/SmartNutriTracker.Api/wwwroot/js/login.js`
- `src/SmartNutriTracker.Api/wwwroot/js/ui.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/auditoria.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/cuenta.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/usuarios.js`
- `src/SmartNutriTracker.Api/wwwroot/lib/` (Bootstrap, iconos y Chart.js locales)

**Base de datos**
- `database/Normalizacion_3FN.md`
- `database/SmartNutriTracker_BD.sql`
- `database/SmartNutriTracker_Esquema_Diagrama.sql`
- `database/por_equipo/1_Equipo1_Seguridad.sql`

**Pruebas**
- `tests/SmartNutriTracker.Tests/PasswordHasherTests.cs`

**Otros**
- `.gitignore`
- `README.md`
- `SmartNutriTracker.slnx`
- `src/SmartNutriTracker.Api/Properties/launchSettings.json`
- `src/SmartNutriTracker.Api/SmartNutriTracker.Api.csproj`
- `src/SmartNutriTracker.Api/appsettings.Development.json`
- `src/SmartNutriTracker.Api/appsettings.json`

## 6. Dependencias con otros equipos
Ninguno. Es la base: todos los demás equipos dependen de este.

La integración se hace así:
- **Clase parcial `SmartNutriDbContext`:** cada equipo aporta sus `DbSet` y su configuración en `ContextoDatos.cs`, mediante el método `ConfigurarEquipo1`.
- **Clase parcial `Mapeos`:** cada equipo aporta sus conversiones a DTO.
- **Inyección de dependencias:** los servicios se registran en `Program.cs`, que entrega el Equipo 1.

## 7. Cómo ejecutar el sistema completo
1. Descomprima los 6 ZIP en la misma carpeta (por ejemplo `SmartNutriTracker/`).
2. Ejecute en SSMS los scripts `database/por_equipo/1_…sql` a `6_…sql`, en orden.
3. Ajuste la cadena de conexión en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
4. En la carpeta raíz, ejecute:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
5. Abra http://localhost:5200 para el sistema y http://localhost:5200/swagger para la API.

**Usuarios de prueba** (contraseña `Innovare2026!`):

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |
