# SmartNutriTracker – Colegio "Innovare"

Sistema web de seguimiento nutricional escolar para la materia Programación Web III (Proyecto Final). Incluye los **6 equipos**.

- **Backend:** API REST en **.NET 10** con Entity Framework Core 10 y **SQL Server**.
- **Seguridad:** JWT, roles, PBKDF2, bloqueo de cuenta y auditoría.
- **Documentación de la API:** Swagger.
- **Frontend:** HTML + JavaScript + Bootstrap 5, con paleta verde. Lo sirve la misma API, así que basta un solo `dotnet run`.
- **Base de datos:** normalizada hasta 3FN (ver `database/Normalizacion_3FN.md`).

---

## 1. Requisitos

- .NET 10 SDK
- SQL Server 2019 o superior (sirve SQL Server Express)
- SQL Server Management Studio, Visual Studio 2026 o VS Code

No hace falta internet para usar el sistema. Bootstrap, los iconos y Chart.js están en `wwwroot/lib`.

## 2. Instalación paso a paso

### 2.1 Base de datos

1. Abra **SSMS** y conéctese a su servidor (por ejemplo `b405-06\SQLEXPRESS`).
2. Ejecute en orden los scripts de `database/por_equipo/` (1 → 6), cada uno completo con **F5**.
   También puede ejecutar el script único `database/SmartNutriTracker_BD.sql`; el resultado es el mismo.
   - El script **elimina y vuelve a crear** la base `SmartNutriTrackerDB`.
   - También carga datos de prueba: 10 usuarios, 6 estudiantes, 35 alimentos, una semana de registros, un menú y una cita.
3. Al final verá una tabla con la cantidad de filas de cada tabla.

### 2.2 Cadena de conexión

Edite `src/SmartNutriTracker.Api/appsettings.json`:

```json
"ConnectionStrings": {
  "SmartNutriDb": "Server=.\\SQLEXPRESS;Database=SmartNutriTrackerDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True"
}
```

- `.\\SQLEXPRESS` es la instancia local de SQL Express. Si su servidor tiene otro nombre, use por ejemplo `b405-06\\SQLEXPRESS` (en JSON la barra va doble).
- Con usuario de SQL Server, la cadena es: `Server=localhost;Database=SmartNutriTrackerDB;User Id=sa;Password=SuClave;TrustServerCertificate=True`

### 2.3 Ejecutar

```bash
dotnet restore
dotnet run --project src/SmartNutriTracker.Api
```

- **Frontend:** http://localhost:5200
- **Swagger:** http://localhost:5200/swagger
- **Salud de la API y la BD:** http://localhost:5200/api/salud

En Visual Studio abra `SmartNutriTracker.slnx` y presione F5.

### 2.4 Pruebas

```bash
dotnet test
```

Hay 56 casos que cubren el cálculo nutricional, el motor de menús, las reglas de alertas y las contraseñas.

## 3. Usuarios de prueba

La contraseña de todos es **`Innovare2026!`**.

| Rol | Correo | Qué puede hacer |
|---|---|---|
| Admin | admin@innovare.edu.bo | Todo, incluidos usuarios, roles y auditoría |
| Nutricionista | nutricion@innovare.edu.bo | Alimentos, menús, reglas, recomendaciones, citas y alertas |
| Docente | jvargas@innovare.edu.bo | Estudiantes de **su** curso (5to A): registro, reportes y alertas |
| Docente | ltorrez@innovare.edu.bo | Estudiantes de 6to A |
| Estudiante | carla.flores@innovare.edu.bo | Sus datos: registro diario, perfil, recomendaciones, reporte y citas |

Otros estudiantes con cuenta:

- ana.mamani@innovare.edu.bo (bajo peso)
- luis.quispe@innovare.edu.bo (normal)
- diego.choque@innovare.edu.bo (obesidad)
- sofia.gutierrez@innovare.edu.bo
- mateo.condori@innovare.edu.bo

## 4. Módulos e historias de usuario

| Equipo | HU | Backend (API) | Frontend |
|---|---|---|---|
| 1 Seguridad | HU-01 a HU-05 | `/api/auth`, `/api/usuarios`, `/api/auditoria` | Login, Usuarios, Auditoría, Cambiar contraseña |
| 2 Perfil y reportes | HU-08 a HU-12 | `/api/estudiantes`, `/api/reportes` | Estudiantes, Mi perfil, Reporte semanal, Inicio (dashboard) |
| 3 Alimentos | HU-14 a HU-17 | `/api/alimentos`, `/api/menus` | Alimentos, Menús diarios (resumen en vivo) |
| 4 Hábitos | HU-19 a HU-22 | `/api/consumos`, `/api/habitos` | Registro diario + historial |
| 5 Recomendaciones | HU-23 a HU-26 | `/api/recomendaciones`, `/api/calculos`, `/api/reglas` | Recomendaciones, Reglas nutricionales |
| 6 Notificaciones | HU-27, HU-28, HU-29, HU-32 | `/api/alertas`, `/api/notificaciones`, `/api/citas` | Alertas, Notificaciones (campana), Citas |
| Scrum Master | HU-30, HU-31 | `tests/`, `.github/workflows/ci.yml` | — |

## 5. Seguridad implementada

- **Contraseñas:** PBKDF2-SHA256 con 100.000 iteraciones y sal aleatoria. Política mínima: 8 caracteres, con mayúscula, minúscula y número.
- **JWT:** firmado con HMAC-SHA256 y válido 8 horas. Incluye el `sub`, el nombre, el correo, el rol y el `estudianteId`.
- **Roles:**
  - Se aplican en cada endpoint con `[Authorize(Roles = ...)]`.
  - Además hay **control por dato**: un estudiante solo ve lo suyo y un docente solo ve sus cursos (`AccesoService`).
- **Protección del login:**
  - Bloqueo de 5 minutos tras 5 intentos fallidos.
  - Límite de 10 intentos por minuto por IP (rate limiting).
  - Mensajes de error genéricos.
- **Auditoría (HU-05):** la tabla `LogsAuditoria` registra los logins, los intentos fallidos y cada acción de crear, actualizar o eliminar, con la IP.
- **Logs globales (HU-29):** se escriben en consola y en un archivo diario en `logs/smartnutri-AAAA-MM-DD.log`.
- **Frontend:**
  - Todo el texto se escapa antes de mostrarse, para prevenir XSS.
  - Cabeceras de seguridad: CSP sin scripts en línea, `X-Frame-Options` y `nosniff`.
- **Errores:** las respuestas usan el formato estándar `ProblemDetails`, sin exponer detalles internos.

## 6. Automatizaciones

- **Alertas (HU-27):**
  - Se evalúan al registrar comidas o hábitos y cada día para el día anterior. Detectan exceso o déficit de calorías, exceso de azúcar o sodio, poca agua, poco sueño, poca actividad e IMC en riesgo.
  - Avisan al docente del curso, a los nutricionistas y al estudiante.
  - El nutricionista ajusta los umbrales desde la pantalla de reglas.
- **Recordatorios (HU-28):** un servicio en segundo plano envía:
  - un recordatorio diario (desde las 19:00) a los estudiantes que no registraron su día;
  - un aviso de cita 24 horas antes.
- **Recomendaciones (HU-23 a HU-26):**
  1. Calcula el IMC, la TMB (Mifflin-St Jeor) y el gasto energético total.
  2. Ajusta las calorías según el objetivo y la regla de IMC.
  3. Reparte las calorías por comida y elige alimentos por categoría, sin repetir en el día, evitando los excluidos y variando respecto a los menús anteriores.
  4. Escala las porciones y genera observaciones.

## 7. Estructura (dividida por equipos)

```
SmartNutriTracker/
├── database/
│   ├── por_equipo/1_Equipo1_Seguridad.sql … 6_Equipo6_Notificaciones.sql   ← ejecutar en orden 1→6
│   ├── SmartNutriTracker_BD.sql                 ← alternativa: todo en un solo script
│   ├── SmartNutriTracker_Esquema_Diagrama.sql   ← solo CREATE TABLE (drawDB / dbdiagram)
│   └── Normalizacion_3FN.md
├── src/SmartNutriTracker.Api/
│   ├── Program.cs, appsettings.json             ← base (Equipo 1)
│   ├── Common/Comunes.cs                        ← roles, excepciones, contraseñas (Equipo 1)
│   ├── Data/SmartNutriDbContext.cs              ← contexto PARCIAL: cada equipo agrega sus tablas
│   ├── Modulos/
│   │   ├── Equipo1_Seguridad/        Entidades, Dtos, Servicios, Controladores, ContextoDatos
│   │   ├── Equipo2_PerfilReportes/
│   │   ├── Equipo3_Alimentos/
│   │   ├── Equipo4_Habitos/
│   │   ├── Equipo5_Recomendaciones/  (+ Dominio: cálculo nutricional y motor de menús)
│   │   └── Equipo6_Notificaciones/   (+ Dominio: reglas de alertas, Logs)
│   └── wwwroot/                      frontend (js/vistas/*.js = una vista por pantalla)
├── tests/SmartNutriTracker.Tests/
└── .github/workflows/ci.yml
```

Cada equipo tiene su ZIP con **sus** archivos en las mismas rutas.
**Para armar el sistema completo, descomprima los 6 ZIP en la misma carpeta**: no se pisan archivos.

## 8. Problemas frecuentes

| Problema | Solución |
|---|---|
| `Cannot open database` / error de conexión | Revise el nombre del servidor en la cadena de conexión y que el script SQL se haya ejecutado. Pruebe en `/api/salud`. |
| `Login failed for user` | Con autenticación de Windows use `Trusted_Connection=True`. Con usuario SQL ponga `User Id` y `Password`. |
| El login dice "Cuenta bloqueada" | Espere 5 minutos o desbloquéela como Admin en **Usuarios**. |
| Puerto ocupado | Cambie `applicationUrl` en `Properties/launchSettings.json`. |
