// Aplicación principal: sesión, menú por rol y enrutador por hash
import { api, sesion } from './api.js';
import { estado } from './estado.js';
import { cargando, errorHtml, esc, iniciales, destruirGraficos } from './ui.js';

import * as inicio from './vistas/inicio.js';
import * as estudiantes from './vistas/estudiantes.js';
import * as perfil from './vistas/perfil.js';
import * as alimentos from './vistas/alimentos.js';
import * as menus from './vistas/menus.js';
import * as registro from './vistas/registro.js';
import * as recomendaciones from './vistas/recomendaciones.js';
import * as reportes from './vistas/reportes.js';
import * as alertas from './vistas/alertas.js';
import * as citas from './vistas/citas.js';
import * as notificaciones from './vistas/notificaciones.js';
import * as usuarios from './vistas/usuarios.js';
import * as reglas from './vistas/reglas.js';
import * as auditoria from './vistas/auditoria.js';
import * as cuenta from './vistas/cuenta.js';

const TODOS = ['Admin', 'Docente', 'Nutricionista', 'Estudiante'];
const PERSONAL = ['Admin', 'Docente', 'Nutricionista'];

// ruta, título, icono, roles, módulo, sección del menú (null = no aparece en el menú)
const RUTAS = [
  { ruta: 'inicio', titulo: 'Inicio', icono: 'bi-house', roles: TODOS, vista: inicio, seccion: 'General' },
  { ruta: 'registro', titulo: 'Registro diario', icono: 'bi-journal-check', roles: TODOS, vista: registro, seccion: 'General', tituloEst: 'Mi registro diario' },
  { ruta: 'perfil', titulo: 'Mi perfil', icono: 'bi-person-heart', roles: ['Estudiante'], vista: perfil, seccion: 'General' },
  { ruta: 'recomendaciones', titulo: 'Recomendaciones', icono: 'bi-stars', roles: TODOS, vista: recomendaciones, seccion: 'General', tituloEst: 'Mis recomendaciones' },
  { ruta: 'reportes', titulo: 'Reporte semanal', icono: 'bi-graph-up', roles: TODOS, vista: reportes, seccion: 'General', tituloEst: 'Mi reporte semanal' },
  { ruta: 'citas', titulo: 'Citas', icono: 'bi-calendar2-heart', roles: TODOS, vista: citas, seccion: 'General', tituloEst: 'Mis citas' },
  { ruta: 'estudiantes', titulo: 'Estudiantes', icono: 'bi-people', roles: PERSONAL, vista: estudiantes, seccion: 'Seguimiento' },
  { ruta: 'alertas', titulo: 'Alertas', icono: 'bi-exclamation-triangle', roles: PERSONAL, vista: alertas, seccion: 'Seguimiento' },
  { ruta: 'alimentos', titulo: 'Alimentos', icono: 'bi-basket', roles: TODOS, vista: alimentos, seccion: 'Nutrición' },
  { ruta: 'menus', titulo: 'Menús diarios', icono: 'bi-card-list', roles: PERSONAL, vista: menus, seccion: 'Nutrición' },
  { ruta: 'reglas', titulo: 'Reglas nutricionales', icono: 'bi-sliders', roles: PERSONAL, vista: reglas, seccion: 'Configuración' },
  { ruta: 'usuarios', titulo: 'Usuarios', icono: 'bi-person-gear', roles: ['Admin'], vista: usuarios, seccion: 'Configuración' },
  { ruta: 'auditoria', titulo: 'Auditoría', icono: 'bi-shield-check', roles: ['Admin'], vista: auditoria, seccion: 'Configuración' },
  { ruta: 'notificaciones', titulo: 'Notificaciones', icono: 'bi-bell', roles: TODOS, vista: notificaciones, seccion: null },
  { ruta: 'cuenta', titulo: 'Cambiar contraseña', icono: 'bi-key', roles: TODOS, vista: cuenta, seccion: null },
  { ruta: 'estudiante', titulo: 'Perfil del estudiante', icono: 'bi-person', roles: PERSONAL, vista: perfil, seccion: null }
];

const vista = document.getElementById('vista');
const titulo = document.getElementById('titulo');

async function iniciar() {
  if (!sesion.valida()) { window.location.replace('index.html'); return; }
  vista.innerHTML = cargando('Preparando tu espacio...');
  try {
    estado.usuario = await api.get('/api/auth/perfil');
    estado.catalogos = await api.get('/api/catalogos');
  } catch (e) {
    vista.innerHTML = errorHtml(e.message);
    return;
  }

  document.getElementById('nombre-usuario').textContent = estado.usuario.nombre;
  document.getElementById('rol-usuario').textContent = estado.usuario.rol;
  document.getElementById('avatar').textContent = iniciales(estado.usuario.nombre);
  construirMenu();

  document.getElementById('btn-salir').addEventListener('click', (ev) => {
    ev.preventDefault();
    sesion.cerrar();
    window.location.replace('index.html');
  });
  document.getElementById('btn-menu').addEventListener('click', () => document.getElementById('sidebar').classList.toggle('abierto'));

  window.addEventListener('hashchange', navegar);
  window.addEventListener('snt:notificaciones', actualizarContador);
  await navegar();
  actualizarContador();
  setInterval(actualizarContador, 60000);
}

function rutasPermitidas() {
  return RUTAS.filter(r => r.roles.includes(estado.usuario.rol));
}

function construirMenu() {
  const esEst = estado.usuario.rol === 'Estudiante';
  let html = '';
  let seccionActual = null;
  rutasPermitidas().filter(r => r.seccion).forEach(r => {
    if (r.seccion !== seccionActual) { html += `<div class="seccion">${esc(r.seccion)}</div>`; seccionActual = r.seccion; }
    html += `<a class="item" href="#/${r.ruta}" data-ruta="${r.ruta}"><i class="bi ${r.icono}"></i>${esc(esEst && r.tituloEst ? r.tituloEst : r.titulo)}</a>`;
  });
  document.getElementById('menu').innerHTML = html;
}

async function navegar() {
  const hash = location.hash.replace(/^#\/?/, '') || 'inicio';
  const [camino, consulta] = hash.split('?');
  const [nombre, id] = camino.split('/');
  const params = new URLSearchParams(consulta || '');
  const def = rutasPermitidas().find(r => r.ruta === nombre);

  document.getElementById('sidebar').classList.remove('abierto');
  document.querySelectorAll('#menu a.item').forEach(a =>
    a.classList.toggle('activo', a.dataset.ruta === (nombre === 'estudiante' ? 'estudiantes' : nombre)));

  destruirGraficos();
  if (!def) {
    titulo.textContent = 'No encontrado';
    vista.innerHTML = errorHtml('La página no existe o no tiene permisos para verla.');
    return;
  }
  const esEst = estado.usuario.rol === 'Estudiante';
  titulo.textContent = esEst && def.tituloEst ? def.tituloEst : def.titulo;
  document.title = `${titulo.textContent} · SmartNutriTracker`;
  vista.innerHTML = cargando();
  try {
    await def.vista.render({ el: vista, id: id ? parseInt(id, 10) : null, params, titulo: (t) => { titulo.textContent = t; } });
  } catch (e) {
    console.error(e);
    vista.innerHTML = errorHtml(e.message || 'Ocurrió un error al cargar la vista.');
  }
}

async function actualizarContador() {
  try {
    const { noLeidas } = await api.get('/api/notificaciones/contador');
    const el = document.getElementById('contador-notif');
    el.textContent = noLeidas > 99 ? '99+' : noLeidas;
    el.classList.toggle('d-none', noLeidas === 0);
  } catch { /* silencioso */ }
}

iniciar();
