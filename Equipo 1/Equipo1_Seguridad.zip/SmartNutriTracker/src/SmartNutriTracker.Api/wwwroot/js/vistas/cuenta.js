// Cambio de contraseña del usuario autenticado
import { api } from '../api.js';
import { estado } from '../estado.js';
import { esc, toast, leerFormulario } from '../ui.js';

export async function render({ el }) {
  const u = estado.usuario;
  el.innerHTML = `
    <div class="tarjeta" style="max-width:520px">
      <div class="cabecera"><i class="bi bi-person-circle" style="color:var(--snt-700)"></i><h3>Mi cuenta</h3></div>
      <div class="cuerpo">
        <div class="mb-3 small"><div><strong>${esc(u.nombre)}</strong></div><div class="muted">${esc(u.correo)} · ${esc(u.rol)}</div></div>
        <form id="form-pass" novalidate>
          <div class="mb-3"><label class="form-label">Contraseña actual</label><input type="password" class="form-control" name="passwordActual" required autocomplete="current-password"></div>
          <div class="mb-3"><label class="form-label">Nueva contraseña</label><input type="password" class="form-control" name="passwordNueva" required minlength="8" autocomplete="new-password">
            <div class="form-text">Mínimo 8 caracteres, con mayúscula, minúscula y número.</div></div>
          <div class="mb-3"><label class="form-label">Repetir nueva contraseña</label><input type="password" class="form-control" id="repetir" required minlength="8" autocomplete="new-password"></div>
          <div class="alert alert-danger d-none" id="err"></div>
          <button class="btn btn-primary" type="submit"><i class="bi bi-key me-1"></i>Cambiar contraseña</button>
        </form>
      </div>
    </div>`;

  el.querySelector('#form-pass').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const form = ev.target;
    const err = el.querySelector('#err');
    err.classList.add('d-none');
    if (!form.checkValidity()) { form.classList.add('was-validated'); return; }
    const datos = leerFormulario(form);
    if (datos.passwordNueva !== el.querySelector('#repetir').value) {
      err.textContent = 'Las contraseñas nuevas no coinciden.';
      err.classList.remove('d-none');
      return;
    }
    try {
      const r = await api.post('/api/auth/cambiar-password', datos);
      toast(r.mensaje);
      form.reset();
    } catch (e) {
      err.textContent = e.message;
      err.classList.remove('d-none');
    }
  });
}
