// HU-05 – Log de auditoría (solo Admin)
import { api, conParametros } from '../api.js';
import { esc, fechaHoraUtc, vacio, on } from '../ui.js';

const ACCIONES = ['LOGIN', 'LOGIN_FALLIDO', 'CREAR', 'ACTUALIZAR', 'ELIMINAR', 'DESACTIVAR', 'GENERAR', 'REGISTRAR_CONSUMO',
  'REGISTRAR_HABITOS', 'ACTUALIZAR_HABITOS', 'CAMBIO_PASSWORD', 'RESET_PASSWORD', 'ATENDER', 'CAMBIAR_ESTADO'];
let f = { accion: '', buscar: '', desde: '', hasta: '', pagina: 1, tamano: 25 };

export async function render(ctx) {
  const { el } = ctx;
  const r = await api.get(conParametros('/api/auditoria', f));
  const paginas = Math.max(1, Math.ceil(r.total / r.tamanoPagina));
  const color = (a) => a.includes('FALLIDO') ? 'b-coral' : a.startsWith('ELIMINAR') || a === 'DESACTIVAR' ? 'b-ambar' : a === 'LOGIN' ? 'b-lima' : 'b-verde';

  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2"><h3><i class="bi bi-shield-check me-1"></i>Registro de auditoría</h3>
        <div class="ms-auto d-flex flex-wrap gap-2">
          <select class="form-select form-select-sm" style="width:190px" id="f-accion"><option value="">Todas las acciones</option>
            ${ACCIONES.map(a => `<option ${a === f.accion ? 'selected' : ''}>${a}</option>`).join('')}</select>
          <input type="date" class="form-control form-control-sm" style="width:150px" id="f-desde" value="${f.desde}" title="Desde">
          <input type="date" class="form-control form-control-sm" style="width:150px" id="f-hasta" value="${f.hasta}" title="Hasta">
          <input class="form-control form-control-sm" style="width:200px" placeholder="Usuario, entidad o detalle..." id="f-buscar" value="${esc(f.buscar)}">
        </div></div>
      <div class="cuerpo p-0">${r.items.length ? `<div class="table-responsive"><table class="table table-sm table-hover">
        <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Entidad</th><th>Detalle</th><th>IP</th></tr></thead>
        <tbody>${r.items.map(l => `<tr>
          <td class="text-nowrap small">${fechaHoraUtc(l.fecha)}</td><td class="small">${esc(l.usuario ?? 'Sistema')}</td>
          <td><span class="badge ${color(l.accion)}">${esc(l.accion)}</span></td>
          <td class="small">${esc(l.entidad)}${l.entidadId ? ` #${esc(l.entidadId)}` : ''}</td>
          <td class="small">${esc(l.detalle ?? '')}</td><td class="small muted">${esc(l.direccionIp ?? '')}</td></tr>`).join('')}
        </tbody></table></div>` : vacio('Sin registros para los filtros indicados.', 'bi-shield')}</div>
      <div class="d-flex align-items-center gap-2 p-3 border-top small">
        <span class="muted">${r.total} registro(s)</span>
        <div class="ms-auto d-flex gap-1 align-items-center">
          <button class="btn btn-sm btn-light" data-pag="-1" ${f.pagina <= 1 ? 'disabled' : ''}><i class="bi bi-chevron-left"></i></button>
          <span>Página ${f.pagina} de ${paginas}</span>
          <button class="btn btn-sm btn-light" data-pag="1" ${f.pagina >= paginas ? 'disabled' : ''}><i class="bi bi-chevron-right"></i></button>
        </div>
      </div>
    </div>`;

  const aplicar = (cambio) => { Object.assign(f, cambio, { pagina: cambio.pagina ?? 1 }); render(ctx); };
  el.querySelector('#f-accion').addEventListener('change', (ev) => aplicar({ accion: ev.target.value }));
  el.querySelector('#f-desde').addEventListener('change', (ev) => aplicar({ desde: ev.target.value }));
  el.querySelector('#f-hasta').addEventListener('change', (ev) => aplicar({ hasta: ev.target.value }));
  let t;
  el.querySelector('#f-buscar').addEventListener('input', (ev) => { clearTimeout(t); t = setTimeout(() => aplicar({ buscar: ev.target.value }), 400); });
  on(el, 'click', '[data-pag]', (_, b) => aplicar({ pagina: f.pagina + parseInt(b.dataset.pag, 10) }));
}
