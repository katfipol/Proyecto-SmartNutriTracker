// HU-01 Registrar usuarios · HU-04 Gestión de roles (solo Admin)
import { api, conParametros } from '../api.js';
import { estado } from '../estado.js';
import { esc, fechaHoraUtc, vacio, abrirModal, opciones, toast, on, leerFormulario, confirmar } from '../ui.js';

let filtros = { rol: '', buscar: '' };

export async function render(ctx) {
  const { el } = ctx;
  const roles = estado.catalogos.roles.map(r => ({ id: r, nombre: r }));
  const lista = await api.get(conParametros('/api/usuarios', filtros));
  const colorRol = { Admin: 'b-oscuro', Nutricionista: 'b-verde', Docente: 'b-lima', Estudiante: 'b-gris' };

  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2"><h3><i class="bi bi-person-gear me-1"></i>Usuarios del sistema</h3>
        <div class="ms-auto d-flex flex-wrap gap-2">
          <input class="form-control form-control-sm" style="width:220px" placeholder="Nombre o correo..." id="f-buscar" value="${esc(filtros.buscar)}">
          <select class="form-select form-select-sm" style="width:170px" id="f-rol">${opciones(roles, filtros.rol, { vacioTexto: 'Todos los roles' })}</select>
          <button class="btn btn-primary btn-sm" data-accion="nuevo"><i class="bi bi-person-plus me-1"></i>Nuevo usuario</button>
        </div></div>
      <div class="cuerpo p-0">${lista.length ? `<div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Último acceso</th><th></th></tr></thead>
        <tbody>${lista.map(u => `<tr class="${u.activo ? '' : 'opacity-50'}">
          <td class="fw-semibold">${esc(u.nombre)}</td><td>${esc(u.correo)}</td>
          <td><span class="badge ${colorRol[u.rol] || 'b-gris'}">${esc(u.rol)}</span></td>
          <td>${u.activo ? '<span class="badge b-verde">Activo</span>' : '<span class="badge b-gris">Inactivo</span>'}
              ${u.bloqueado ? '<span class="badge b-coral"><i class="bi bi-lock"></i> Bloqueado</span>' : ''}</td>
          <td class="small">${u.ultimoAcceso ? fechaHoraUtc(u.ultimoAcceso) : '<span class="muted">Nunca</span>'}</td>
          <td class="text-end text-nowrap">
            <button class="btn btn-sm btn-light" data-accion="editar" data-id="${u.id}" title="Editar"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-light" data-accion="reset" data-id="${u.id}" title="Restablecer contraseña"><i class="bi bi-key"></i></button>
            ${u.bloqueado ? `<button class="btn btn-sm btn-light" data-accion="desbloquear" data-id="${u.id}" title="Desbloquear"><i class="bi bi-unlock"></i></button>` : ''}
          </td></tr>`).join('')}</tbody></table></div>` : vacio('No se encontraron usuarios.', 'bi-people')}</div>
    </div>
    <p class="small muted mt-2"><i class="bi bi-shield-lock"></i> Contraseñas con PBKDF2-SHA256. Tras 5 intentos fallidos la cuenta se bloquea 5 minutos. Los estudiantes también pueden crearse desde <a href="#/estudiantes">Estudiantes</a> con su perfil.</p>`;

  const recargar = () => render(ctx);
  let t;
  el.querySelector('#f-buscar').addEventListener('input', (ev) => { clearTimeout(t); t = setTimeout(() => { filtros.buscar = ev.target.value; recargar(); }, 350); });
  el.querySelector('#f-rol').addEventListener('change', (ev) => { filtros.rol = ev.target.value; recargar(); });

  on(el, 'click', '[data-accion=nuevo]', () => abrirModal({
    titulo: 'Nuevo usuario',
    cuerpo: `<div class="row g-3">
      <div class="col-12"><label class="form-label">Nombre completo</label><input class="form-control" name="nombre" required maxlength="100"></div>
      <div class="col-12"><label class="form-label">Correo</label><input type="email" class="form-control" name="correo" required maxlength="150"></div>
      <div class="col-md-6"><label class="form-label">Rol</label><select class="form-select" name="rol">${opciones(roles, 'Docente')}</select></div>
      <div class="col-md-6"><label class="form-label">Contraseña inicial</label><input type="text" class="form-control" name="password" required minlength="8"></div>
      <div class="col-12 small muted">Mínimo 8 caracteres con mayúscula, minúscula y número.</div></div>`,
    alGuardar: async (form) => { await api.post('/api/usuarios', leerFormulario(form)); toast('Usuario creado.'); recargar(); }
  }));
  on(el, 'click', '[data-accion=editar]', (_, b) => {
    const u = lista.find(x => x.id === parseInt(b.dataset.id, 10));
    abrirModal({
      titulo: `Editar: ${u.correo}`,
      cuerpo: `<div class="row g-3">
        <div class="col-12"><label class="form-label">Nombre</label><input class="form-control" name="nombre" required maxlength="100" value="${esc(u.nombre)}"></div>
        <div class="col-md-6"><label class="form-label">Rol</label><select class="form-select" name="rol">${opciones(roles, u.rol)}</select></div>
        <div class="col-md-6 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="u-activo" ${u.activo ? 'checked' : ''}>
          <label class="form-check-label" for="u-activo">Usuario activo</label></div></div></div>`,
      alGuardar: async (form) => { await api.put(`/api/usuarios/${u.id}`, leerFormulario(form)); toast('Usuario actualizado.'); recargar(); }
    });
  });
  on(el, 'click', '[data-accion=reset]', (_, b) => abrirModal({
    titulo: 'Restablecer contraseña',
    cuerpo: `<label class="form-label">Nueva contraseña</label><input type="text" class="form-control" name="passwordNueva" required minlength="8">
      <div class="small muted mt-1">Comunique la nueva contraseña al usuario.</div>`,
    alGuardar: async (form) => { await api.post(`/api/usuarios/${b.dataset.id}/reset-password`, leerFormulario(form)); toast('Contraseña restablecida.'); }
  }));
  on(el, 'click', '[data-accion=desbloquear]', async (_, b) => {
    if (!await confirmar('¿Desbloquear esta cuenta?', 'Desbloquear')) return;
    await api.post(`/api/usuarios/${b.dataset.id}/desbloquear`);
    toast('Cuenta desbloqueada.');
    recargar();
  });
}
