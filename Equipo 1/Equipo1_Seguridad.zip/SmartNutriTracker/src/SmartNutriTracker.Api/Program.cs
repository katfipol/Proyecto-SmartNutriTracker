using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;
using SmartNutriTracker.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// ---------- HU-29: logs globales (consola + archivo diario) ----------
var carpetaLogs = Path.Combine(builder.Environment.ContentRootPath, builder.Configuration["Logging:Archivo:Carpeta"] ?? "logs");
builder.Logging.AddProvider(new ArchivoLoggerProvider(carpetaLogs));

// ---------- Base de datos ----------
builder.Services.AddDbContext<SmartNutriDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("SmartNutriDb")));

// ---------- Opciones ----------
builder.Services.Configure<RecomendacionOptions>(builder.Configuration.GetSection("Recomendaciones"));
builder.Services.Configure<RecordatoriosOptions>(builder.Configuration.GetSection("Recordatorios"));

// ---------- Servicios ----------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<IUsuarioActual, UsuarioActual>();
builder.Services.AddScoped<IAuditoriaService, AuditoriaService>();
builder.Services.AddScoped<IAccesoService, AccesoService>();
builder.Services.AddScoped<INutricionService, NutricionService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IUsuariosService, UsuariosService>();
builder.Services.AddScoped<ICatalogosService, CatalogosService>();
builder.Services.AddScoped<IEstudiantesService, EstudiantesService>();
builder.Services.AddScoped<IAlimentosService, AlimentosService>();
builder.Services.AddScoped<IMenusService, MenusService>();
builder.Services.AddScoped<IHabitosService, HabitosService>();
builder.Services.AddScoped<IRecomendacionesService, RecomendacionesService>();
builder.Services.AddScoped<IReglasService, ReglasService>();
builder.Services.AddScoped<IAlertasService, AlertasService>();
builder.Services.AddScoped<INotificacionesService, NotificacionesService>();
builder.Services.AddScoped<ICitasService, CitasService>();
builder.Services.AddScoped<IReportesService, ReportesService>();
builder.Services.AddHostedService<RecordatoriosBackgroundService>();

// ---------- HU-03: autenticación JWT ----------
var jwt = builder.Configuration.GetSection("Jwt");
var clave = jwt["Key"];
if (string.IsNullOrWhiteSpace(clave) || clave.Length < 32)
    throw new InvalidOperationException("Jwt:Key debe tener al menos 32 caracteres.");

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt["Issuer"],
            ValidateAudience = true,
            ValidAudience = jwt["Audience"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(clave)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            RoleClaimType = ClaimTypes.Role,
            NameClaimType = ClaimTypes.Name
        };
    });
builder.Services.AddAuthorization();

// ---------- Límite de intentos de login (anti fuerza bruta) ----------
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddPolicy("login", ctx => RateLimitPartition.GetFixedWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "anonimo",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
});

builder.Services.AddControllers();

// ---------- HU-32: Swagger ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "SmartNutriTracker API",
        Version = "v1",
        Description = "Sistema de seguimiento nutricional – Colegio Innovare. Inicie sesión en POST /api/auth/login, copie el token y presione Authorize."
    });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Pegue solo el token JWT."
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } },
            Array.Empty<string>()
        }
    });
    var xml = Path.Combine(AppContext.BaseDirectory, $"{Assembly.GetExecutingAssembly().GetName().Name}.xml");
    if (File.Exists(xml)) c.IncludeXmlComments(xml);
});

var app = builder.Build();

app.UseMiddleware<ManejoErroresMiddleware>();
app.UseMiddleware<CabecerasSeguridadMiddleware>();

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "SmartNutriTracker v1");
    c.DocumentTitle = "SmartNutriTracker API";
});

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
    app.UseHttpsRedirection();
}

// ---------- Frontend (wwwroot) ----------
app.UseDefaultFiles();
app.UseStaticFiles();

app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

// Ruta de salud para el pipeline CI/CD y para probar la conexión a la BD
app.MapGet("/api/salud", async (SmartNutriDbContext db) =>
{
    var bd = await db.Database.CanConnectAsync();
    return Results.Ok(new { estado = bd ? "ok" : "sin conexión a la base de datos", baseDeDatos = bd, fecha = DateTime.Now });
}).AllowAnonymous();

app.Logger.LogInformation("SmartNutriTracker iniciado. Frontend: / · Swagger: /swagger");
app.Run();

/// <summary>Necesario para pruebas de integración.</summary>
public partial class Program { }
