// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 1 – Autenticación y Seguridad dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<Rol> Roles => Set<Rol>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<LogAuditoria> LogsAuditoria => Set<LogAuditoria>();

    partial void ConfigurarEquipo1(ModelBuilder mb)
    {
        mb.Entity<Rol>().ToTable("Roles");
        mb.Entity<Usuario>().ToTable("Usuarios");
        mb.Entity<LogAuditoria>().ToTable("LogsAuditoria");
    }
}
