// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 1 – HU-02 / HU-03: inicio de sesión y token JWT.</summary>
[ApiController]
[Route("api/auth")]
[Produces("application/json")]
public class AuthController(IAuthService servicio) : ControllerBase
{
    /// <summary>Inicia sesión con correo y contraseña. Devuelve el token JWT.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting("login")]
    [ProducesResponseType<LoginResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request, CancellationToken ct) =>
        Ok(await servicio.LoginAsync(request, ct));

    /// <summary>Datos del usuario autenticado.</summary>
    [HttpGet("perfil")]
    [Authorize]
    public async Task<ActionResult<UsuarioActualDto>> Perfil(CancellationToken ct) => Ok(await servicio.PerfilAsync(ct));

    /// <summary>Cambia la contraseña del usuario autenticado.</summary>
    [HttpPost("cambiar-password")]
    [Authorize]
    public async Task<ActionResult<MensajeDto>> CambiarPassword([FromBody] CambiarPasswordRequest request, CancellationToken ct)
    {
        await servicio.CambiarPasswordAsync(request, ct);
        return Ok(new MensajeDto("Contraseña actualizada correctamente."));
    }
}

/// <summary>EQUIPO 1 – HU-01 / HU-04: usuarios y roles (solo administrador).</summary>
[ApiController]
[Route("api/usuarios")]
[Authorize(Roles = Roles.Admin)]
[Produces("application/json")]
public class UsuariosController(IUsuariosService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<UsuarioDto>>> Listar([FromQuery] string? rol, [FromQuery] string? buscar, CancellationToken ct) =>
        Ok(await servicio.ListarAsync(rol, buscar, ct));

    [HttpPost]
    public async Task<ActionResult<UsuarioDto>> Crear([FromBody] CrearUsuarioRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.CrearAsync(request, ct));

    [HttpPut("{id:int}")]
    public async Task<ActionResult<UsuarioDto>> Actualizar(int id, [FromBody] ActualizarUsuarioRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarAsync(id, request, ct));

    [HttpPost("{id:int}/reset-password")]
    public async Task<ActionResult<MensajeDto>> ResetPassword(int id, [FromBody] ResetPasswordRequest request, CancellationToken ct)
    {
        await servicio.ResetPasswordAsync(id, request, ct);
        return Ok(new MensajeDto("Contraseña restablecida."));
    }

    [HttpPost("{id:int}/desbloquear")]
    public async Task<ActionResult<MensajeDto>> Desbloquear(int id, CancellationToken ct)
    {
        await servicio.DesbloquearAsync(id, ct);
        return Ok(new MensajeDto("Usuario desbloqueado."));
    }
}

/// <summary>EQUIPO 1 – HU-05: consulta del log de auditoría (solo administrador).</summary>
[ApiController]
[Route("api/auditoria")]
[Authorize(Roles = Roles.Admin)]
[Produces("application/json")]
public class AuditoriaController(IAuditoriaService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<PaginaDto<LogAuditoriaDto>>> Listar(
        [FromQuery] DateOnly? desde, [FromQuery] DateOnly? hasta, [FromQuery] string? accion, [FromQuery] string? buscar,
        [FromQuery] int pagina = 1, [FromQuery] int tamano = 25, CancellationToken ct = default) =>
        Ok(await servicio.ListarAsync(desde, hasta, accion, buscar, pagina, tamano, ct));
}

/// <summary>Catálogos para los formularios.</summary>
[ApiController]
[Route("api/catalogos")]
[Authorize]
[Produces("application/json")]
public class CatalogosController(ICatalogosService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<CatalogosDto>> Obtener(CancellationToken ct) => Ok(await servicio.ObtenerAsync(ct));
}
