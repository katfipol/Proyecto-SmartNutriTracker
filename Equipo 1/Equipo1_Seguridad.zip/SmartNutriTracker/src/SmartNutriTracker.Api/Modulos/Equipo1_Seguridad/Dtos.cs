// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

public sealed record PaginaDto<T>(IReadOnlyList<T> Items, int Total, int Pagina, int TamanoPagina);

public sealed record OpcionDto(int Id, string Nombre, string? Codigo = null);

public sealed record MensajeDto(string Mensaje);

public sealed class LoginRequest
{
    /// <example>nutricion@innovare.edu.bo</example>
    [Required, EmailAddress, MaxLength(150)] public string Correo { get; set; } = string.Empty;
    /// <example>Innovare2026!</example>
    [Required, MaxLength(100)] public string Password { get; set; } = string.Empty;
}

public sealed record UsuarioActualDto(int Id, string Nombre, string Correo, string Rol, int? EstudianteId);

public sealed record LoginResponse(string Token, DateTime ExpiraEn, UsuarioActualDto Usuario);

public sealed class CambiarPasswordRequest
{
    [Required] public string PasswordActual { get; set; } = string.Empty;
    [Required, MinLength(8), MaxLength(100)] public string PasswordNueva { get; set; } = string.Empty;
}

public sealed record UsuarioDto(int Id, string Nombre, string Correo, string Rol, bool Activo, bool Bloqueado,
    DateTime? UltimoAcceso, DateTime FechaCreacion);

public sealed class CrearUsuarioRequest
{
    [Required, MaxLength(100)] public string Nombre { get; set; } = string.Empty;
    [Required, EmailAddress, MaxLength(150)] public string Correo { get; set; } = string.Empty;
    [Required, MinLength(8), MaxLength(100)] public string Password { get; set; } = string.Empty;
    /// <summary>Admin | Docente | Nutricionista | Estudiante</summary>
    [Required] public string Rol { get; set; } = string.Empty;
}

public sealed class ActualizarUsuarioRequest
{
    [Required, MaxLength(100)] public string Nombre { get; set; } = string.Empty;
    [Required] public string Rol { get; set; } = string.Empty;
    public bool Activo { get; set; } = true;
}

public sealed class ResetPasswordRequest
{
    [Required, MinLength(8), MaxLength(100)] public string PasswordNueva { get; set; } = string.Empty;
}

public sealed record LogAuditoriaDto(long Id, DateTime Fecha, string? Usuario, string Accion, string Entidad,
    string? EntidadId, string? Detalle, string? DireccionIp);

public sealed record NivelActividadDto(int Id, string Codigo, string Nombre, decimal Factor);

public sealed record TipoComidaDto(int Id, string Nombre, int Orden, decimal PorcentajeCalorias);

public sealed record CursoDto(int Id, string Nombre, int? DocenteId, string? Docente);

public sealed record CatalogosDto(
    IReadOnlyList<string> Roles,
    IReadOnlyList<CursoDto> Cursos,
    IReadOnlyList<NivelActividadDto> NivelesActividad,
    IReadOnlyList<OpcionDto> Objetivos,
    IReadOnlyList<OpcionDto> CategoriasAlimento,
    IReadOnlyList<TipoComidaDto> TiposComida,
    IReadOnlyList<OpcionDto> Nutricionistas,
    IReadOnlyList<OpcionDto> Docentes);
