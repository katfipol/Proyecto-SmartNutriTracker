// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IUsuarioActual
{
    bool Autenticado { get; }
    int Id { get; }
    string Rol { get; }
    string? Ip { get; }
    bool EsAdmin => Rol == Roles.Admin;
    bool EsNutricionista => Rol == Roles.Nutricionista;
    bool EsDocente => Rol == Roles.Docente;
    bool EsEstudiante => Rol == Roles.Estudiante;
    bool EsSalud => EsAdmin || EsNutricionista;
}

public class UsuarioActual(IHttpContextAccessor accessor) : IUsuarioActual
{
    private ClaimsPrincipal? Principal => accessor.HttpContext?.User;
    public bool Autenticado => Principal?.Identity?.IsAuthenticated == true;
    public int Id => Principal?.ObtenerUsuarioId() ?? throw new NoAutorizadoException("No hay un usuario autenticado.");
    public string Rol => Principal?.ObtenerRol() ?? string.Empty;
    public string? Ip => accessor.HttpContext?.Connection.RemoteIpAddress?.ToString();
}

public interface IAccesoService
{
    IQueryable<Estudiante> EstudiantesVisibles();
    Task VerificarEstudianteAsync(int estudianteId, CancellationToken ct = default);
    Task<int> EstudianteActualIdAsync(CancellationToken ct = default);
}

public class AccesoService(SmartNutriDbContext db, IUsuarioActual usuario) : IAccesoService
{
    public IQueryable<Estudiante> EstudiantesVisibles()
    {
        var q = db.Estudiantes.AsQueryable();
        if (usuario.EsSalud) return q;
        var uid = usuario.Id;
        if (usuario.EsDocente) return q.Where(e => e.Curso!.DocenteId == uid);
        if (usuario.EsEstudiante) return q.Where(e => e.UsuarioId == uid);
        return q.Where(_ => false);
    }

    public async Task VerificarEstudianteAsync(int estudianteId, CancellationToken ct = default)
    {
        if (await EstudiantesVisibles().AnyAsync(e => e.Id == estudianteId, ct)) return;
        if (await db.Estudiantes.AnyAsync(e => e.Id == estudianteId, ct))
            throw new AccesoDenegadoException("No tiene permiso para acceder a los datos de este estudiante.");
        throw new NoEncontradoException($"Estudiante {estudianteId} no encontrado.");
    }

    public async Task<int> EstudianteActualIdAsync(CancellationToken ct = default)
    {
        var uid = usuario.Id;
        var id = await db.Estudiantes.Where(e => e.UsuarioId == uid).Select(e => (int?)e.Id).FirstOrDefaultAsync(ct);
        return id ?? throw new NoEncontradoException("El usuario no está vinculado a un perfil de estudiante.");
    }
}
