// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IAuditoriaService
{
    Task RegistrarAsync(string accion, string entidad, object? entidadId = null, string? detalle = null,
        int? usuarioId = null, CancellationToken ct = default);
    Task<PaginaDto<LogAuditoriaDto>> ListarAsync(DateOnly? desde, DateOnly? hasta, string? accion, string? buscar,
        int pagina, int tamano, CancellationToken ct = default);
}

public class AuditoriaService(SmartNutriDbContext db, IUsuarioActual usuario, ILogger<AuditoriaService> logger) : IAuditoriaService
{
    public async Task RegistrarAsync(string accion, string entidad, object? entidadId = null, string? detalle = null,
        int? usuarioId = null, CancellationToken ct = default)
    {
        var uid = usuarioId ?? (usuario.Autenticado ? usuario.Id : null);
        db.LogsAuditoria.Add(new LogAuditoria
        {
            UsuarioId = uid,
            Accion = accion,
            Entidad = entidad,
            EntidadId = entidadId?.ToString(),
            Detalle = detalle is { Length: > 1000 } ? detalle[..1000] : detalle,
            DireccionIp = usuario.Ip,
            Fecha = DateTime.UtcNow
        });
        await db.SaveChangesAsync(ct);
        logger.LogInformation("AUDITORIA {Accion} {Entidad} {EntidadId} por usuario {UsuarioId}: {Detalle}", accion, entidad, entidadId, uid, detalle);
    }

    public async Task<PaginaDto<LogAuditoriaDto>> ListarAsync(DateOnly? desde, DateOnly? hasta, string? accion, string? buscar,
        int pagina, int tamano, CancellationToken ct = default)
    {
        pagina = Math.Max(1, pagina);
        tamano = Math.Clamp(tamano, 5, 200);
        var q = db.LogsAuditoria.AsNoTracking().AsQueryable();
        if (desde.HasValue) { var d = desde.Value.ToDateTime(TimeOnly.MinValue); q = q.Where(l => l.Fecha >= d); }
        if (hasta.HasValue) { var h = hasta.Value.AddDays(1).ToDateTime(TimeOnly.MinValue); q = q.Where(l => l.Fecha < h); }
        if (!string.IsNullOrWhiteSpace(accion)) q = q.Where(l => l.Accion == accion);
        if (!string.IsNullOrWhiteSpace(buscar))
            q = q.Where(l => l.Entidad.Contains(buscar) || (l.Detalle != null && l.Detalle.Contains(buscar)) ||
                             (l.Usuario != null && l.Usuario.Correo.Contains(buscar)));

        var total = await q.CountAsync(ct);
        var items = await q.OrderByDescending(l => l.Fecha)
            .Skip((pagina - 1) * tamano).Take(tamano)
            .Select(l => new LogAuditoriaDto(l.Id, l.Fecha, l.Usuario != null ? l.Usuario.Correo : null, l.Accion, l.Entidad,
                l.EntidadId, l.Detalle, l.DireccionIp))
            .ToListAsync(ct);
        return new PaginaDto<LogAuditoriaDto>(items, total, pagina, tamano);
    }
}
