// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;

namespace SmartNutriTracker.Api.Services;

public interface IUsuariosService
{
    Task<IReadOnlyList<UsuarioDto>> ListarAsync(string? rol, string? buscar, CancellationToken ct = default);
    Task<UsuarioDto> CrearAsync(CrearUsuarioRequest request, CancellationToken ct = default);
    Task<UsuarioDto> ActualizarAsync(int id, ActualizarUsuarioRequest request, CancellationToken ct = default);
    Task ResetPasswordAsync(int id, ResetPasswordRequest request, CancellationToken ct = default);
    Task DesbloquearAsync(int id, CancellationToken ct = default);
    /// <summary>Crea el usuario sin guardar auditoría (lo usa el registro de estudiantes).</summary>
    Task<Usuario> CrearEntidadAsync(string nombre, string correo, string password, string rol, CancellationToken ct = default);
}

public class UsuariosService(SmartNutriDbContext db, IUsuarioActual usuarioActual, IAuditoriaService auditoria) : IUsuariosService
{
    public async Task<IReadOnlyList<UsuarioDto>> ListarAsync(string? rol, string? buscar, CancellationToken ct = default)
    {
        var q = db.Usuarios.AsNoTracking().Include(u => u.Rol).AsQueryable();
        if (!string.IsNullOrWhiteSpace(rol)) q = q.Where(u => u.Rol!.Nombre == rol);
        if (!string.IsNullOrWhiteSpace(buscar)) q = q.Where(u => u.Nombre.Contains(buscar) || u.Correo.Contains(buscar));
        var ahora = DateTime.UtcNow;
        return await q.OrderBy(u => u.Rol!.Nombre).ThenBy(u => u.Nombre)
            .Select(u => new UsuarioDto(u.Id, u.Nombre, u.Correo, u.Rol!.Nombre, u.Activo,
                u.BloqueadoHasta != null && u.BloqueadoHasta > ahora, u.UltimoAcceso, u.FechaCreacion))
            .ToListAsync(ct);
    }

    public async Task<UsuarioDto> CrearAsync(CrearUsuarioRequest request, CancellationToken ct = default)
    {
        var u = await CrearEntidadAsync(request.Nombre, request.Correo, request.Password, request.Rol, ct);
        await auditoria.RegistrarAsync("CREAR", "Usuario", u.Id, $"{u.Correo} ({request.Rol})", ct: ct);
        return await ObtenerAsync(u.Id, ct);
    }

    public async Task<Usuario> CrearEntidadAsync(string nombre, string correo, string password, string rol, CancellationToken ct = default)
    {
        var correoNorm = correo.Trim().ToLowerInvariant();
        if (await db.Usuarios.AnyAsync(x => x.Correo == correoNorm, ct))
            throw new ReglaNegocioException($"Ya existe un usuario con el correo {correoNorm}.");
        PasswordHasher.ValidarPolitica(password);
        var rolEntidad = await db.Roles.FirstOrDefaultAsync(r => r.Nombre == rol, ct)
                         ?? throw new ReglaNegocioException($"Rol '{rol}' no válido. Use: {string.Join(", ", Roles.Lista)}.");

        var u = new Usuario
        {
            Nombre = nombre.Trim(),
            Correo = correoNorm,
            PasswordHash = PasswordHasher.Hash(password),
            RolId = rolEntidad.Id,
            Activo = true,
            FechaCreacion = DateTime.UtcNow
        };
        db.Usuarios.Add(u);
        await db.SaveChangesAsync(ct);
        return u;
    }

    public async Task<UsuarioDto> ActualizarAsync(int id, ActualizarUsuarioRequest request, CancellationToken ct = default)
    {
        var u = await db.Usuarios.Include(x => x.Rol).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NoEncontradoException($"Usuario {id} no encontrado.");
        var rol = await db.Roles.FirstOrDefaultAsync(r => r.Nombre == request.Rol, ct)
                  ?? throw new ReglaNegocioException($"Rol '{request.Rol}' no válido.");

        if (id == usuarioActual.Id && (!request.Activo || rol.Nombre != Roles.Admin))
            throw new ReglaNegocioException("No puede desactivarse ni quitarse el rol de administrador a sí mismo.");

        var antes = $"{u.Nombre}/{u.Rol!.Nombre}/{(u.Activo ? "activo" : "inactivo")}";
        u.Nombre = request.Nombre.Trim();
        u.RolId = rol.Id;
        u.Activo = request.Activo;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "Usuario", id,
            $"{antes} -> {u.Nombre}/{rol.Nombre}/{(u.Activo ? "activo" : "inactivo")}", ct: ct);
        return await ObtenerAsync(id, ct);
    }

    public async Task ResetPasswordAsync(int id, ResetPasswordRequest request, CancellationToken ct = default)
    {
        var u = await db.Usuarios.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Usuario {id} no encontrado.");
        PasswordHasher.ValidarPolitica(request.PasswordNueva);
        u.PasswordHash = PasswordHasher.Hash(request.PasswordNueva);
        u.IntentosFallidos = 0;
        u.BloqueadoHasta = null;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("RESET_PASSWORD", "Usuario", id, u.Correo, ct: ct);
    }

    public async Task DesbloquearAsync(int id, CancellationToken ct = default)
    {
        var u = await db.Usuarios.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Usuario {id} no encontrado.");
        u.IntentosFallidos = 0;
        u.BloqueadoHasta = null;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("DESBLOQUEAR", "Usuario", id, u.Correo, ct: ct);
    }

    private async Task<UsuarioDto> ObtenerAsync(int id, CancellationToken ct) =>
        (await ListarAsync(null, null, ct)).First(u => u.Id == id);
}
