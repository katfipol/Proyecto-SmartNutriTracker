// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;

namespace SmartNutriTracker.Api.Services;

public interface IAuthService
{
    Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct = default);
    Task<UsuarioActualDto> PerfilAsync(CancellationToken ct = default);
    Task CambiarPasswordAsync(CambiarPasswordRequest request, CancellationToken ct = default);
}

public class AuthService(
    SmartNutriDbContext db,
    IConfiguration config,
    IUsuarioActual usuarioActual,
    IAuditoriaService auditoria) : IAuthService
{
    public async Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct = default)
    {
        var correo = request.Correo.Trim().ToLowerInvariant();
        var usuario = await db.Usuarios.Include(u => u.Rol).FirstOrDefaultAsync(u => u.Correo == correo, ct);

        // Mensaje genérico: no revela si el correo existe
        const string credencialesInvalidas = "Correo o contraseña incorrectos.";
        if (usuario is null)
        {
            await auditoria.RegistrarAsync("LOGIN_FALLIDO", "Usuario", null, $"Correo inexistente: {correo}", ct: ct);
            throw new NoAutorizadoException(credencialesInvalidas);
        }

        if (!usuario.Activo)
        {
            await auditoria.RegistrarAsync("LOGIN_FALLIDO", "Usuario", usuario.Id, "Usuario inactivo", usuario.Id, ct);
            throw new NoAutorizadoException("La cuenta está desactivada. Contacte al administrador.");
        }

        if (usuario.BloqueadoHasta is { } hasta && hasta > DateTime.UtcNow)
        {
            var minutos = Math.Ceiling((hasta - DateTime.UtcNow).TotalMinutes);
            throw new NoAutorizadoException($"Cuenta bloqueada temporalmente por intentos fallidos. Intente en {minutos} minuto(s).");
        }

        if (!PasswordHasher.Verificar(request.Password, usuario.PasswordHash))
        {
            var max = config.GetValue("Seguridad:MaxIntentosFallidos", 5);
            usuario.IntentosFallidos++;
            var detalle = $"Contraseña incorrecta (intento {usuario.IntentosFallidos} de {max})";
            if (usuario.IntentosFallidos >= max)
            {
                usuario.BloqueadoHasta = DateTime.UtcNow.AddMinutes(config.GetValue("Seguridad:MinutosBloqueo", 5));
                usuario.IntentosFallidos = 0;
                detalle += " - cuenta bloqueada";
            }
            await db.SaveChangesAsync(ct);
            await auditoria.RegistrarAsync("LOGIN_FALLIDO", "Usuario", usuario.Id, detalle, usuario.Id, ct);
            throw new NoAutorizadoException(credencialesInvalidas);
        }

        usuario.IntentosFallidos = 0;
        usuario.BloqueadoHasta = null;
        usuario.UltimoAcceso = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);

        var estudianteId = await db.Estudiantes.Where(e => e.UsuarioId == usuario.Id).Select(e => (int?)e.Id).FirstOrDefaultAsync(ct);
        var (token, expira) = GenerarToken(usuario, usuario.Rol!.Nombre, estudianteId);
        await auditoria.RegistrarAsync("LOGIN", "Usuario", usuario.Id, $"Inicio de sesión ({usuario.Rol.Nombre})", usuario.Id, ct);

        return new LoginResponse(token, expira,
            new UsuarioActualDto(usuario.Id, usuario.Nombre, usuario.Correo, usuario.Rol.Nombre, estudianteId));
    }

    public async Task<UsuarioActualDto> PerfilAsync(CancellationToken ct = default)
    {
        var id = usuarioActual.Id;
        var u = await db.Usuarios.AsNoTracking().Include(x => x.Rol).FirstOrDefaultAsync(x => x.Id == id && x.Activo, ct)
                ?? throw new NoAutorizadoException("Usuario no encontrado o inactivo.");
        var estudianteId = await db.Estudiantes.Where(e => e.UsuarioId == id).Select(e => (int?)e.Id).FirstOrDefaultAsync(ct);
        return new UsuarioActualDto(u.Id, u.Nombre, u.Correo, u.Rol!.Nombre, estudianteId);
    }

    public async Task CambiarPasswordAsync(CambiarPasswordRequest request, CancellationToken ct = default)
    {
        var u = await db.Usuarios.FirstOrDefaultAsync(x => x.Id == usuarioActual.Id, ct)
                ?? throw new NoAutorizadoException("Usuario no encontrado.");
        if (!PasswordHasher.Verificar(request.PasswordActual, u.PasswordHash))
            throw new ReglaNegocioException("La contraseña actual es incorrecta.");
        PasswordHasher.ValidarPolitica(request.PasswordNueva);
        u.PasswordHash = PasswordHasher.Hash(request.PasswordNueva);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CAMBIO_PASSWORD", "Usuario", u.Id, "El usuario cambió su contraseña", ct: ct);
    }

    private (string Token, DateTime Expira) GenerarToken(Usuario usuario, string rol, int? estudianteId)
    {
        var jwt = config.GetSection("Jwt");
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
        var expira = DateTime.UtcNow.AddMinutes(jwt.GetValue("ExpiracionMinutos", 480));

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, usuario.Id.ToString()),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new(ClaimTypes.Name, usuario.Nombre),
            new(ClaimTypes.Email, usuario.Correo),
            new(ClaimTypes.Role, rol)
        };
        if (estudianteId.HasValue) claims.Add(new Claim("estudianteId", estudianteId.Value.ToString()));

        var token = new JwtSecurityToken(jwt["Issuer"], jwt["Audience"], claims, DateTime.UtcNow, expira,
            new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return (new JwtSecurityTokenHandler().WriteToken(token), expira);
    }
}
