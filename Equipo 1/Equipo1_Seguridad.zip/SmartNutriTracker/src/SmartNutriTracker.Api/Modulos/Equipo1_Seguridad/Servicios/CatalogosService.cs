// EQUIPO 1 – Autenticación y Seguridad
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface ICatalogosService
{
    Task<CatalogosDto> ObtenerAsync(CancellationToken ct = default);
}

public class CatalogosService(SmartNutriDbContext db) : ICatalogosService
{
    public async Task<CatalogosDto> ObtenerAsync(CancellationToken ct = default)
    {
        var cursos = await db.Cursos.AsNoTracking().OrderBy(c => c.Nombre)
            .Select(c => new CursoDto(c.Id, c.Nombre, c.DocenteId, c.Docente != null ? c.Docente.Nombre : null)).ToListAsync(ct);
        var niveles = await db.NivelesActividad.AsNoTracking().OrderBy(n => n.Factor)
            .Select(n => new NivelActividadDto(n.Id, n.Codigo, n.Nombre, n.Factor)).ToListAsync(ct);
        var objetivos = await db.ObjetivosNutricionales.AsNoTracking().OrderBy(o => o.Id)
            .Select(o => new OpcionDto(o.Id, o.Nombre, o.Codigo)).ToListAsync(ct);
        var categorias = await db.CategoriasAlimento.AsNoTracking().OrderBy(c => c.Nombre)
            .Select(c => new OpcionDto(c.Id, c.Nombre, c.Codigo)).ToListAsync(ct);
        var tipos = await db.TiposComida.AsNoTracking().OrderBy(t => t.Orden)
            .Select(t => new TipoComidaDto(t.Id, t.Nombre, t.Orden, t.PorcentajeCalorias)).ToListAsync(ct);
        var nutricionistas = await db.Usuarios.AsNoTracking().Where(u => u.Activo && u.Rol!.Nombre == Roles.Nutricionista)
            .OrderBy(u => u.Nombre).Select(u => new OpcionDto(u.Id, u.Nombre, null)).ToListAsync(ct);
        var docentes = await db.Usuarios.AsNoTracking().Where(u => u.Activo && u.Rol!.Nombre == Roles.Docente)
            .OrderBy(u => u.Nombre).Select(u => new OpcionDto(u.Id, u.Nombre, null)).ToListAsync(ct);

        return new CatalogosDto(Roles.Lista, cursos, niveles, objetivos, categorias, tipos, nutricionistas, docentes);
    }
}
