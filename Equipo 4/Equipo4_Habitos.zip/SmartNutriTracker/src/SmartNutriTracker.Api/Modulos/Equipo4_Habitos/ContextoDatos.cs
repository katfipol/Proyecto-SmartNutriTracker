// EQUIPO 4 – Registro de Hábitos
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 4 – Registro de Hábitos dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<RegistroConsumo> RegistrosConsumo => Set<RegistroConsumo>();
    public DbSet<RegistroHabito> RegistrosHabitos => Set<RegistroHabito>();

    partial void ConfigurarEquipo4(ModelBuilder mb)
    {
        mb.Entity<RegistroConsumo>().ToTable("RegistrosConsumo");
        mb.Entity<RegistroHabito>().ToTable("RegistrosHabitos");
    }
}
