# SmartNutriTracker · Equipo 6 – Notificaciones y Testing

**Historias de usuario:** HU-27, HU-28, HU-29, HU-32 (+ HU-30 y HU-31)  
**Proyecto:** SmartNutriTracker – Colegio "Innovare" · Programación Web III  
**Tecnologías:** .NET 10 · ASP.NET Core Web API · Entity Framework Core 10 · SQL Server · HTML + JS + Bootstrap 5

Este ZIP contiene **solo la parte del Equipo 6**, con las mismas rutas del proyecto completo.
Para tener el sistema funcionando, **descomprima los 6 ZIP en la misma carpeta**: los archivos no se pisan.

---

## 1. Historias de usuario implementadas

| HU | Descripción | Implementación |
|---|---|---|
| HU-27 | Alertas de hábitos no saludables | `ReglasAlertas` evalúa exceso o déficit de calorías, azúcar, sodio, agua, sueño, actividad e IMC en riesgo. Notifica al docente, a los nutricionistas y al estudiante |
| HU-28 | Notificaciones internas y recordatorios | `NotificacionesService` + `RecordatoriosBackgroundService`: recordatorio diario desde las 19:00 y aviso de cita 24 h antes |
| HU-29 | Logs globales | `Logs/ArchivoLogger.cs`: un archivo por día en `logs/`. `ManejoErroresMiddleware`: errores en formato ProblemDetails |
| HU-32 | Documentación con Swagger | Comentarios XML en todos los controladores, visibles en `/swagger` |
| HU-30 / HU-31 | Pruebas y CI/CD | Proyecto `tests/` con 56 casos (xUnit) y `.github/workflows/ci.yml` |

### Pruebas
Este equipo entrega el proyecto de pruebas (`.csproj` y `DatosPrueba.cs`).
Los casos de prueba de cada módulo también vienen en el ZIP de su equipo:
- Equipo 1: `PasswordHasherTests`.
- Equipo 5: `CalculadoraNutricionalTests` y `GeneradorMenuTests`.

Para ejecutarlas, con los 6 ZIP juntos:
```bash
dotnet test
```

### Citas
- Horario de 07:00 a 19:00.
- No se permiten cruces de horario con el nutricionista ni con el estudiante.
- Se notifica al crear, reprogramar y cancelar.

## 2. Base de datos

**Script del equipo:** `database/por_equipo/6_Equipo6_Notificaciones.sql`

Orden de ejecución en SSMS (base nueva): **Equipo 1 → 2 → 3 → 4 → 5 → 6**.
- El script del Equipo 1 crea la base desde cero.
- Cada script comprueba que ya se ejecutaron los anteriores.

### Tablas del equipo
- `TiposAlerta`
- `Alertas`
- `Notificaciones`
- `Citas`

### Normalización (3FN)
- `Alertas.TipoAlertaId` es una FK: el nombre, el umbral y el nivel viven solo en `TiposAlerta` (3FN).
- `Alertas.ValorRegistrado` es el valor medido ese día (hecho histórico).
- `UNIQUE (EstudianteId, TipoAlertaId, Fecha)` asegura una alerta por tipo y día.
- Los estados de cita y los tipos de notificación son dominios cerrados con `CHECK`.

## 3. API REST (endpoints del equipo)

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| GET | `/api/alertas` | Cualquier usuario autenticado | Listar |
| PATCH | `/api/alertas/{id}/atender` | Admin, Docente, Nutricionista | Marcar alerta como atendida |
| POST | `/api/alertas/evaluar` | Admin, Nutricionista | Evalúa las reglas para todos los estudiantes en una fecha (por defecto ayer, día cerrado). |
| GET | `/api/notificaciones` | Cualquier usuario autenticado | Listar |
| GET | `/api/notificaciones/contador` | Cualquier usuario autenticado | Cantidad de notificaciones sin leer |
| PATCH | `/api/notificaciones/{id}/leer` | Cualquier usuario autenticado | Marcar como leída |
| PATCH | `/api/notificaciones/leer-todas` | Cualquier usuario autenticado | Marcar todas como leídas |
| GET | `/api/citas` | Cualquier usuario autenticado | Listar |
| POST | `/api/citas` | Admin, Docente, Nutricionista | Crear |
| PUT | `/api/citas/{id}` | Admin, Docente, Nutricionista | Actualizar |
| PATCH | `/api/citas/{id}/estado` | Admin, Docente, Nutricionista | Cambiar estado |

Todas las rutas (salvo el login) requieren el encabezado `Authorization: Bearer <token>`.
Para probarlas en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 4. Frontend (pantallas del equipo)
- Alertas: pendientes, atendidas y evaluación manual (`vistas/alertas.js`)
- Citas nutricionales (`vistas/citas.js`)
- Notificaciones y contador de la campana (`vistas/notificaciones.js`)

## 5. Archivos del equipo

**Backend**
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/ContextoDatos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Dominio/ReglasAlertas.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Entidades.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Logs/ArchivoLogger.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Logs/ManejoErroresMiddleware.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/AlertasService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/CitasService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/Mapeos.Equipo6.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/NotificacionesService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo6_Notificaciones/Servicios/RecordatoriosBackgroundService.cs`

**Frontend**
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/alertas.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/citas.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/notificaciones.js`

**Base de datos**
- `database/por_equipo/6_Equipo6_Notificaciones.sql`

**Pruebas**
- `tests/SmartNutriTracker.Tests/DatosPrueba.cs`
- `tests/SmartNutriTracker.Tests/ReglasAlertasTests.cs`
- `tests/SmartNutriTracker.Tests/SmartNutriTracker.Tests.csproj`

**Otros**
- `.github/workflows/ci.yml`

## 6. Dependencias con otros equipos
Equipos 1 a 5 (es el último script SQL). Su servicio de alertas lo llaman los Equipos 2 y 4.

La integración se hace así:
- **Clase parcial `SmartNutriDbContext`:** cada equipo aporta sus `DbSet` y su configuración en `ContextoDatos.cs`, mediante el método `ConfigurarEquipo6`.
- **Clase parcial `Mapeos`:** cada equipo aporta sus conversiones a DTO.
- **Inyección de dependencias:** los servicios se registran en `Program.cs`, que entrega el Equipo 1.

## 7. Cómo ejecutar el sistema completo
1. Descomprima los 6 ZIP en la misma carpeta (por ejemplo `SmartNutriTracker/`).
2. Ejecute en SSMS los scripts `database/por_equipo/1_…sql` a `6_…sql`, en orden.
3. Ajuste la cadena de conexión en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
4. En la carpeta raíz, ejecute:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
5. Abra http://localhost:5200 para el sistema y http://localhost:5200/swagger para la API.

**Usuarios de prueba** (contraseña `Innovare2026!`):

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |
