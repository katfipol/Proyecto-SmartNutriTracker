// HU-28 – Notificaciones internas
import { api, conParametros } from '../api.js';
import { esc, fechaHoraUtc, haceCuanto, vacio, toast, on } from '../ui.js';

let soloNoLeidas = false;
const ICONOS = {
  Recordatorio: ['bi-alarm', 'ic-lima'], Alerta: ['bi-exclamation-triangle', 'ic-coral'],
  Cita: ['bi-calendar2-heart', 'ic-ambar'], Sistema: ['bi-info-circle', 'ic-verde']
};

export async function render(ctx) {
  const { el } = ctx;
  const lista = await api.get(conParametros('/api/notificaciones', { soloNoLeidas }));
  el.innerHTML = `
    <div class="tarjeta" style="max-width:860px">
      <div class="cabecera">
        <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="solo" ${soloNoLeidas ? 'checked' : ''}>
          <label class="form-check-label" for="solo">Solo no leídas</label></div>
        <button class="btn btn-sm btn-outline-primary ms-auto" data-accion="todas"><i class="bi bi-check2-all me-1"></i>Marcar todas como leídas</button>
      </div>
      <div class="cuerpo p-0">${lista.length ? lista.map(n => {
        const [ic, color] = ICONOS[n.tipo] || ICONOS.Sistema;
        return `<div class="notif ${n.leida ? '' : 'no-leida'}">
          <div class="ic ${color}"><i class="bi ${ic}"></i></div>
          <div class="flex-grow-1"><div class="d-flex justify-content-between"><strong>${esc(n.titulo)}</strong>
            <span class="small muted" title="${fechaHoraUtc(n.fechaCreacion)}">${haceCuanto(n.fechaCreacion)}</span></div>
            <div class="small">${esc(n.mensaje)}</div></div>
          ${n.leida ? '' : `<button class="btn btn-sm btn-light align-self-center" data-accion="leer" data-id="${n.id}" title="Marcar como leída"><i class="bi bi-check2"></i></button>`}
        </div>`;
      }).join('') : vacio('No tienes notificaciones.', 'bi-bell-slash')}</div>
    </div>`;

  const avisar = () => window.dispatchEvent(new Event('snt:notificaciones'));
  el.querySelector('#solo').addEventListener('change', (ev) => { soloNoLeidas = ev.target.checked; render(ctx); });
  on(el, 'click', '[data-accion=leer]', async (_, b) => { await api.patch(`/api/notificaciones/${b.dataset.id}/leer`); avisar(); render(ctx); });
  on(el, 'click', '[data-accion=todas]', async () => { await api.patch('/api/notificaciones/leer-todas'); avisar(); toast('Notificaciones marcadas como leídas.'); render(ctx); });
}
