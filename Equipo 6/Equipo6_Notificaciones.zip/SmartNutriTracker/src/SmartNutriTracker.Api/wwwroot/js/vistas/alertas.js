// HU-27 – Alertas de hábitos no saludables
import { api, conParametros } from '../api.js';
import { esSalud } from '../estado.js';
import { esc, fecha, fechaHoraUtc, vacio, toast, on, badgeNivel } from '../ui.js';

let filtro = 'pendientes';

export async function render(ctx) {
  const { el } = ctx;
  const atendida = filtro === 'pendientes' ? false : filtro === 'atendidas' ? true : null;
  const lista = await api.get(conParametros('/api/alertas', { atendida }));

  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2">
        <ul class="nav nav-pills nav-sm">
          ${['pendientes', 'atendidas', 'todas'].map(f => `<li class="nav-item"><a class="nav-link py-1 ${f === filtro ? 'active' : ''}" href="#" data-filtro="${f}">${f[0].toUpperCase() + f.slice(1)}</a></li>`).join('')}
        </ul>
        ${esSalud() ? `<button class="btn btn-sm btn-outline-primary ms-auto" data-accion="evaluar" title="Evalúa el día de ayer para todos los estudiantes">
          <i class="bi bi-arrow-repeat me-1"></i>Evaluar día anterior</button>` : ''}
      </div>
      <div class="cuerpo p-0">${lista.length ? `<div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Fecha</th><th>Estudiante</th><th>Tipo</th><th>Nivel</th><th>Detalle</th><th>Estado</th><th></th></tr></thead>
        <tbody>${lista.map(a => `<tr>
          <td class="text-nowrap">${fecha(a.fecha)}</td>
          <td><a href="#/estudiante/${a.estudianteId}" class="fw-semibold">${esc(a.estudiante)}</a><div class="small muted">${esc(a.curso)}</div></td>
          <td>${esc(a.tipo)}</td><td>${badgeNivel(a.nivel)}</td>
          <td class="small">${esc(a.mensaje)}</td>
          <td class="small">${a.atendida ? `<span class="badge b-verde">Atendida</span><div class="muted">${esc(a.atendidaPor ?? '')} · ${fechaHoraUtc(a.fechaAtencion)}</div>` : '<span class="badge b-coral">Pendiente</span>'}</td>
          <td class="text-end">${a.atendida ? '' : `<button class="btn btn-sm btn-success text-nowrap" data-accion="atender" data-id="${a.id}"><i class="bi bi-check2 me-1"></i>Atender</button>`}</td>
        </tr>`).join('')}</tbody></table></div>` : vacio(filtro === 'pendientes' ? 'No hay alertas pendientes. ¡Todo en orden!' : 'Sin alertas.', 'bi-shield-check')}
      </div>
    </div>
    <p class="small muted mt-2"><i class="bi bi-info-circle"></i> Las alertas se generan automáticamente al registrar comidas y hábitos, y cada día para el día anterior. Los umbrales se configuran en <a href="#/reglas">Reglas nutricionales</a>.</p>`;

  on(el, 'click', '[data-filtro]', (ev, a) => { ev.preventDefault(); filtro = a.dataset.filtro; render(ctx); });
  on(el, 'click', '[data-accion=atender]', async (_, b) => {
    try { await api.patch(`/api/alertas/${b.dataset.id}/atender`); toast('Alerta marcada como atendida.'); render(ctx); }
    catch (e) { toast(e.message, 'error'); }
  });
  on(el, 'click', '[data-accion=evaluar]', async (_, b) => {
    b.disabled = true;
    try { const r = await api.post('/api/alertas/evaluar'); toast(r.mensaje, 'info'); render(ctx); }
    catch (e) { toast(e.message, 'error'); b.disabled = false; }
  });
}
