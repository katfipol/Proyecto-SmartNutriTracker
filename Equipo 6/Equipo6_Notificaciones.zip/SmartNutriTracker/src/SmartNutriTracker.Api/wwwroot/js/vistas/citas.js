// Gestión de citas nutricionales y recordatorios
import { api, conParametros } from '../api.js';
import { estado, esPersonal, cargarEstudiantes } from '../estado.js';
import { esc, fechaHora, hoyIso, sumarDias, vacio, abrirModal, opciones, toast, on, badgeEstado, leerFormulario } from '../ui.js';

let rango = 'proximas';

export async function render(ctx) {
  const { el } = ctx;
  const personal = esPersonal();
  if (personal) await cargarEstudiantes();
  const hoy = hoyIso();
  const params = rango === 'proximas' ? { desde: hoy } : rango === 'pasadas' ? { desde: sumarDias(hoy, -90), hasta: sumarDias(hoy, -1) } : {};
  const citas = await api.get(conParametros('/api/citas', params));

  el.innerHTML = `
    <div class="tarjeta">
      <div class="cabecera flex-wrap gap-2">
        <ul class="nav nav-pills">
          ${[['proximas', 'Próximas'], ['pasadas', 'Pasadas'], ['todas', 'Todas']].map(([k, t]) =>
            `<li class="nav-item"><a class="nav-link py-1 ${k === rango ? 'active' : ''}" href="#" data-rango="${k}">${t}</a></li>`).join('')}
        </ul>
        ${personal ? '<button class="btn btn-primary btn-sm ms-auto" data-accion="nueva"><i class="bi bi-calendar-plus me-1"></i>Programar cita</button>' : ''}
      </div>
      <div class="cuerpo p-0">${citas.length ? `<div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Fecha y hora</th><th>Estudiante</th><th>Nutricionista</th><th>Motivo</th><th>Estado</th>${personal ? '<th></th>' : ''}</tr></thead>
        <tbody>${citas.map(c => `<tr>
          <td class="fw-semibold text-nowrap">${fechaHora(c.fechaHora)}<div class="small muted fw-normal">${c.duracionMinutos} min</div></td>
          <td>${esc(c.estudiante)}</td><td>${esc(c.nutricionista)}</td>
          <td class="small">${esc(c.motivo)}${c.notas ? `<div class="muted">Notas: ${esc(c.notas)}</div>` : ''}</td>
          <td>${badgeEstado(c.estado)}</td>
          ${personal ? `<td class="text-end text-nowrap">${c.estado === 'Programada' ? `
            <button class="btn btn-sm btn-light" data-accion="editar" data-id="${c.id}" title="Reprogramar"><i class="bi bi-pencil"></i></button>
            <button class="btn btn-sm btn-success" data-accion="estado" data-id="${c.id}" data-estado="Completada" title="Completar"><i class="bi bi-check2"></i></button>
            <button class="btn btn-sm btn-light text-danger" data-accion="estado" data-id="${c.id}" data-estado="Cancelada" title="Cancelar"><i class="bi bi-x-lg"></i></button>` : ''}</td>` : ''}
        </tr>`).join('')}</tbody></table></div>` : vacio('No hay citas en este rango.', 'bi-calendar')}
      </div>
    </div>
    <p class="small muted mt-2"><i class="bi bi-bell"></i> El sistema envía un recordatorio al estudiante y al nutricionista 24 horas antes de cada cita.</p>`;

  const recargar = () => render(ctx);
  on(el, 'click', '[data-rango]', (ev, a) => { ev.preventDefault(); rango = a.dataset.rango; recargar(); });
  on(el, 'click', '[data-accion=nueva]', () => formulario(null, recargar));
  on(el, 'click', '[data-accion=editar]', (_, b) => formulario(citas.find(c => c.id === parseInt(b.dataset.id, 10)), recargar));
  on(el, 'click', '[data-accion=estado]', (_, b) => {
    const nuevo = b.dataset.estado;
    abrirModal({
      titulo: nuevo === 'Completada' ? 'Completar cita' : 'Cancelar cita',
      cuerpo: `<label class="form-label">Notas</label><textarea class="form-control" id="notas" rows="3" maxlength="500" placeholder="${nuevo === 'Completada' ? 'Indicaciones dadas al estudiante...' : 'Motivo de la cancelación...'}"></textarea>`,
      textoGuardar: nuevo === 'Completada' ? 'Marcar completada' : 'Cancelar cita',
      alGuardar: async (form) => {
        await api.patch(`/api/citas/${b.dataset.id}/estado`, { estado: nuevo, notas: form.querySelector('#notas').value.trim() || null });
        toast(`Cita ${nuevo.toLowerCase()}.`);
        recargar();
      }
    });
  });
}

function formulario(c, recargar) {
  const nutris = estado.catalogos.nutricionistas;
  const valorLocal = (v) => v ? v.substring(0, 16) : `${sumarDias(hoyIso(), 1)}T10:00`;
  abrirModal({
    titulo: c ? 'Reprogramar cita' : 'Programar cita nutricional',
    cuerpo: `<div class="row g-3">
      <div class="col-12"><label class="form-label">Estudiante</label><select class="form-select" name="estudianteId" data-tipo="int" required>
        ${opciones((estado.estudiantes || []).map(e => ({ id: e.id, nombre: `${e.nombreCompleto} · ${e.curso}` })), c?.estudianteId)}</select></div>
      <div class="col-12"><label class="form-label">Nutricionista</label><select class="form-select" name="nutricionistaId" data-tipo="int" required>
        ${opciones(nutris, c?.nutricionistaId ?? (estado.usuario.rol === 'Nutricionista' ? estado.usuario.id : nutris[0]?.id))}</select></div>
      <div class="col-md-8"><label class="form-label">Fecha y hora</label><input type="datetime-local" class="form-control" name="fechaHora" required value="${valorLocal(c?.fechaHora)}"></div>
      <div class="col-md-4"><label class="form-label">Duración</label><select class="form-select" name="duracionMinutos" data-tipo="int">
        ${[15, 30, 45, 60].map(m => `<option value="${m}" ${(c?.duracionMinutos ?? 30) === m ? 'selected' : ''}>${m} min</option>`).join('')}</select></div>
      <div class="col-12"><label class="form-label">Motivo</label><input class="form-control" name="motivo" required maxlength="200" value="${esc(c?.motivo ?? '')}" placeholder="Control de peso, revisión de hábitos..."></div>
    </div>`,
    alGuardar: async (form) => {
      const datos = leerFormulario(form);
      datos.fechaHora = `${datos.fechaHora}:00`;
      if (c) await api.put(`/api/citas/${c.id}`, datos); else await api.post('/api/citas', datos);
      toast(c ? 'Cita reprogramada.' : 'Cita programada. Se notificó al estudiante.');
      recargar();
    }
  });
}
