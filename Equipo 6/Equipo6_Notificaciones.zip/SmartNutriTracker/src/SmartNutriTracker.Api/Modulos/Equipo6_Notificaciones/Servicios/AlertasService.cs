// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IAlertasService
{
    /// <summary>Evalúa las reglas del día; crea alertas nuevas y notifica a docente y nutricionistas.</summary>
    Task<int> EvaluarDiaAsync(int estudianteId, DateOnly fecha, bool diaCerrado, CancellationToken ct = default);
    Task<int> EvaluarImcAsync(int estudianteId, CancellationToken ct = default);
    Task<int> EvaluarTodosAsync(DateOnly fecha, bool diaCerrado, CancellationToken ct = default);
    Task<IReadOnlyList<AlertaDto>> ListarAsync(bool? atendida, int? estudianteId, CancellationToken ct = default);
    Task<AlertaDto> AtenderAsync(int id, CancellationToken ct = default);
    Task<IReadOnlyList<TipoAlertaDto>> TiposAsync(CancellationToken ct = default);
    Task<TipoAlertaDto> ActualizarTipoAsync(int id, TipoAlertaRequest request, CancellationToken ct = default);
}

public class AlertasService(
    SmartNutriDbContext db,
    IAccesoService acceso,
    IUsuarioActual usuario,
    INutricionService nutricion,
    INotificacionesService notificaciones,
    IAuditoriaService auditoria,
    ILogger<AlertasService> logger) : IAlertasService
{
    public async Task<int> EvaluarDiaAsync(int estudianteId, DateOnly fecha, bool diaCerrado, CancellationToken ct = default)
    {
        var tipos = await TiposActivosAsync(ct);
        if (tipos.Count == 0) return 0;

        var consumo = await db.RegistrosConsumo.AsNoTracking()
            .Where(r => r.EstudianteId == estudianteId && r.Fecha == fecha)
            .Select(r => new { r.Porciones, r.Alimento!.Calorias, r.Alimento.Azucares, r.Alimento.SodioMg })
            .ToListAsync(ct);
        var habito = await db.RegistrosHabitos.AsNoTracking().FirstOrDefaultAsync(h => h.EstudianteId == estudianteId && h.Fecha == fecha, ct);

        var dia = new ResumenDia(fecha,
            consumo.Count > 0,
            consumo.Sum(c => c.Calorias * c.Porciones),
            Math.Round(consumo.Sum(c => c.Azucares * c.Porciones), 1),
            Math.Round(consumo.Sum(c => c.SodioMg * c.Porciones), 0),
            habito is not null,
            habito?.HorasSueno ?? 0, habito?.AguaMl ?? 0, habito?.MinutosActividad ?? 0);

        var e = await nutricion.CargarEstudianteAsync(estudianteId, ct);
        var calculo = await nutricion.CalcularEstudianteAsync(e, fecha, ct: ct);
        var detectadas = ReglasAlertas.Evaluar(dia, calculo.CaloriasObjetivo, tipos, diaCerrado);
        return await GuardarAsync(e, fecha, detectadas, ct);
    }

    public async Task<int> EvaluarImcAsync(int estudianteId, CancellationToken ct = default)
    {
        var tipos = await TiposActivosAsync(ct);
        var e = await nutricion.CargarEstudianteAsync(estudianteId, ct);
        var hoy = DateOnly.FromDateTime(DateTime.Today);
        var calculo = await nutricion.CalcularEstudianteAsync(e, hoy, ct: ct);
        var alerta = ReglasAlertas.EvaluarImc(calculo.Imc, calculo.CategoriaImc, tipos);
        return alerta is null ? 0 : await GuardarAsync(e, hoy, [alerta], ct);
    }

    public async Task<int> EvaluarTodosAsync(DateOnly fecha, bool diaCerrado, CancellationToken ct = default)
    {
        var ids = await db.Estudiantes.AsNoTracking().Where(e => e.Activo).Select(e => e.Id).ToListAsync(ct);
        var total = 0;
        foreach (var id in ids)
        {
            try { total += await EvaluarDiaAsync(id, fecha, diaCerrado, ct); }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "No se pudo evaluar alertas del estudiante {EstudianteId}", id);
            }
        }
        return total;
    }

    public async Task<IReadOnlyList<AlertaDto>> ListarAsync(bool? atendida, int? estudianteId, CancellationToken ct = default)
    {
        var visibles = acceso.EstudiantesVisibles().Select(e => e.Id);
        var q = db.Alertas.AsNoTracking()
            .Where(a => visibles.Contains(a.EstudianteId))
            .Include(a => a.Estudiante).ThenInclude(e => e!.Curso)
            .Include(a => a.TipoAlerta)
            .Include(a => a.AtendidaPor)
            .AsQueryable();
        if (atendida.HasValue) q = q.Where(a => a.Atendida == atendida);
        if (estudianteId.HasValue) q = q.Where(a => a.EstudianteId == estudianteId);
        var lista = await q.OrderByDescending(a => a.Fecha).ThenByDescending(a => a.Id).Take(300).ToListAsync(ct);
        return lista.Select(Mapeos.ADto).ToList();
    }

    public async Task<AlertaDto> AtenderAsync(int id, CancellationToken ct = default)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("Solo el personal puede atender alertas.");
        var a = await db.Alertas.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Alerta {id} no encontrada.");
        await acceso.VerificarEstudianteAsync(a.EstudianteId, ct);
        a.Atendida = true;
        a.AtendidaPorId = usuario.Id;
        a.FechaAtencion = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ATENDER", "Alerta", id, a.Mensaje, ct: ct);
        return (await ListarAsync(null, a.EstudianteId, ct)).First(x => x.Id == id);
    }

    public async Task<IReadOnlyList<TipoAlertaDto>> TiposAsync(CancellationToken ct = default) =>
        await db.TiposAlerta.AsNoTracking().OrderBy(t => t.Id)
            .Select(t => new TipoAlertaDto(t.Id, t.Codigo, t.Nombre, t.Descripcion, t.Umbral, t.Unidad, t.Nivel, t.Activo))
            .ToListAsync(ct);

    public async Task<TipoAlertaDto> ActualizarTipoAsync(int id, TipoAlertaRequest request, CancellationToken ct = default)
    {
        var t = await db.TiposAlerta.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Tipo de alerta {id} no encontrado.");
        t.Umbral = request.Umbral;
        t.Nivel = request.Nivel;
        t.Activo = request.Activo;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "TipoAlerta", id, $"{t.Codigo}: umbral {t.Umbral} {t.Unidad}, nivel {t.Nivel}", ct: ct);
        return new TipoAlertaDto(t.Id, t.Codigo, t.Nombre, t.Descripcion, t.Umbral, t.Unidad, t.Nivel, t.Activo);
    }

    private async Task<IReadOnlyList<TipoAlertaModelo>> TiposActivosAsync(CancellationToken ct) =>
        await db.TiposAlerta.AsNoTracking().Where(t => t.Activo)
            .Select(t => new TipoAlertaModelo(t.Id, t.Codigo, t.Nombre, t.Umbral, t.Unidad, t.Nivel))
            .ToListAsync(ct);

    /// <summary>Guarda alertas nuevas (una por tipo y día) o actualiza el valor si ya existía sin atender.</summary>
    private async Task<int> GuardarAsync(Estudiante e, DateOnly fecha, IReadOnlyList<AlertaDetectada> detectadas, CancellationToken ct)
    {
        if (detectadas.Count == 0) return 0;
        var tipoIds = detectadas.Select(d => d.TipoAlertaId).ToList();
        var existentes = await db.Alertas.Where(a => a.EstudianteId == e.Id && a.Fecha == fecha && tipoIds.Contains(a.TipoAlertaId)).ToListAsync(ct);

        var nuevas = new List<AlertaDetectada>();
        foreach (var d in detectadas)
        {
            var existente = existentes.FirstOrDefault(a => a.TipoAlertaId == d.TipoAlertaId);
            if (existente is null)
            {
                db.Alertas.Add(new Alerta
                {
                    EstudianteId = e.Id, TipoAlertaId = d.TipoAlertaId, Fecha = fecha, ValorRegistrado = Math.Round(d.Valor, 2),
                    Mensaje = d.Mensaje, Atendida = false, FechaCreacion = DateTime.UtcNow
                });
                nuevas.Add(d);
            }
            else if (!existente.Atendida)
            {
                existente.ValorRegistrado = Math.Round(d.Valor, 2);
                existente.Mensaje = d.Mensaje;
            }
        }
        await db.SaveChangesAsync(ct);

        if (nuevas.Count > 0)
        {
            var destinatarios = await db.Usuarios.AsNoTracking()
                .Where(u => u.Activo && (u.Rol!.Nombre == Roles.Nutricionista || u.Id == e.Curso!.DocenteId))
                .Select(u => u.Id).ToListAsync(ct);
            foreach (var d in nuevas)
            {
                await notificaciones.CrearAsync(destinatarios, $"Alerta: {e.NombreCompleto}", d.Mensaje, "Alerta", ct);
                if (e.UsuarioId.HasValue)
                    await notificaciones.CrearAsync([e.UsuarioId.Value], "Revisa tus hábitos", d.Mensaje, "Alerta", ct);
            }
            logger.LogInformation("Se generaron {Cantidad} alerta(s) para el estudiante {EstudianteId} ({Fecha})", nuevas.Count, e.Id, fecha);
        }
        return nuevas.Count;
    }
}
