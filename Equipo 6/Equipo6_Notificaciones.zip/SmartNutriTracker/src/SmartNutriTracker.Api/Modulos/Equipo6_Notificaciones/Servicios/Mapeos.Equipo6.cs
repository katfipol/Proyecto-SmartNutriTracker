// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

/// <summary>Conversión a DTOs del Equipo 6 (clase parcial compartida).</summary>
public static partial class Mapeos
{
    public static CitaDto ADto(Cita c) =>
        new(c.Id, c.EstudianteId, c.Estudiante?.NombreCompleto ?? string.Empty, c.NutricionistaId, c.Nutricionista?.Nombre ?? string.Empty,
            c.FechaHora, c.DuracionMinutos, c.Motivo, c.Estado, c.Notas);

    public static AlertaDto ADto(Alerta a) =>
        new(a.Id, a.EstudianteId, a.Estudiante?.NombreCompleto ?? string.Empty, a.Estudiante?.Curso?.Nombre ?? string.Empty,
            a.TipoAlerta?.Nombre ?? string.Empty, a.TipoAlerta?.Codigo ?? string.Empty, a.TipoAlerta?.Nivel ?? string.Empty,
            a.Fecha, a.ValorRegistrado, a.Mensaje, a.Atendida, a.AtendidaPor?.Nombre, a.FechaAtencion);
}
