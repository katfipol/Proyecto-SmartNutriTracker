// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface ICitasService
{
    Task<IReadOnlyList<CitaDto>> ListarAsync(DateOnly? desde, DateOnly? hasta, int? estudianteId, CancellationToken ct = default);
    Task<CitaDto> CrearAsync(CitaRequest request, CancellationToken ct = default);
    Task<CitaDto> ActualizarAsync(int id, CitaRequest request, CancellationToken ct = default);
    Task<CitaDto> CambiarEstadoAsync(int id, EstadoCitaRequest request, CancellationToken ct = default);
}

public class CitasService(
    SmartNutriDbContext db,
    IAccesoService acceso,
    IUsuarioActual usuario,
    INotificacionesService notificaciones,
    IAuditoriaService auditoria) : ICitasService
{
    public async Task<IReadOnlyList<CitaDto>> ListarAsync(DateOnly? desde, DateOnly? hasta, int? estudianteId, CancellationToken ct = default)
    {
        var visibles = acceso.EstudiantesVisibles().Select(e => e.Id);
        var q = db.Citas.AsNoTracking().Where(c => visibles.Contains(c.EstudianteId))
            .Include(c => c.Estudiante).Include(c => c.Nutricionista).AsQueryable();
        if (usuario.EsNutricionista) { var uid = usuario.Id; q = q.Where(c => c.NutricionistaId == uid); }
        if (desde.HasValue) { var d = desde.Value.ToDateTime(TimeOnly.MinValue); q = q.Where(c => c.FechaHora >= d); }
        if (hasta.HasValue) { var h = hasta.Value.AddDays(1).ToDateTime(TimeOnly.MinValue); q = q.Where(c => c.FechaHora < h); }
        if (estudianteId.HasValue) q = q.Where(c => c.EstudianteId == estudianteId);
        return (await q.OrderBy(c => c.FechaHora).ToListAsync(ct)).Select(Mapeos.ADto).ToList();
    }

    public async Task<CitaDto> CrearAsync(CitaRequest r, CancellationToken ct = default)
    {
        await ValidarAsync(r, null, ct);
        var c = new Cita
        {
            EstudianteId = r.EstudianteId, NutricionistaId = r.NutricionistaId, FechaHora = r.FechaHora,
            DuracionMinutos = r.DuracionMinutos, Motivo = r.Motivo.Trim(), Estado = "Programada", FechaCreacion = DateTime.UtcNow
        };
        db.Citas.Add(c);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CREAR", "Cita", c.Id, $"Estudiante {r.EstudianteId} - {r.FechaHora:yyyy-MM-dd HH:mm}", ct: ct);
        await NotificarAsync(c.Id, "Nueva cita nutricional", ct);
        return await ObtenerAsync(c.Id, ct);
    }

    public async Task<CitaDto> ActualizarAsync(int id, CitaRequest r, CancellationToken ct = default)
    {
        var c = await db.Citas.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Cita {id} no encontrada.");
        if (c.Estado != "Programada") throw new ReglaNegocioException("Solo se pueden modificar citas programadas.");
        await ValidarAsync(r, id, ct);
        c.EstudianteId = r.EstudianteId;
        c.NutricionistaId = r.NutricionistaId;
        c.FechaHora = r.FechaHora;
        c.DuracionMinutos = r.DuracionMinutos;
        c.Motivo = r.Motivo.Trim();
        c.RecordatorioEnviado = false;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "Cita", id, $"{r.FechaHora:yyyy-MM-dd HH:mm}", ct: ct);
        await NotificarAsync(id, "Cita reprogramada", ct);
        return await ObtenerAsync(id, ct);
    }

    public async Task<CitaDto> CambiarEstadoAsync(int id, EstadoCitaRequest r, CancellationToken ct = default)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("Solo el personal puede cambiar el estado de una cita.");
        var c = await db.Citas.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Cita {id} no encontrada.");
        await acceso.VerificarEstudianteAsync(c.EstudianteId, ct);
        c.Estado = r.Estado;
        c.Notas = r.Notas;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CAMBIAR_ESTADO", "Cita", id, r.Estado, ct: ct);
        if (r.Estado == "Cancelada") await NotificarAsync(id, "Cita cancelada", ct);
        return await ObtenerAsync(id, ct);
    }

    private async Task<CitaDto> ObtenerAsync(int id, CancellationToken ct)
    {
        var c = await db.Citas.AsNoTracking().Include(x => x.Estudiante).Include(x => x.Nutricionista).FirstAsync(x => x.Id == id, ct);
        return Mapeos.ADto(c);
    }

    private async Task ValidarAsync(CitaRequest r, int? id, CancellationToken ct)
    {
        if (usuario.EsEstudiante) throw new AccesoDenegadoException("Las citas las programa el personal del colegio.");
        await acceso.VerificarEstudianteAsync(r.EstudianteId, ct);
        if (r.FechaHora < DateTime.Now.AddMinutes(-5)) throw new ReglaNegocioException("La cita no puede programarse en el pasado.");
        if (r.FechaHora.Hour is < 7 or >= 19) throw new ReglaNegocioException("Las citas deben estar entre las 07:00 y las 19:00.");
        if (!await db.Usuarios.AnyAsync(u => u.Id == r.NutricionistaId && u.Activo && u.Rol!.Nombre == Roles.Nutricionista, ct))
            throw new ReglaNegocioException("El nutricionista indicado no es válido.");

        var inicio = r.FechaHora;
        var fin = r.FechaHora.AddMinutes(r.DuracionMinutos);
        var cruces = await db.Citas.AsNoTracking()
            .Where(c => c.Id != id && c.Estado == "Programada" &&
                        (c.NutricionistaId == r.NutricionistaId || c.EstudianteId == r.EstudianteId) &&
                        c.FechaHora < fin && c.FechaHora.AddMinutes(c.DuracionMinutos) > inicio)
            .AnyAsync(ct);
        if (cruces) throw new ReglaNegocioException("El horario se cruza con otra cita del nutricionista o del estudiante.");
    }

    private async Task NotificarAsync(int citaId, string titulo, CancellationToken ct)
    {
        var c = await db.Citas.AsNoTracking().Include(x => x.Estudiante).FirstAsync(x => x.Id == citaId, ct);
        var ids = new List<int> { c.NutricionistaId };
        if (c.Estudiante!.UsuarioId.HasValue) ids.Add(c.Estudiante.UsuarioId.Value);
        await notificaciones.CrearAsync(ids, titulo,
            $"{c.Estudiante.NombreCompleto}: {c.FechaHora:dd/MM/yyyy HH:mm} ({c.DuracionMinutos} min) - {c.Motivo}", "Cita", ct);
    }
}
