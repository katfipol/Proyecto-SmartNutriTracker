// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data;

namespace SmartNutriTracker.Api.Services;

public sealed class RecordatoriosOptions
{
    public bool Habilitado { get; set; } = true;
    /// <summary>Hora local (0-23) a partir de la cual se envía el recordatorio diario.</summary>
    public int HoraRecordatorioDiario { get; set; } = 19;
    public int IntervaloMinutos { get; set; } = 30;
}

/// <summary>
/// HU-28 – Tareas automáticas:
///  • Recordatorio diario a los estudiantes que aún no registraron comidas ni hábitos.
///  • Recordatorio de citas en las próximas 24 horas.
///  • Evaluación de alertas del día anterior (día cerrado: incluye déficit calórico).
/// </summary>
public class RecordatoriosBackgroundService(
    IServiceScopeFactory scopes,
    Microsoft.Extensions.Options.IOptions<RecordatoriosOptions> opciones,
    ILogger<RecordatoriosBackgroundService> logger) : BackgroundService
{
    private DateOnly? _ultimoRecordatorioDiario;
    private DateOnly? _ultimaEvaluacionCierre;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var op = opciones.Value;
        if (!op.Habilitado)
        {
            logger.LogInformation("Recordatorios automáticos deshabilitados.");
            return;
        }

        await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(Math.Max(1, op.IntervaloMinutos)));
        do
        {
            try
            {
                await EjecutarCicloAsync(op, stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogError(ex, "Error en el ciclo de recordatorios");
            }
        } while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    private async Task EjecutarCicloAsync(RecordatoriosOptions op, CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<SmartNutriDbContext>();
        var notificaciones = scope.ServiceProvider.GetRequiredService<INotificacionesService>();
        var alertas = scope.ServiceProvider.GetRequiredService<IAlertasService>();

        var hoy = DateOnly.FromDateTime(DateTime.Today);

        // 1) Alertas del día anterior (una vez por día)
        if (_ultimaEvaluacionCierre != hoy)
        {
            var generadas = await alertas.EvaluarTodosAsync(hoy.AddDays(-1), diaCerrado: true, ct);
            _ultimaEvaluacionCierre = hoy;
            logger.LogInformation("Evaluación de cierre del {Fecha}: {Cantidad} alerta(s) nueva(s)", hoy.AddDays(-1), generadas);
        }

        // 2) Recordatorio diario de registro
        if (DateTime.Now.Hour >= op.HoraRecordatorioDiario && _ultimoRecordatorioDiario != hoy)
        {
            var sinRegistro = await db.Estudiantes.AsNoTracking()
                .Where(e => e.Activo && e.UsuarioId != null &&
                            !db.RegistrosConsumo.Any(r => r.EstudianteId == e.Id && r.Fecha == hoy) &&
                            !db.RegistrosHabitos.Any(h => h.EstudianteId == e.Id && h.Fecha == hoy))
                .Select(e => e.UsuarioId!.Value)
                .ToListAsync(ct);

            // Evita duplicar si la app se reinicia el mismo día
            var inicioDia = DateTime.Today.ToUniversalTime();
            var yaNotificados = await db.Notificaciones.AsNoTracking()
                .Where(n => n.Tipo == "Recordatorio" && n.FechaCreacion >= inicioDia && n.Titulo == "Registra tu día")
                .Select(n => n.UsuarioId).ToListAsync(ct);

            var destinatarios = sinRegistro.Except(yaNotificados).ToList();
            await notificaciones.CrearAsync(destinatarios, "Registra tu día",
                "Aún no registraste tus comidas ni tus hábitos de hoy (agua, sueño y actividad física).", "Recordatorio", ct);
            _ultimoRecordatorioDiario = hoy;
            logger.LogInformation("Recordatorio diario enviado a {Cantidad} estudiante(s)", destinatarios.Count);
        }

        // 3) Recordatorio de citas en las próximas 24 h
        var ahora = DateTime.Now;
        var limite = ahora.AddHours(24);
        var citas = await db.Citas.Include(c => c.Estudiante)
            .Where(c => c.Estado == "Programada" && !c.RecordatorioEnviado && c.FechaHora >= ahora && c.FechaHora <= limite)
            .ToListAsync(ct);
        foreach (var c in citas)
        {
            var ids = new List<int> { c.NutricionistaId };
            if (c.Estudiante?.UsuarioId is int uid) ids.Add(uid);
            await notificaciones.CrearAsync(ids, "Recordatorio de cita",
                $"Cita nutricional de {c.Estudiante?.NombreCompleto} el {c.FechaHora:dd/MM/yyyy} a las {c.FechaHora:HH:mm}: {c.Motivo}", "Cita", ct);
            c.RecordatorioEnviado = true;
        }
        if (citas.Count > 0)
        {
            await db.SaveChangesAsync(ct);
            logger.LogInformation("Recordatorios de cita enviados: {Cantidad}", citas.Count);
        }
    }
}
