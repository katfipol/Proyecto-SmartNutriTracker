// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Data.Entities;

public class TipoAlerta
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string? Descripcion { get; set; }
    public decimal Umbral { get; set; }
    public string Unidad { get; set; } = string.Empty;
    public string Nivel { get; set; } = "Media";
    public bool Activo { get; set; } = true;
}

public class Alerta
{
    public int Id { get; set; }
    public int EstudianteId { get; set; }
    public int TipoAlertaId { get; set; }
    public DateOnly Fecha { get; set; }
    public decimal ValorRegistrado { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public bool Atendida { get; set; }
    public int? AtendidaPorId { get; set; }
    public DateTime? FechaAtencion { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public Estudiante? Estudiante { get; set; }
    public TipoAlerta? TipoAlerta { get; set; }
    public Usuario? AtendidaPor { get; set; }
}

public class Notificacion
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string Mensaje { get; set; } = string.Empty;
    public string Tipo { get; set; } = "Sistema";
    public bool Leida { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}

public class Cita
{
    public int Id { get; set; }
    public int EstudianteId { get; set; }
    public int NutricionistaId { get; set; }
    public DateTime FechaHora { get; set; }
    public int DuracionMinutos { get; set; } = 30;
    public string Motivo { get; set; } = string.Empty;
    public string Estado { get; set; } = "Programada";
    public string? Notas { get; set; }
    public bool RecordatorioEnviado { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public Estudiante? Estudiante { get; set; }
    public Usuario? Nutricionista { get; set; }
}
