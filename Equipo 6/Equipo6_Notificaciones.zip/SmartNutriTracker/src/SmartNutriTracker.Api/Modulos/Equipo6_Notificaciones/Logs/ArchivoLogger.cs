// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using System.Collections.Concurrent;
using System.Text;

namespace SmartNutriTracker.Api.Common;

/// <summary>
/// HU-29 – Logger global a archivo (un archivo por día en la carpeta "logs").
/// Implementación propia para no depender de paquetes externos.
/// </summary>
public sealed class ArchivoLoggerProvider : ILoggerProvider
{
    private readonly string _carpeta;
    private readonly ConcurrentDictionary<string, ArchivoLogger> _loggers = new();
    private readonly BlockingCollection<string> _cola = new(10_000);
    private readonly Task _escritor;

    public ArchivoLoggerProvider(string carpeta)
    {
        _carpeta = carpeta;
        Directory.CreateDirectory(_carpeta);
        _escritor = Task.Factory.StartNew(Escribir, TaskCreationOptions.LongRunning);
    }

    public ILogger CreateLogger(string categoryName) => _loggers.GetOrAdd(categoryName, c => new ArchivoLogger(c, this));

    internal void Encolar(string linea)
    {
        if (!_cola.IsAddingCompleted) _cola.TryAdd(linea);
    }

    private void Escribir()
    {
        foreach (var linea in _cola.GetConsumingEnumerable())
        {
            try
            {
                var archivo = Path.Combine(_carpeta, $"smartnutri-{DateTime.Now:yyyy-MM-dd}.log");
                File.AppendAllText(archivo, linea + Environment.NewLine, Encoding.UTF8);
            }
            catch (IOException)
            {
                // Si el archivo está bloqueado se descarta la línea; el log de consola sigue activo.
            }
        }
    }

    public void Dispose()
    {
        _cola.CompleteAdding();
        _escritor.Wait(TimeSpan.FromSeconds(2));
    }

    private sealed class ArchivoLogger(string categoria, ArchivoLoggerProvider provider) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

        public bool IsEnabled(LogLevel logLevel) =>
            logLevel >= LogLevel.Information &&
            !(categoria.StartsWith("Microsoft", StringComparison.Ordinal) && logLevel < LogLevel.Warning);

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel)) return;
            var sb = new StringBuilder()
                .Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")).Append(" [")
                .Append(logLevel.ToString().ToUpperInvariant()).Append("] ")
                .Append(categoria).Append(": ")
                .Append(formatter(state, exception));
            if (exception is not null) sb.AppendLine().Append(exception);
            provider.Encolar(sb.ToString());
        }
    }
}
