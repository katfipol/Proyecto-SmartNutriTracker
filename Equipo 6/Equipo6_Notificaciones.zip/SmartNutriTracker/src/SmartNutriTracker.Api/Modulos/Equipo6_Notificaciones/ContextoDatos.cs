// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 6 – Notificaciones y Testing dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<TipoAlerta> TiposAlerta => Set<TipoAlerta>();
    public DbSet<Alerta> Alertas => Set<Alerta>();
    public DbSet<Notificacion> Notificaciones => Set<Notificacion>();
    public DbSet<Cita> Citas => Set<Cita>();

    partial void ConfigurarEquipo6(ModelBuilder mb)
    {
        mb.Entity<TipoAlerta>().ToTable("TiposAlerta");
        mb.Entity<Alerta>(e =>
        {
            e.ToTable("Alertas");
            e.HasOne(x => x.AtendidaPor).WithMany().HasForeignKey(x => x.AtendidaPorId).OnDelete(DeleteBehavior.Restrict);
        });
        mb.Entity<Notificacion>().ToTable("Notificaciones");
        mb.Entity<Cita>(e =>
        {
            e.ToTable("Citas");
            e.HasOne(x => x.Nutricionista).WithMany().HasForeignKey(x => x.NutricionistaId).OnDelete(DeleteBehavior.Restrict);
        });
    }
}
