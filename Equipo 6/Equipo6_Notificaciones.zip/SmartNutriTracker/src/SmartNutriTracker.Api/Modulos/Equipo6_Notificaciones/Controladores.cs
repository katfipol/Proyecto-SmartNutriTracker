// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 6 – HU-27: alertas de hábitos no saludables.</summary>
[ApiController]
[Route("api/alertas")]
[Authorize]
[Produces("application/json")]
public class AlertasController(IAlertasService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<AlertaDto>>> Listar([FromQuery] bool? atendida, [FromQuery] int? estudianteId, CancellationToken ct) =>
        Ok(await servicio.ListarAsync(atendida, estudianteId, ct));

    [HttpPatch("{id:int}/atender")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<AlertaDto>> Atender(int id, CancellationToken ct) => Ok(await servicio.AtenderAsync(id, ct));

    /// <summary>Evalúa las reglas para todos los estudiantes en una fecha (por defecto ayer, día cerrado).</summary>
    [HttpPost("evaluar")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<MensajeDto>> Evaluar([FromQuery] DateOnly? fecha, CancellationToken ct)
    {
        var dia = fecha ?? DateOnly.FromDateTime(DateTime.Today).AddDays(-1);
        var n = await servicio.EvaluarTodosAsync(dia, dia < DateOnly.FromDateTime(DateTime.Today), ct);
        return Ok(new MensajeDto($"Evaluación del {dia:dd/MM/yyyy} completada: {n} alerta(s) nueva(s)."));
    }
}

/// <summary>EQUIPO 6 – HU-28: notificaciones internas del usuario.</summary>
[ApiController]
[Route("api/notificaciones")]
[Authorize]
[Produces("application/json")]
public class NotificacionesController(INotificacionesService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<NotificacionDto>>> Listar([FromQuery] bool soloNoLeidas = false, CancellationToken ct = default) =>
        Ok(await servicio.ListarAsync(soloNoLeidas, ct));

    [HttpGet("contador")]
    public async Task<ActionResult<ContadorDto>> Contador(CancellationToken ct) => Ok(await servicio.ContadorAsync(ct));

    [HttpPatch("{id:int}/leer")]
    public async Task<IActionResult> Leer(int id, CancellationToken ct)
    {
        await servicio.MarcarLeidaAsync(id, ct);
        return NoContent();
    }

    [HttpPatch("leer-todas")]
    public async Task<IActionResult> LeerTodas(CancellationToken ct)
    {
        await servicio.MarcarTodasAsync(ct);
        return NoContent();
    }
}

/// <summary>Alcance – citas nutricionales.</summary>
[ApiController]
[Route("api/citas")]
[Authorize]
[Produces("application/json")]
public class CitasController(ICitasService servicio) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<CitaDto>>> Listar([FromQuery] DateOnly? desde, [FromQuery] DateOnly? hasta,
        [FromQuery] int? estudianteId, CancellationToken ct) =>
        Ok(await servicio.ListarAsync(desde, hasta, estudianteId, ct));

    [HttpPost]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<CitaDto>> Crear([FromBody] CitaRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.CrearAsync(request, ct));

    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<CitaDto>> Actualizar(int id, [FromBody] CitaRequest request, CancellationToken ct) =>
        Ok(await servicio.ActualizarAsync(id, request, ct));

    [HttpPatch("{id:int}/estado")]
    [Authorize(Roles = Roles.Personal)]
    public async Task<ActionResult<CitaDto>> CambiarEstado(int id, [FromBody] EstadoCitaRequest request, CancellationToken ct) =>
        Ok(await servicio.CambiarEstadoAsync(id, request, ct));
}
