// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Domain;

/// <summary>Tipo de alerta configurable (tabla TiposAlerta).</summary>
public sealed record TipoAlertaModelo(int Id, string Codigo, string Nombre, decimal Umbral, string Unidad, string Nivel);

/// <summary>Lo que el estudiante registró en un día.</summary>
public sealed record ResumenDia(
    DateOnly Fecha,
    bool TieneConsumo,
    decimal Calorias,
    decimal Azucares,
    decimal SodioMg,
    bool TieneHabitos,
    decimal HorasSueno,
    int AguaMl,
    int MinutosActividad);

public sealed record AlertaDetectada(int TipoAlertaId, string Codigo, decimal Valor, string Mensaje);

/// <summary>
/// HU-27 – Reglas de alertas de hábitos no saludables (lógica pura).
/// Con diaCerrado = true (el día ya terminó) también se evalúa el déficit calórico.
/// </summary>
public static class ReglasAlertas
{
    public static IReadOnlyList<AlertaDetectada> Evaluar(
        ResumenDia dia, decimal caloriasObjetivo, IReadOnlyList<TipoAlertaModelo> tipos, bool diaCerrado)
    {
        var resultado = new List<AlertaDetectada>();
        TipoAlertaModelo? Tipo(string codigo) => tipos.FirstOrDefault(t => t.Codigo == codigo);

        if (dia.TieneConsumo && caloriasObjetivo > 0)
        {
            var pct = Math.Round(dia.Calorias / caloriasObjetivo * 100m, 1);

            if (Tipo("CALORIAS_EXCESO") is { } exceso && pct > exceso.Umbral)
                resultado.Add(new(exceso.Id, exceso.Codigo, pct,
                    $"Consumió {dia.Calorias:0} kcal ({pct}% de su objetivo de {caloriasObjetivo:0} kcal)."));

            if (diaCerrado && Tipo("CALORIAS_DEFICIT") is { } deficit && pct < deficit.Umbral)
                resultado.Add(new(deficit.Id, deficit.Codigo, pct,
                    $"Consumió solo {dia.Calorias:0} kcal ({pct}% de su objetivo de {caloriasObjetivo:0} kcal)."));

            if (Tipo("AZUCAR_EXCESO") is { } azucar && dia.Azucares > azucar.Umbral)
                resultado.Add(new(azucar.Id, azucar.Codigo, dia.Azucares,
                    $"Consumió {dia.Azucares:0.#} g de azúcar (límite {azucar.Umbral:0} g)."));

            if (Tipo("SODIO_EXCESO") is { } sodio && dia.SodioMg > sodio.Umbral)
                resultado.Add(new(sodio.Id, sodio.Codigo, dia.SodioMg,
                    $"Consumió {dia.SodioMg:0} mg de sodio (límite {sodio.Umbral:0} mg)."));
        }

        if (dia.TieneHabitos)
        {
            if (Tipo("AGUA_BAJA") is { } agua && dia.AguaMl < agua.Umbral)
                resultado.Add(new(agua.Id, agua.Codigo, dia.AguaMl,
                    $"Tomó {dia.AguaMl} ml de agua (mínimo {agua.Umbral:0} ml)."));

            if (Tipo("SUENO_BAJO") is { } sueno && dia.HorasSueno < sueno.Umbral)
                resultado.Add(new(sueno.Id, sueno.Codigo, dia.HorasSueno,
                    $"Durmió {dia.HorasSueno:0.#} h (mínimo {sueno.Umbral:0.#} h)."));

            if (Tipo("ACTIVIDAD_BAJA") is { } act && dia.MinutosActividad < act.Umbral)
                resultado.Add(new(act.Id, act.Codigo, dia.MinutosActividad,
                    $"Realizó {dia.MinutosActividad} min de actividad física (mínimo {act.Umbral:0} min)."));
        }

        return resultado;
    }

    /// <summary>Alerta de IMC en zona de riesgo (Bajo peso u Obesidad).</summary>
    public static AlertaDetectada? EvaluarImc(decimal imc, string categoriaImc, IReadOnlyList<TipoAlertaModelo> tipos)
    {
        var tipo = tipos.FirstOrDefault(t => t.Codigo == "IMC_RIESGO");
        if (tipo is null) return null;
        var enRiesgo = categoriaImc.Equals("Bajo peso", StringComparison.OrdinalIgnoreCase)
                    || categoriaImc.Equals("Obesidad", StringComparison.OrdinalIgnoreCase);
        return enRiesgo ? new AlertaDetectada(tipo.Id, tipo.Codigo, imc, $"IMC {imc} en categoría '{categoriaImc}'.") : null;
    }
}
