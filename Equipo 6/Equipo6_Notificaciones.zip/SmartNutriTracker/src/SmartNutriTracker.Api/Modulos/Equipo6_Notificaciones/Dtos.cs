// EQUIPO 6 – Notificaciones y Testing
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

public sealed record TipoAlertaDto(int Id, string Codigo, string Nombre, string? Descripcion, decimal Umbral, string Unidad, string Nivel, bool Activo);

public sealed class TipoAlertaRequest
{
    [Required, Range(0, 100000)] public decimal Umbral { get; set; }
    [Required, RegularExpression("^(Baja|Media|Alta)$")] public string Nivel { get; set; } = "Media";
    public bool Activo { get; set; } = true;
}

public sealed record AlertaDto(int Id, int EstudianteId, string Estudiante, string Curso, string Tipo, string Codigo, string Nivel,
    DateOnly Fecha, decimal ValorRegistrado, string Mensaje, bool Atendida, string? AtendidaPor, DateTime? FechaAtencion);

public sealed record NotificacionDto(int Id, string Titulo, string Mensaje, string Tipo, bool Leida, DateTime FechaCreacion);

public sealed record ContadorDto(int NoLeidas);

public sealed record CitaDto(int Id, int EstudianteId, string Estudiante, int NutricionistaId, string Nutricionista,
    DateTime FechaHora, int DuracionMinutos, string Motivo, string Estado, string? Notas);

public sealed class CitaRequest
{
    [Required, Range(1, int.MaxValue)] public int EstudianteId { get; set; }
    [Required, Range(1, int.MaxValue)] public int NutricionistaId { get; set; }
    [Required] public DateTime FechaHora { get; set; }
    [Range(10, 240)] public int DuracionMinutos { get; set; } = 30;
    [Required, MaxLength(200)] public string Motivo { get; set; } = string.Empty;
}

public sealed class EstadoCitaRequest
{
    /// <summary>Programada | Completada | Cancelada</summary>
    [Required, RegularExpression("^(Programada|Completada|Cancelada)$")] public string Estado { get; set; } = string.Empty;
    [MaxLength(500)] public string? Notas { get; set; }
}
