using SmartNutriTracker.Api.Domain;
using static SmartNutriTracker.Tests.DatosPrueba;

namespace SmartNutriTracker.Tests;

/// <summary>HU-27 – Alertas de hábitos no saludables.</summary>
public class ReglasAlertasTests
{
    private static ResumenDia Dia(decimal kcal = 1800, decimal azucar = 20, decimal sodio = 1500, bool habitos = true,
        decimal sueno = 8, int agua = 2000, int actividad = 45) =>
        new(new DateOnly(2026, 11, 5), kcal > 0, kcal, azucar, sodio, habitos, sueno, agua, actividad);

    [Fact]
    public void DiaSaludable_SinAlertas() =>
        Assert.Empty(ReglasAlertas.Evaluar(Dia(), 1800, TiposAlerta, diaCerrado: true));

    [Fact]
    public void ExcesoDeCalorias_GeneraAlerta()
    {
        var r = ReglasAlertas.Evaluar(Dia(kcal: 2500), 1800, TiposAlerta, diaCerrado: false);
        Assert.Contains(r, a => a.Codigo == "CALORIAS_EXCESO" && a.Valor > 130);
    }

    [Fact]
    public void Deficit_SoloSiElDiaEstaCerrado()
    {
        Assert.DoesNotContain(ReglasAlertas.Evaluar(Dia(kcal: 600), 1800, TiposAlerta, diaCerrado: false), a => a.Codigo == "CALORIAS_DEFICIT");
        Assert.Contains(ReglasAlertas.Evaluar(Dia(kcal: 600), 1800, TiposAlerta, diaCerrado: true), a => a.Codigo == "CALORIAS_DEFICIT");
    }

    [Fact]
    public void AzucarYSodio_Altos_GeneranAlertas()
    {
        var r = ReglasAlertas.Evaluar(Dia(azucar: 75, sodio: 3000), 1800, TiposAlerta, diaCerrado: false);
        Assert.Contains(r, a => a.Codigo == "AZUCAR_EXCESO");
        Assert.Contains(r, a => a.Codigo == "SODIO_EXCESO");
    }

    [Fact]
    public void HabitosBajos_GeneranTresAlertas()
    {
        var r = ReglasAlertas.Evaluar(Dia(sueno: 5, agua: 800, actividad: 5), 1800, TiposAlerta, diaCerrado: false);
        Assert.Equal(["AGUA_BAJA", "SUENO_BAJO", "ACTIVIDAD_BAJA"], r.Select(a => a.Codigo).ToArray());
    }

    [Fact]
    public void SinHabitosRegistrados_NoEvaluaHabitos() =>
        Assert.Empty(ReglasAlertas.Evaluar(Dia(habitos: false, sueno: 0, agua: 0, actividad: 0), 1800, TiposAlerta, diaCerrado: false));

    [Fact]
    public void TipoInactivo_NoSeEvalua()
    {
        var sinAgua = TiposAlerta.Where(t => t.Codigo != "AGUA_BAJA").ToList();
        Assert.DoesNotContain(ReglasAlertas.Evaluar(Dia(agua: 500), 1800, sinAgua, false), a => a.Codigo == "AGUA_BAJA");
    }

    [Theory]
    [InlineData("Bajo peso", true)]
    [InlineData("Normal", false)]
    [InlineData("Sobrepeso", false)]
    [InlineData("Obesidad", true)]
    public void ImcRiesgo(string categoria, bool esperaAlerta) =>
        Assert.Equal(esperaAlerta, ReglasAlertas.EvaluarImc(20, categoria, TiposAlerta) is not null);
}
