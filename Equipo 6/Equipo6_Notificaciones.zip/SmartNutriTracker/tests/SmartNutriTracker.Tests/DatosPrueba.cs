using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Tests;

/// <summary>Mismos valores que los datos semilla de database/SmartNutriTracker_BD.sql.</summary>
internal static class DatosPrueba
{
    public static readonly IReadOnlyList<ObjetivoModelo> Objetivos =
    [
        new(1, "BAJAR", "Bajar de peso", -15, 25, 45, 30),
        new(2, "MANTENER", "Mantener peso", 0, 20, 50, 30),
        new(3, "GANAR", "Ganar peso", 10, 20, 55, 25)
    ];

    public static readonly IReadOnlyList<ReglaImcModelo> Reglas =
    [
        new(1, "Bajo peso", 0, 18.5m, "GANAR", ["GANAR", "MANTENER"], "IMC bajo."),
        new(2, "Normal", 18.5m, 25m, "MANTENER", ["BAJAR", "MANTENER", "GANAR"], "IMC normal."),
        new(3, "Sobrepeso", 25m, 30m, "BAJAR", ["BAJAR", "MANTENER"], "IMC elevado."),
        new(4, "Obesidad", 30m, 99.99m, "BAJAR", ["BAJAR"], "IMC muy elevado.")
    ];

    public static readonly IReadOnlyList<ComidaPlantilla> Plantilla =
    [
        new(1, "Desayuno", 1, 25, ["LACTEO", "CEREAL", "FRUTA"]),
        new(2, "Merienda mañana", 2, 10, ["FRUTA", "GRASA_SALUDABLE"]),
        new(3, "Almuerzo", 3, 35, ["PROTEINA", "CEREAL", "VERDURA", "FRUTA"]),
        new(4, "Merienda tarde", 4, 10, ["LACTEO", "FRUTA"]),
        new(5, "Cena", 5, 20, ["PROTEINA", "VERDURA", "CEREAL"])
    ];

    public static readonly IReadOnlyList<AlimentoCandidato> Alimentos =
    [
        new(1, "Leche semidescremada", "LACTEO", "1 taza", 120, 8, 12, 4.5m),
        new(2, "Yogur natural", "LACTEO", "1 vaso", 122, 7, 14, 4),
        new(3, "Queso fresco", "LACTEO", "2 rebanadas", 132, 9, 1.5m, 10),
        new(6, "Pan integral", "CEREAL", "2 rebanadas", 150, 6, 26, 2),
        new(7, "Avena cocida", "CEREAL", "1 taza", 160, 6, 27, 3),
        new(8, "Arroz blanco cocido", "CEREAL", "1 taza", 205, 4.3m, 45, 0.4m),
        new(9, "Quinua cocida", "CEREAL", "1 taza", 222, 8, 39, 3.5m),
        new(13, "Manzana", "FRUTA", "1 unidad", 95, 0.5m, 25, 0.3m),
        new(14, "Plátano", "FRUTA", "1 unidad", 105, 1.3m, 27, 0.4m),
        new(15, "Naranja", "FRUTA", "1 unidad", 62, 1.2m, 15, 0.2m),
        new(16, "Papaya", "FRUTA", "1 taza", 62, 0.7m, 16, 0.4m),
        new(19, "Ensalada mixta", "VERDURA", "1 plato", 30, 1.5m, 6, 0.3m),
        new(20, "Brócoli al vapor", "VERDURA", "1 taza", 52, 4.2m, 10, 0.6m),
        new(24, "Pechuga de pollo", "PROTEINA", "1 filete", 198, 37, 0, 4.3m),
        new(25, "Huevo duro", "PROTEINA", "2 unidades", 155, 13, 1.1m, 10.6m),
        new(27, "Trucha al horno", "PROTEINA", "1 filete", 170, 25, 0, 7.5m),
        new(30, "Maní tostado", "GRASA_SALUDABLE", "1 puñado", 170, 7, 6, 14),
        new(31, "Almendras", "GRASA_SALUDABLE", "1 puñado", 164, 6, 6, 14)
    ];

    public static readonly IReadOnlyList<TipoAlertaModelo> TiposAlerta =
    [
        new(1, "CALORIAS_EXCESO", "Exceso de calorías", 130, "%", "Media"),
        new(2, "CALORIAS_DEFICIT", "Déficit de calorías", 50, "%", "Media"),
        new(3, "AZUCAR_EXCESO", "Exceso de azúcar", 50, "g", "Alta"),
        new(4, "SODIO_EXCESO", "Exceso de sodio", 2300, "mg", "Media"),
        new(5, "AGUA_BAJA", "Agua baja", 1500, "ml", "Baja"),
        new(6, "SUENO_BAJO", "Sueño bajo", 7, "h", "Media"),
        new(7, "ACTIVIDAD_BAJA", "Actividad baja", 30, "min", "Baja"),
        new(8, "IMC_RIESGO", "IMC en riesgo", 0, "IMC", "Alta")
    ];

    public static readonly RecomendacionOptions Opciones = new();

    public static PerfilFisico Luis => new(65, 172, 17, 'M', 1.725m);   // IMC normal, activo
    public static PerfilFisico Ana => new(45, 165, 16, 'F', 1.375m);    // bajo peso
    public static PerfilFisico Carla => new(70, 160, 15, 'F', 1.2m);    // sobrepeso, sedentaria
    public static PerfilFisico Diego => new(95, 170, 15, 'M', 1.55m);   // obesidad
}
