using SmartNutriTracker.Api.Domain;
using static SmartNutriTracker.Tests.DatosPrueba;

namespace SmartNutriTracker.Tests;

/// <summary>HU-23 – Motor de recomendación de menú.</summary>
public class GeneradorMenuTests
{
    private static ResultadoCalculo CalculoNormal() => CalculadoraNutricional.Calcular(Luis, "MANTENER", Reglas, Objetivos, 1400);

    [Fact]
    public void Generar_IncluyeTodasLasComidas()
    {
        var menu = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 123, Opciones);
        Assert.Equal(Plantilla.Select(p => p.TipoComida), menu.Items.Select(i => i.TipoComida).Distinct());
    }

    [Fact]
    public void Generar_NoRepiteAlimentosEnElDia()
    {
        var ids = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 7, Opciones).Items.Select(i => i.Alimento.Id).ToList();
        Assert.Equal(ids.Count, ids.Distinct().Count());
    }

    [Fact]
    public void Generar_MismaSemilla_MismoMenu()
    {
        var a = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 42, Opciones);
        var b = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 42, Opciones);
        Assert.Equal(a.Items.Select(i => (i.Alimento.Id, i.Porciones)), b.Items.Select(i => (i.Alimento.Id, i.Porciones)));
    }

    [Theory]
    [InlineData(1)]
    [InlineData(99)]
    [InlineData(2026)]
    public void Generar_CaloriasCercanasAlObjetivo(int semilla) =>
        Assert.InRange(GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), semilla, Opciones).PorcentajeCumplimiento, 75m, 125m);

    [Fact]
    public void Generar_PorcionesEnPasosDeMedio()
    {
        var menu = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 5, Opciones);
        Assert.All(menu.Items, i =>
        {
            Assert.InRange(i.Porciones, Opciones.PorcionMinima, Opciones.PorcionMaxima);
            Assert.Equal(0m, i.Porciones * 2 % 1);
        });
    }

    [Fact]
    public void Generar_EvitaAlimentosRecientes()
    {
        var menu = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int> { 1, 2 }, 11, Opciones);
        Assert.Equal(3, menu.Items.First(i => i.TipoComida == "Desayuno" && i.Alimento.Categoria == "LACTEO").Alimento.Id);
    }

    [Fact]
    public void Generar_SinCategoria_AgregaObservacion()
    {
        var sinGrasas = Alimentos.Where(a => a.Categoria != "GRASA_SALUDABLE").ToList();
        var menu = GeneradorMenu.Generar(CalculoNormal(), Plantilla, sinGrasas, new HashSet<int>(), 3, Opciones);
        Assert.Contains(menu.Observaciones, o => o.Contains("GRASA_SALUDABLE"));
    }

    [Fact]
    public void Generar_DistribucionQueNoSuma100_LanzaExcepcion() =>
        Assert.Throws<InvalidOperationException>(() =>
            GeneradorMenu.Generar(CalculoNormal(), [new(3, "Almuerzo", 1, 60, ["PROTEINA"])], Alimentos, new HashSet<int>(), 1, Opciones));

    [Fact]
    public void Generar_TotalesCoinciden()
    {
        var menu = GeneradorMenu.Generar(CalculoNormal(), Plantilla, Alimentos, new HashSet<int>(), 8, Opciones);
        Assert.Equal(menu.Items.Sum(i => i.Calorias), menu.Totales.Calorias);
    }

    [Theory]
    [InlineData(0.1, 0.5)]
    [InlineData(1.24, 1.0)]
    [InlineData(1.26, 1.5)]
    [InlineData(5.0, 3.0)]
    public void RedondearPorcion(decimal factor, decimal esperado) =>
        Assert.Equal(esperado, GeneradorMenu.RedondearPorcion(factor, 0.5m, 3m));
}
