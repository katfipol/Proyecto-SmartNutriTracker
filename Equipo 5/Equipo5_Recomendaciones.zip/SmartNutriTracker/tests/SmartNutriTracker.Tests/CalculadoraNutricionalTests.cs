using SmartNutriTracker.Api.Domain;
using static SmartNutriTracker.Tests.DatosPrueba;

namespace SmartNutriTracker.Tests;

/// <summary>HU-24 / HU-25 / HU-26.</summary>
public class CalculadoraNutricionalTests
{
    [Theory]
    [InlineData(45, 165, 16.53)]
    [InlineData(65, 172, 21.97)]
    [InlineData(70, 160, 27.34)]
    [InlineData(95, 170, 32.87)]
    public void CalcularImc_DevuelveValorCorrecto(decimal peso, decimal altura, decimal esperado) =>
        Assert.Equal(esperado, CalculadoraNutricional.CalcularImc(peso, altura));

    [Fact]
    public void CalcularImc_PesoCero_LanzaExcepcion() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => CalculadoraNutricional.CalcularImc(0, 170));

    [Fact]
    public void CalcularTmb_Hombre_MifflinStJeor() =>
        Assert.Equal(1645m, CalculadoraNutricional.CalcularTmb(Luis));          // 650 + 1075 - 85 + 5

    [Fact]
    public void CalcularTmb_Mujer_MifflinStJeor() =>
        Assert.Equal(1240.25m, CalculadoraNutricional.CalcularTmb(Ana));        // 450 + 1031.25 - 80 - 161

    [Fact]
    public void Perfil_FactorFueraDeRango_LanzaExcepcion() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => CalculadoraNutricional.CalcularTmb(new PerfilFisico(60, 160, 15, 'F', 3m)));

    [Theory]
    [InlineData(16.53, "Bajo peso")]
    [InlineData(18.5, "Normal")]
    [InlineData(24.99, "Normal")]
    [InlineData(25, "Sobrepeso")]
    [InlineData(32.87, "Obesidad")]
    public void ClasificarImc_UbicaCategoria(decimal imc, string categoria) =>
        Assert.Equal(categoria, CalculadoraNutricional.ClasificarImc(imc, Reglas).Categoria);

    [Fact]
    public void Calcular_Normal_Mantener_CaloriasIgualAlGasto()
    {
        var r = CalculadoraNutricional.Calcular(Luis, "MANTENER", Reglas, Objetivos, 1400);
        Assert.Equal("Normal", r.CategoriaImc);
        Assert.Equal(2, r.CategoriaImcId);
        Assert.Equal("MANTENER", r.ObjetivoAplicado);
        Assert.Equal(Math.Round(1645m * 1.725m, 2), r.GastoEnergeticoTotal);
        Assert.Equal(Math.Round(r.GastoEnergeticoTotal, 0), r.CaloriasObjetivo);
        Assert.Equal(Math.Round(r.CaloriasObjetivo * 0.20m / 4, 1), r.ProteinasG);
    }

    [Fact]
    public void Calcular_BajoPeso_QuiereBajar_SeAplicaGanar()
    {
        var r = CalculadoraNutricional.Calcular(Ana, "BAJAR", Reglas, Objetivos, 1400);
        Assert.Equal("Bajo peso", r.CategoriaImc);
        Assert.Equal("BAJAR", r.ObjetivoSolicitado);
        Assert.Equal("GANAR", r.ObjetivoAplicado);
        Assert.Contains(r.Observaciones, o => o.Contains("no es adecuado"));
    }

    [Fact]
    public void Calcular_Obesidad_QuiereGanar_SeAplicaBajar()
    {
        var r = CalculadoraNutricional.Calcular(Diego, "GANAR", Reglas, Objetivos, 1400);
        Assert.Equal("BAJAR", r.ObjetivoAplicado);
        Assert.True(r.CaloriasObjetivo < r.GastoEnergeticoTotal);
    }

    [Fact]
    public void Calcular_SinObjetivo_UsaElSugerido()
    {
        var r = CalculadoraNutricional.Calcular(Carla, null, Reglas, Objetivos, 1400);
        Assert.Equal("Sobrepeso", r.CategoriaImc);
        Assert.Equal("BAJAR", r.ObjetivoAplicado);
    }

    [Fact]
    public void Calcular_RespetaCaloriasMinimas()
    {
        var r = CalculadoraNutricional.Calcular(Carla, "BAJAR", Reglas, Objetivos, 1600);
        Assert.Equal(1600m, r.CaloriasObjetivo);
        Assert.Contains(r.Observaciones, o => o.Contains("mínimo seguro"));
    }

    [Fact]
    public void Calcular_MacrosSumanLasCalorias()
    {
        var r = CalculadoraNutricional.Calcular(Luis, "GANAR", Reglas, Objetivos, 1400);
        var kcal = r.ProteinasG * 4 + r.CarbohidratosG * 4 + r.GrasasG * 9;
        Assert.InRange(kcal, r.CaloriasObjetivo - 5, r.CaloriasObjetivo + 5);
    }

    [Theory]
    [InlineData("2010-05-10", "2026-11-06", 16)]
    [InlineData("2010-11-30", "2026-11-06", 15)]
    [InlineData("2010-11-06", "2026-11-06", 16)]
    public void CalcularEdad_EsCorrecta(string nacimiento, string fecha, int esperada) =>
        Assert.Equal(esperada, CalculadoraNutricional.CalcularEdad(DateOnly.Parse(nacimiento), DateOnly.Parse(fecha)));
}
