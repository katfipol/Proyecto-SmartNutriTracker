// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IRecomendacionesService
{
    Task<RecomendacionDto> GenerarAsync(GenerarRecomendacionRequest request, CancellationToken ct = default);
    Task<RecomendacionDto> ObtenerAsync(int id, CancellationToken ct = default);
    Task<RecomendacionDto?> UltimaAsync(int estudianteId, CancellationToken ct = default);
    Task<IReadOnlyList<RecomendacionResumenDto>> HistorialAsync(int estudianteId, CancellationToken ct = default);
    Task<RecomendacionDto> CambiarEstadoAsync(int id, CambiarEstadoRequest request, CancellationToken ct = default);
    Task EliminarAsync(int id, CancellationToken ct = default);
}

public class RecomendacionesService(
    SmartNutriDbContext db,
    IAccesoService acceso,
    IUsuarioActual usuario,
    INutricionService nutricion,
    IOptions<RecomendacionOptions> opciones,
    INotificacionesService notificaciones,
    IAuditoriaService auditoria) : IRecomendacionesService
{
    private readonly RecomendacionOptions _op = opciones.Value;

    public async Task<RecomendacionDto> GenerarAsync(GenerarRecomendacionRequest request, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(request.EstudianteId, ct);
        var e = await nutricion.CargarEstudianteAsync(request.EstudianteId, ct);
        if (!e.Activo) throw new ReglaNegocioException("El estudiante está inactivo.");

        var fecha = request.Fecha ?? DateOnly.FromDateTime(DateTime.Today);
        var calculo = await nutricion.CalcularEstudianteAsync(e, fecha, request.Objetivo, ct);

        var excluidos = await db.AlimentosExcluidos.AsNoTracking().Where(x => x.EstudianteId == e.Id).Select(x => x.AlimentoId).ToListAsync(ct);
        var alimentos = await db.Alimentos.AsNoTracking().Include(a => a.CategoriaAlimento)
            .Where(a => a.Activo && !excluidos.Contains(a.Id)).ToListAsync(ct);

        var ultimas = await db.Recomendaciones.AsNoTracking().Where(r => r.EstudianteId == e.Id)
            .OrderByDescending(r => r.Fecha).ThenByDescending(r => r.Id)
            .Take(_op.RecomendacionesRecientesParaVariedad).Select(r => r.Id).ToListAsync(ct);
        var recientes = (await db.RecomendacionDetalles.AsNoTracking().Where(d => ultimas.Contains(d.RecomendacionId))
            .Select(d => d.AlimentoId).Distinct().ToListAsync(ct)).ToHashSet();

        var semilla = request.Semilla ?? Random.Shared.Next(1, int.MaxValue);
        var menu = GeneradorMenu.Generar(calculo, await nutricion.PlantillaAsync(ct), alimentos.Select(Mapeos.AModelo).ToList(),
            recientes, semilla, _op);
        if (menu.Items.Count == 0) throw new InvalidOperationException("No fue posible armar un menú con los alimentos disponibles.");

        var objetivos = await nutricion.ObjetivosAsync(ct);
        int IdObjetivo(string codigo) => objetivos.First(o => o.Codigo == codigo).Id;

        var r = new Recomendacion
        {
            EstudianteId = e.Id,
            Fecha = fecha,
            PesoKg = e.PesoKg,
            AlturaCm = e.AlturaCm,
            Edad = CalculadoraNutricional.CalcularEdad(e.FechaNacimiento, fecha),
            FactorActividad = calculo.FactorActividad,
            CategoriaImcId = calculo.CategoriaImcId,
            ObjetivoSolicitadoId = IdObjetivo(calculo.ObjetivoSolicitado),
            ObjetivoAplicadoId = IdObjetivo(calculo.ObjetivoAplicado),
            CaloriasObjetivo = calculo.CaloriasObjetivo,
            ProteinasObjetivoG = calculo.ProteinasG,
            CarbohidratosObjetivoG = calculo.CarbohidratosG,
            GrasasObjetivoG = calculo.GrasasG,
            Estado = "Generada",
            Semilla = semilla,
            CreadoPorId = usuario.Id,
            FechaCreacion = DateTime.UtcNow,
            Detalles = menu.Items.Select(i => new RecomendacionDetalle { TipoComidaId = i.TipoComidaId, AlimentoId = i.Alimento.Id, Porciones = i.Porciones }).ToList(),
            Observaciones = calculo.Observaciones.Concat(menu.Observaciones)
                .Select((t, idx) => new RecomendacionObservacion { Orden = idx + 1, Texto = t.Length > 400 ? t[..400] : t }).ToList()
        };
        db.Recomendaciones.Add(r);
        await db.SaveChangesAsync(ct);

        await auditoria.RegistrarAsync("GENERAR", "Recomendacion", r.Id,
            $"Estudiante {e.Id}: IMC {calculo.Imc} {calculo.CategoriaImc}, {calculo.ObjetivoAplicado}, {calculo.CaloriasObjetivo} kcal", ct: ct);
        if (e.UsuarioId.HasValue && e.UsuarioId != usuario.Id)
            await notificaciones.CrearAsync([e.UsuarioId.Value], "Nueva recomendación de menú",
                $"Tienes un menú recomendado para el {fecha:dd/MM/yyyy} ({calculo.CaloriasObjetivo:0} kcal).", "Sistema", ct);

        return await ObtenerAsync(r.Id, ct);
    }

    public async Task<RecomendacionDto> ObtenerAsync(int id, CancellationToken ct = default)
    {
        var r = await Consulta().FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Recomendación {id} no encontrada.");
        await acceso.VerificarEstudianteAsync(r.EstudianteId, ct);
        return ADto(r);
    }

    public async Task<RecomendacionDto?> UltimaAsync(int estudianteId, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(estudianteId, ct);
        var r = await Consulta().Where(x => x.EstudianteId == estudianteId)
            .OrderByDescending(x => x.Fecha).ThenByDescending(x => x.Id).FirstOrDefaultAsync(ct);
        return r is null ? null : ADto(r);
    }

    public async Task<IReadOnlyList<RecomendacionResumenDto>> HistorialAsync(int estudianteId, CancellationToken ct = default)
    {
        await acceso.VerificarEstudianteAsync(estudianteId, ct);
        var lista = await db.Recomendaciones.AsNoTracking().Where(r => r.EstudianteId == estudianteId)
            .Include(r => r.CategoriaImc).Include(r => r.ObjetivoAplicado)
            .Include(r => r.Detalles).ThenInclude(d => d.Alimento)
            .OrderByDescending(r => r.Fecha).ThenByDescending(r => r.Id)
            .AsSplitQuery()
            .ToListAsync(ct);
        return lista.Select(r =>
        {
            var kcal = Math.Round(r.Detalles.Sum(d => d.Alimento!.Calorias * d.Porciones), 0);
            return new RecomendacionResumenDto(r.Id, r.Fecha, r.CategoriaImc!.Nombre, r.ObjetivoAplicado!.Nombre, r.CaloriasObjetivo, kcal,
                r.CaloriasObjetivo > 0 ? Math.Round(kcal / r.CaloriasObjetivo * 100, 1) : 0, r.Estado);
        }).ToList();
    }

    public async Task<RecomendacionDto> CambiarEstadoAsync(int id, CambiarEstadoRequest request, CancellationToken ct = default)
    {
        var estado = request.Estado.Trim();
        if (estado is not ("Aceptada" or "Rechazada")) throw new ReglaNegocioException("Estado no válido. Use 'Aceptada' o 'Rechazada'.");
        var r = await db.Recomendaciones.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Recomendación {id} no encontrada.");
        await acceso.VerificarEstudianteAsync(r.EstudianteId, ct);
        r.Estado = estado;
        r.ComentarioEstado = request.Comentario;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("CAMBIAR_ESTADO", "Recomendacion", id, estado, ct: ct);
        return await ObtenerAsync(id, ct);
    }

    public async Task EliminarAsync(int id, CancellationToken ct = default)
    {
        var r = await db.Recomendaciones.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Recomendación {id} no encontrada.");
        db.Recomendaciones.Remove(r);
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ELIMINAR", "Recomendacion", id, $"Estudiante {r.EstudianteId}", ct: ct);
    }

    private IQueryable<Recomendacion> Consulta() =>
        db.Recomendaciones.AsNoTracking()
            .Include(r => r.Estudiante)
            .Include(r => r.CategoriaImc)
            .Include(r => r.ObjetivoSolicitado)
            .Include(r => r.ObjetivoAplicado)
            .Include(r => r.Observaciones)
            .Include(r => r.Detalles).ThenInclude(d => d.TipoComida)
            .Include(r => r.Detalles).ThenInclude(d => d.Alimento).ThenInclude(a => a!.CategoriaAlimento)
            .AsSplitQuery();

    /// <summary>IMC, TMB, GET y totales se recalculan desde los datos guardados (no se almacenan: 3FN).</summary>
    private static RecomendacionDto ADto(Recomendacion r)
    {
        var sexo = string.IsNullOrEmpty(r.Estudiante?.Sexo) ? 'M' : r.Estudiante!.Sexo[0];
        var imc = CalculadoraNutricional.CalcularImc(r.PesoKg, r.AlturaCm);
        var tmb = CalculadoraNutricional.CalcularTmb(new PerfilFisico(r.PesoKg, r.AlturaCm, r.Edad, sexo, r.FactorActividad));
        var calculo = new CalculoNutricionalDto(imc, r.CategoriaImc!.Nombre, tmb, r.FactorActividad, Math.Round(tmb * r.FactorActividad, 2),
            r.ObjetivoSolicitado!.Codigo, r.ObjetivoAplicado!.Codigo, r.CaloriasObjetivo, r.ProteinasObjetivoG, r.CarbohidratosObjetivoG,
            r.GrasasObjetivoG, r.Observaciones.OrderBy(o => o.Orden).Select(o => o.Texto).ToList());

        var comidas = Mapeos.AgruparComidas(r.Detalles.OrderBy(d => d.Id).Select(d => (d.Id, d.TipoComida!, d.Alimento!, d.Porciones)));
        var totales = Mapeos.Totales(r.Detalles.Select(d => (d.Alimento!, d.Porciones)));
        var cumplimiento = r.CaloriasObjetivo > 0 ? Math.Round(totales.Calorias / r.CaloriasObjetivo * 100, 1) : 0;

        return new RecomendacionDto(r.Id, r.EstudianteId, r.Estudiante?.NombreCompleto ?? string.Empty, r.Fecha, r.PesoKg, r.AlturaCm, r.Edad,
            calculo, comidas, Mapeos.Resumen(totales), cumplimiento, r.Estado, r.ComentarioEstado, r.Semilla, r.FechaCreacion);
    }
}
