// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface IReglasService
{
    Task<IReadOnlyList<CategoriaImcDto>> CategoriasAsync(CancellationToken ct = default);
    Task<CategoriaImcDto> ActualizarCategoriaAsync(int id, CategoriaImcRequest request, CancellationToken ct = default);
    Task<IReadOnlyList<ObjetivoDto>> ObjetivosAsync(CancellationToken ct = default);
    Task<ObjetivoDto> ActualizarObjetivoAsync(int id, ObjetivoRequest request, CancellationToken ct = default);
}

public class ReglasService(SmartNutriDbContext db, IAuditoriaService auditoria) : IReglasService
{
    public async Task<IReadOnlyList<CategoriaImcDto>> CategoriasAsync(CancellationToken ct = default)
    {
        var lista = await db.CategoriasImc.AsNoTracking()
            .Include(c => c.ObjetivoSugerido)
            .Include(c => c.ObjetivosPermitidos).ThenInclude(p => p.Objetivo)
            .OrderBy(c => c.ImcMin).ToListAsync(ct);
        return lista.Select(c => new CategoriaImcDto(c.Id, c.Nombre, c.ImcMin, c.ImcMax, c.ObjetivoSugeridoId, c.ObjetivoSugerido!.Nombre,
            c.ObjetivosPermitidos.Select(p => p.ObjetivoId).ToList(), c.ObjetivosPermitidos.Select(p => p.Objetivo!.Nombre).ToList(),
            c.Mensaje, c.Activo)).ToList();
    }

    public async Task<CategoriaImcDto> ActualizarCategoriaAsync(int id, CategoriaImcRequest r, CancellationToken ct = default)
    {
        var c = await db.CategoriasImc.Include(x => x.ObjetivosPermitidos).FirstOrDefaultAsync(x => x.Id == id, ct)
                ?? throw new NoEncontradoException($"Categoría {id} no encontrada.");
        if (r.ImcMin >= r.ImcMax) throw new ReglaNegocioException("ImcMin debe ser menor que ImcMax.");
        var permitidos = r.ObjetivosPermitidosIds.Distinct().ToList();
        if (!permitidos.Contains(r.ObjetivoSugeridoId)) throw new ReglaNegocioException("El objetivo sugerido debe estar entre los permitidos.");
        if (await db.ObjetivosNutricionales.CountAsync(o => permitidos.Contains(o.Id), ct) != permitidos.Count)
            throw new ReglaNegocioException("Hay objetivos no válidos.");
        if (r.Activo && await db.CategoriasImc.AnyAsync(x => x.Id != id && x.Activo && r.ImcMin < x.ImcMax && x.ImcMin < r.ImcMax, ct))
            throw new ReglaNegocioException("El rango de IMC se cruza con otra categoría activa.");

        c.ImcMin = r.ImcMin;
        c.ImcMax = r.ImcMax;
        c.ObjetivoSugeridoId = r.ObjetivoSugeridoId;
        c.Mensaje = r.Mensaje.Trim();
        c.Activo = r.Activo;
        db.CategoriaImcObjetivos.RemoveRange(c.ObjetivosPermitidos);
        c.ObjetivosPermitidos = permitidos.Select(o => new CategoriaImcObjetivo { CategoriaImcId = id, ObjetivoId = o }).ToList();
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "CategoriaImc", id, $"{c.Nombre}: {r.ImcMin}-{r.ImcMax}", ct: ct);
        return (await CategoriasAsync(ct)).First(x => x.Id == id);
    }

    public async Task<IReadOnlyList<ObjetivoDto>> ObjetivosAsync(CancellationToken ct = default) =>
        await db.ObjetivosNutricionales.AsNoTracking().OrderBy(o => o.Id)
            .Select(o => new ObjetivoDto(o.Id, o.Codigo, o.Nombre, o.AjustePorcentaje, o.PctProteina, o.PctCarbohidratos, o.PctGrasas, o.Descripcion))
            .ToListAsync(ct);

    public async Task<ObjetivoDto> ActualizarObjetivoAsync(int id, ObjetivoRequest r, CancellationToken ct = default)
    {
        var o = await db.ObjetivosNutricionales.FirstOrDefaultAsync(x => x.Id == id, ct) ?? throw new NoEncontradoException($"Objetivo {id} no encontrado.");
        if (r.PctProteina + r.PctCarbohidratos + r.PctGrasas != 100m)
            throw new ReglaNegocioException("La suma de % de proteína, carbohidratos y grasas debe ser 100.");
        o.Nombre = r.Nombre.Trim();
        o.AjustePorcentaje = r.AjustePorcentaje;
        o.PctProteina = r.PctProteina;
        o.PctCarbohidratos = r.PctCarbohidratos;
        o.PctGrasas = r.PctGrasas;
        o.Descripcion = r.Descripcion;
        await db.SaveChangesAsync(ct);
        await auditoria.RegistrarAsync("ACTUALIZAR", "ObjetivoNutricional", id, $"{o.Codigo}: {r.AjustePorcentaje}% / {r.PctProteina}-{r.PctCarbohidratos}-{r.PctGrasas}", ct: ct);
        return new ObjetivoDto(o.Id, o.Codigo, o.Nombre, o.AjustePorcentaje, o.PctProteina, o.PctCarbohidratos, o.PctGrasas, o.Descripcion);
    }
}
