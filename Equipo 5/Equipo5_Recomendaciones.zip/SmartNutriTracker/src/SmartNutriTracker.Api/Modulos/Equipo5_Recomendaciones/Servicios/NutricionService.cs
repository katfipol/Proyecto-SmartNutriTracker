// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

public interface INutricionService
{
    Task<IReadOnlyList<ReglaImcModelo>> ReglasAsync(CancellationToken ct = default);
    Task<IReadOnlyList<ObjetivoModelo>> ObjetivosAsync(CancellationToken ct = default);
    Task<IReadOnlyList<ComidaPlantilla>> PlantillaAsync(CancellationToken ct = default);
    Task<ResultadoCalculo> CalcularAsync(PerfilFisico perfil, string? objetivo, CancellationToken ct = default);
    /// <summary>Requiere Estudiante con NivelActividad y Objetivo cargados.</summary>
    Task<ResultadoCalculo> CalcularEstudianteAsync(Estudiante estudiante, DateOnly fecha, string? objetivo = null, CancellationToken ct = default);
    Task<Estudiante> CargarEstudianteAsync(int estudianteId, CancellationToken ct = default);
}

public class NutricionService(SmartNutriDbContext db, IOptions<RecomendacionOptions> opciones) : INutricionService
{
    private IReadOnlyList<ReglaImcModelo>? _reglas;
    private IReadOnlyList<ObjetivoModelo>? _objetivos;

    public async Task<IReadOnlyList<ReglaImcModelo>> ReglasAsync(CancellationToken ct = default)
    {
        if (_reglas is not null) return _reglas;
        var categorias = await db.CategoriasImc.AsNoTracking()
            .Where(c => c.Activo)
            .Include(c => c.ObjetivoSugerido)
            .Include(c => c.ObjetivosPermitidos).ThenInclude(p => p.Objetivo)
            .OrderBy(c => c.ImcMin)
            .ToListAsync(ct);
        if (categorias.Count == 0) throw new InvalidOperationException("No hay categorías de IMC configuradas.");

        _reglas = categorias.Select(c => new ReglaImcModelo(c.Id, c.Nombre, c.ImcMin, c.ImcMax,
            c.ObjetivoSugerido!.Codigo, c.ObjetivosPermitidos.Select(p => p.Objetivo!.Codigo).ToList(), c.Mensaje)).ToList();
        return _reglas;
    }

    public async Task<IReadOnlyList<ObjetivoModelo>> ObjetivosAsync(CancellationToken ct = default)
    {
        if (_objetivos is not null) return _objetivos;
        _objetivos = await db.ObjetivosNutricionales.AsNoTracking()
            .Select(o => new ObjetivoModelo(o.Id, o.Codigo, o.Nombre, o.AjustePorcentaje, o.PctProteina, o.PctCarbohidratos, o.PctGrasas))
            .ToListAsync(ct);
        return _objetivos;
    }

    public async Task<IReadOnlyList<ComidaPlantilla>> PlantillaAsync(CancellationToken ct = default)
    {
        var tipos = await db.TiposComida.AsNoTracking()
            .Include(t => t.Categorias).ThenInclude(c => c.CategoriaAlimento)
            .OrderBy(t => t.Orden)
            .ToListAsync(ct);
        return tipos.Select(t => new ComidaPlantilla(t.Id, t.Nombre, t.Orden, t.PorcentajeCalorias,
            t.Categorias.OrderBy(c => c.Orden).Select(c => c.CategoriaAlimento!.Codigo).ToList())).ToList();
    }

    public async Task<ResultadoCalculo> CalcularAsync(PerfilFisico perfil, string? objetivo, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(objetivo) &&
            objetivo.Trim().ToUpperInvariant() is not (CodigosObjetivo.Bajar or CodigosObjetivo.Mantener or CodigosObjetivo.Ganar))
            throw new ReglaNegocioException($"Objetivo '{objetivo}' no válido. Use BAJAR, MANTENER o GANAR.");

        return CalculadoraNutricional.Calcular(perfil, objetivo, await ReglasAsync(ct), await ObjetivosAsync(ct),
            opciones.Value.CaloriasMinimas);
    }

    public Task<ResultadoCalculo> CalcularEstudianteAsync(Estudiante e, DateOnly fecha, string? objetivo = null, CancellationToken ct = default)
    {
        var perfil = new PerfilFisico(e.PesoKg, e.AlturaCm, CalculadoraNutricional.CalcularEdad(e.FechaNacimiento, fecha),
            string.IsNullOrEmpty(e.Sexo) ? 'M' : e.Sexo[0], e.NivelActividad!.Factor);
        return CalcularAsync(perfil, string.IsNullOrWhiteSpace(objetivo) ? e.Objetivo!.Codigo : objetivo, ct);
    }

    public async Task<Estudiante> CargarEstudianteAsync(int estudianteId, CancellationToken ct = default) =>
        await db.Estudiantes.AsNoTracking()
            .Include(e => e.NivelActividad).Include(e => e.Objetivo).Include(e => e.Curso).Include(e => e.Usuario)
            .FirstOrDefaultAsync(e => e.Id == estudianteId, ct)
        ?? throw new NoEncontradoException($"Estudiante {estudianteId} no encontrado.");
}
