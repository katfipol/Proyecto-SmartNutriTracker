// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Data.Entities;
using SmartNutriTracker.Api.Data;
using SmartNutriTracker.Api.Domain;

namespace SmartNutriTracker.Api.Services;

/// <summary>Conversión a DTOs del Equipo 5 (clase parcial compartida).</summary>
public static partial class Mapeos
{
    public static CalculoNutricionalDto ADto(ResultadoCalculo c) =>
        new(c.Imc, c.CategoriaImc, c.Tmb, c.FactorActividad, c.GastoEnergeticoTotal, c.ObjetivoSolicitado,
            c.ObjetivoAplicado, c.CaloriasObjetivo, c.ProteinasG, c.CarbohidratosG, c.GrasasG, c.Observaciones);
}
