// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using System.ComponentModel.DataAnnotations;

namespace SmartNutriTracker.Api.DTOs;

public sealed record AlimentoExcluidoDto(int AlimentoId, string Alimento, string? Motivo);

public sealed class AlimentoExcluidoRequest
{
    [Required, Range(1, int.MaxValue)] public int AlimentoId { get; set; }
    [MaxLength(150)] public string? Motivo { get; set; }
}

public sealed class CalculoNutricionalRequest
{
    [Required, Range(10, 300)] public decimal PesoKg { get; set; }
    [Required, Range(80, 230)] public decimal AlturaCm { get; set; }
    [Required, Range(5, 100)] public int Edad { get; set; }
    [Required, RegularExpression("^[MF]$")] public string Sexo { get; set; } = "F";
    [Required, Range(1, int.MaxValue)] public int NivelActividadId { get; set; }
    /// <summary>BAJAR | MANTENER | GANAR (opcional)</summary>
    public string? Objetivo { get; set; }
}

public sealed record CalculoNutricionalDto(
    decimal Imc, string CategoriaImc, decimal Tmb, decimal FactorActividad, decimal GastoEnergeticoTotal,
    string ObjetivoSolicitado, string ObjetivoAplicado, decimal CaloriasObjetivo, decimal ProteinasG,
    decimal CarbohidratosG, decimal GrasasG, IReadOnlyList<string> Observaciones);

public sealed class GenerarRecomendacionRequest
{
    [Required, Range(1, int.MaxValue)] public int EstudianteId { get; set; }
    /// <summary>BAJAR | MANTENER | GANAR (opcional: por defecto el del perfil)</summary>
    public string? Objetivo { get; set; }
    public DateOnly? Fecha { get; set; }
    public int? Semilla { get; set; }
}

public sealed record RecomendacionDto(
    int Id, int EstudianteId, string Estudiante, DateOnly Fecha, decimal PesoKg, decimal AlturaCm, int Edad,
    CalculoNutricionalDto Calculo, IReadOnlyList<ComidaDto> Comidas, ResumenNutricionalDto Totales,
    decimal PorcentajeCumplimiento, string Estado, string? ComentarioEstado, int Semilla, DateTime FechaCreacion);

public sealed record RecomendacionResumenDto(int Id, DateOnly Fecha, string CategoriaImc, string ObjetivoAplicado,
    decimal CaloriasObjetivo, decimal CaloriasMenu, decimal PorcentajeCumplimiento, string Estado);

public sealed class CambiarEstadoRequest
{
    /// <summary>Aceptada | Rechazada</summary>
    [Required] public string Estado { get; set; } = string.Empty;
    [MaxLength(300)] public string? Comentario { get; set; }
}

public sealed record CategoriaImcDto(int Id, string Nombre, decimal ImcMin, decimal ImcMax, int ObjetivoSugeridoId,
    string ObjetivoSugerido, IReadOnlyList<int> ObjetivosPermitidosIds, IReadOnlyList<string> ObjetivosPermitidos,
    string Mensaje, bool Activo);

public sealed class CategoriaImcRequest
{
    [Required, Range(0, 99.99)] public decimal ImcMin { get; set; }
    [Required, Range(0, 99.99)] public decimal ImcMax { get; set; }
    [Required, Range(1, int.MaxValue)] public int ObjetivoSugeridoId { get; set; }
    [Required, MinLength(1)] public List<int> ObjetivosPermitidosIds { get; set; } = [];
    [Required, MaxLength(300)] public string Mensaje { get; set; } = string.Empty;
    public bool Activo { get; set; } = true;
}

public sealed record ObjetivoDto(int Id, string Codigo, string Nombre, decimal AjustePorcentaje,
    decimal PctProteina, decimal PctCarbohidratos, decimal PctGrasas, string? Descripcion);

public sealed class ObjetivoRequest
{
    [Required, MaxLength(60)] public string Nombre { get; set; } = string.Empty;
    [Required, Range(-30, 30)] public decimal AjustePorcentaje { get; set; }
    [Required, Range(0, 100)] public decimal PctProteina { get; set; }
    [Required, Range(0, 100)] public decimal PctCarbohidratos { get; set; }
    [Required, Range(0, 100)] public decimal PctGrasas { get; set; }
    [MaxLength(300)] public string? Descripcion { get; set; }
}
