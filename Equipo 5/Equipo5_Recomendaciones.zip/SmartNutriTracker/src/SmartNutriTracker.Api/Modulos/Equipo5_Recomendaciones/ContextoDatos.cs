// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using Microsoft.EntityFrameworkCore;
using SmartNutriTracker.Api.Data.Entities;

namespace SmartNutriTracker.Api.Data;

/// <summary>Tablas del EQUIPO 5 – Recomendaciones Inteligentes dentro del contexto compartido.</summary>
public partial class SmartNutriDbContext
{
    public DbSet<ObjetivoNutricional> ObjetivosNutricionales => Set<ObjetivoNutricional>();
    public DbSet<CategoriaImc> CategoriasImc => Set<CategoriaImc>();
    public DbSet<CategoriaImcObjetivo> CategoriaImcObjetivos => Set<CategoriaImcObjetivo>();
    public DbSet<AlimentoExcluido> AlimentosExcluidos => Set<AlimentoExcluido>();
    public DbSet<Recomendacion> Recomendaciones => Set<Recomendacion>();
    public DbSet<RecomendacionDetalle> RecomendacionDetalles => Set<RecomendacionDetalle>();
    public DbSet<RecomendacionObservacion> RecomendacionObservaciones => Set<RecomendacionObservacion>();

    partial void ConfigurarEquipo5(ModelBuilder mb)
    {
        mb.Entity<ObjetivoNutricional>().ToTable("ObjetivosNutricionales");
        mb.Entity<CategoriaImc>(e =>
        {
            e.ToTable("CategoriasImc");
            e.HasOne(x => x.ObjetivoSugerido).WithMany().HasForeignKey(x => x.ObjetivoSugeridoId).OnDelete(DeleteBehavior.Restrict);
            e.HasMany(x => x.ObjetivosPermitidos).WithOne(x => x.CategoriaImc).HasForeignKey(x => x.CategoriaImcId);
        });
        mb.Entity<CategoriaImcObjetivo>(e =>
        {
            e.ToTable("CategoriaImcObjetivos");
            e.HasKey(x => new { x.CategoriaImcId, x.ObjetivoId });
            e.HasOne(x => x.Objetivo).WithMany().HasForeignKey(x => x.ObjetivoId).OnDelete(DeleteBehavior.Restrict);
        });
        mb.Entity<AlimentoExcluido>(e =>
        {
            e.ToTable("AlimentosExcluidos");
            e.HasKey(x => new { x.EstudianteId, x.AlimentoId });
        });
        mb.Entity<Recomendacion>(e =>
        {
            e.ToTable("Recomendaciones");
            e.Property(x => x.FactorActividad).HasPrecision(4, 3);
            e.HasOne(x => x.ObjetivoSolicitado).WithMany().HasForeignKey(x => x.ObjetivoSolicitadoId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.ObjetivoAplicado).WithMany().HasForeignKey(x => x.ObjetivoAplicadoId).OnDelete(DeleteBehavior.Restrict);
            e.HasMany(x => x.Detalles).WithOne().HasForeignKey(x => x.RecomendacionId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(x => x.Observaciones).WithOne().HasForeignKey(x => x.RecomendacionId).OnDelete(DeleteBehavior.Cascade);
        });
        mb.Entity<RecomendacionDetalle>().ToTable("RecomendacionDetalles");
        mb.Entity<RecomendacionObservacion>().ToTable("RecomendacionObservaciones");
    }
}
