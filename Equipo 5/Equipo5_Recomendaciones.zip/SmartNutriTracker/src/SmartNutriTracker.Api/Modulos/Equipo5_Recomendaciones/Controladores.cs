// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartNutriTracker.Api.Common;
using SmartNutriTracker.Api.DTOs;
using SmartNutriTracker.Api.Services;

namespace SmartNutriTracker.Api.Controllers;

/// <summary>EQUIPO 5 – HU-23: recomendaciones inteligentes.</summary>
[ApiController]
[Route("api/recomendaciones")]
[Authorize]
[Produces("application/json")]
public class RecomendacionesController(IRecomendacionesService servicio) : ControllerBase
{
    /// <summary>Genera y guarda un menú diario saludable según IMC, objetivo y alimentos excluidos.</summary>
    [HttpPost("generar")]
    public async Task<ActionResult<RecomendacionDto>> Generar([FromBody] GenerarRecomendacionRequest request, CancellationToken ct) =>
        StatusCode(StatusCodes.Status201Created, await servicio.GenerarAsync(request, ct));

    [HttpGet("{id:int}")]
    public async Task<ActionResult<RecomendacionDto>> Obtener(int id, CancellationToken ct) => Ok(await servicio.ObtenerAsync(id, ct));

    [HttpGet("estudiante/{estudianteId:int}")]
    public async Task<ActionResult<IReadOnlyList<RecomendacionResumenDto>>> Historial(int estudianteId, CancellationToken ct) =>
        Ok(await servicio.HistorialAsync(estudianteId, ct));

    [HttpGet("estudiante/{estudianteId:int}/ultima")]
    public async Task<ActionResult<RecomendacionDto>> Ultima(int estudianteId, CancellationToken ct)
    {
        var dto = await servicio.UltimaAsync(estudianteId, ct);
        return dto is null ? NoContent() : Ok(dto);
    }

    [HttpPatch("{id:int}/estado")]
    public async Task<ActionResult<RecomendacionDto>> CambiarEstado(int id, [FromBody] CambiarEstadoRequest request, CancellationToken ct) =>
        Ok(await servicio.CambiarEstadoAsync(id, request, ct));

    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<IActionResult> Eliminar(int id, CancellationToken ct)
    {
        await servicio.EliminarAsync(id, ct);
        return NoContent();
    }
}

/// <summary>EQUIPO 5 – HU-26: cálculo nutricional automático.</summary>
[ApiController]
[Route("api/calculos")]
[Authorize]
[Produces("application/json")]
public class CalculosController(INutricionService nutricion, IAccesoService acceso) : ControllerBase
{
    /// <summary>IMC, TMB (Mifflin-St Jeor), gasto energético, calorías y macronutrientes para datos libres.</summary>
    [HttpPost("nutricional")]
    public async Task<ActionResult<CalculoNutricionalDto>> Calcular([FromBody] CalculoNutricionalRequest r,
        [FromServices] ICatalogosService catalogos, CancellationToken ct)
    {
        var nivel = (await catalogos.ObtenerAsync(ct)).NivelesActividad.FirstOrDefault(n => n.Id == r.NivelActividadId)
                    ?? throw new ReglaNegocioException("Nivel de actividad no válido.");
        var perfil = new Domain.PerfilFisico(r.PesoKg, r.AlturaCm, r.Edad, r.Sexo[0], nivel.Factor);
        return Ok(Mapeos.ADto(await nutricion.CalcularAsync(perfil, r.Objetivo, ct)));
    }

    /// <summary>Requerimientos del estudiante según su perfil registrado.</summary>
    [HttpGet("estudiante/{estudianteId:int}")]
    public async Task<ActionResult<CalculoNutricionalDto>> Estudiante(int estudianteId, [FromQuery] string? objetivo, CancellationToken ct)
    {
        await acceso.VerificarEstudianteAsync(estudianteId, ct);
        var e = await nutricion.CargarEstudianteAsync(estudianteId, ct);
        return Ok(Mapeos.ADto(await nutricion.CalcularEstudianteAsync(e, DateOnly.FromDateTime(DateTime.Today), objetivo, ct)));
    }
}

/// <summary>HU-24 / HU-25 / HU-27: reglas configurables (IMC, objetivos y umbrales de alertas).</summary>
[ApiController]
[Route("api/reglas")]
[Authorize(Roles = Roles.Personal)]
[Produces("application/json")]
public class ReglasController(IReglasService reglas, IAlertasService alertas) : ControllerBase
{
    [HttpGet("imc")]
    public async Task<ActionResult<IReadOnlyList<CategoriaImcDto>>> Categorias(CancellationToken ct) => Ok(await reglas.CategoriasAsync(ct));

    [HttpPut("imc/{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<CategoriaImcDto>> ActualizarCategoria(int id, [FromBody] CategoriaImcRequest request, CancellationToken ct) =>
        Ok(await reglas.ActualizarCategoriaAsync(id, request, ct));

    [HttpGet("objetivos")]
    public async Task<ActionResult<IReadOnlyList<ObjetivoDto>>> Objetivos(CancellationToken ct) => Ok(await reglas.ObjetivosAsync(ct));

    [HttpPut("objetivos/{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<ObjetivoDto>> ActualizarObjetivo(int id, [FromBody] ObjetivoRequest request, CancellationToken ct) =>
        Ok(await reglas.ActualizarObjetivoAsync(id, request, ct));

    [HttpGet("alertas")]
    public async Task<ActionResult<IReadOnlyList<TipoAlertaDto>>> TiposAlerta(CancellationToken ct) => Ok(await alertas.TiposAsync(ct));

    [HttpPut("alertas/{id:int}")]
    [Authorize(Roles = Roles.Salud)]
    public async Task<ActionResult<TipoAlertaDto>> ActualizarTipoAlerta(int id, [FromBody] TipoAlertaRequest request, CancellationToken ct) =>
        Ok(await alertas.ActualizarTipoAsync(id, request, ct));
}
