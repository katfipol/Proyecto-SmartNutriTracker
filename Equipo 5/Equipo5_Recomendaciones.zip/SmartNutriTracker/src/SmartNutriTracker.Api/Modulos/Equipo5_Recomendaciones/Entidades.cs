// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Data.Entities;

public class ObjetivoNutricional
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public decimal AjustePorcentaje { get; set; }
    public decimal PctProteina { get; set; }
    public decimal PctCarbohidratos { get; set; }
    public decimal PctGrasas { get; set; }
    public string? Descripcion { get; set; }
}

public class CategoriaImc
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public decimal ImcMin { get; set; }
    public decimal ImcMax { get; set; }
    public int ObjetivoSugeridoId { get; set; }
    public string Mensaje { get; set; } = string.Empty;
    public bool Activo { get; set; } = true;

    public ObjetivoNutricional? ObjetivoSugerido { get; set; }
    public List<CategoriaImcObjetivo> ObjetivosPermitidos { get; set; } = [];
}

public class CategoriaImcObjetivo
{
    public int CategoriaImcId { get; set; }
    public int ObjetivoId { get; set; }

    public CategoriaImc? CategoriaImc { get; set; }
    public ObjetivoNutricional? Objetivo { get; set; }
}

public class AlimentoExcluido
{
    public int EstudianteId { get; set; }
    public int AlimentoId { get; set; }
    public string? Motivo { get; set; }

    public Alimento? Alimento { get; set; }
}

public class Recomendacion
{
    public int Id { get; set; }
    public int EstudianteId { get; set; }
    public DateOnly Fecha { get; set; }
    public decimal PesoKg { get; set; }
    public decimal AlturaCm { get; set; }
    public int Edad { get; set; }
    public decimal FactorActividad { get; set; }
    public int CategoriaImcId { get; set; }
    public int ObjetivoSolicitadoId { get; set; }
    public int ObjetivoAplicadoId { get; set; }
    public decimal CaloriasObjetivo { get; set; }
    public decimal ProteinasObjetivoG { get; set; }
    public decimal CarbohidratosObjetivoG { get; set; }
    public decimal GrasasObjetivoG { get; set; }
    public string Estado { get; set; } = "Generada";
    public string? ComentarioEstado { get; set; }
    public int Semilla { get; set; }
    public int? CreadoPorId { get; set; }
    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public Estudiante? Estudiante { get; set; }
    public CategoriaImc? CategoriaImc { get; set; }
    public ObjetivoNutricional? ObjetivoSolicitado { get; set; }
    public ObjetivoNutricional? ObjetivoAplicado { get; set; }
    public List<RecomendacionDetalle> Detalles { get; set; } = [];
    public List<RecomendacionObservacion> Observaciones { get; set; } = [];
}

public class RecomendacionDetalle
{
    public int Id { get; set; }
    public int RecomendacionId { get; set; }
    public int TipoComidaId { get; set; }
    public int AlimentoId { get; set; }
    public decimal Porciones { get; set; }

    public TipoComida? TipoComida { get; set; }
    public Alimento? Alimento { get; set; }
}

public class RecomendacionObservacion
{
    public int Id { get; set; }
    public int RecomendacionId { get; set; }
    public int Orden { get; set; }
    public string Texto { get; set; } = string.Empty;
}
