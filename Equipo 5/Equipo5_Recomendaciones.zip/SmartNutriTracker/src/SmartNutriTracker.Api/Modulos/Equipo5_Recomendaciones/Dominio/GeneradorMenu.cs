// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Domain;

/// <summary>
/// HU-23 – Motor de recomendación de menú basado en reglas simples:
/// 1) Reparte las calorías objetivo entre los tiempos de comida.
/// 2) En cada comida elige un alimento por categoría de la plantilla, sin repetir en el día
///    y priorizando los que no se recomendaron recientemente.
/// 3) Escala las porciones (pasos de 0.5) para acercarse a las calorías de esa comida.
/// 4) Calcula totales, % de cumplimiento y observaciones.
/// </summary>
public static class GeneradorMenu
{
    public static MenuGenerado Generar(
        ResultadoCalculo calculo,
        IReadOnlyList<ComidaPlantilla> plantilla,
        IReadOnlyList<AlimentoCandidato> alimentos,
        IReadOnlySet<int> alimentosRecientes,
        int semilla,
        RecomendacionOptions opciones)
    {
        ArgumentNullException.ThrowIfNull(calculo);
        if (plantilla.Count == 0) throw new InvalidOperationException("No hay tiempos de comida configurados.");
        if (alimentos.Count == 0) throw new InvalidOperationException("No hay alimentos disponibles para generar la recomendación.");

        var sumaPct = plantilla.Sum(p => p.Porcentaje);
        if (sumaPct != 100m)
            throw new InvalidOperationException($"La distribución de comidas debe sumar 100% (actual: {sumaPct}%).");

        var random = new Random(semilla);
        var usadosHoy = new HashSet<int>();
        var items = new List<ItemMenu>();
        var observaciones = new List<string>();

        foreach (var comida in plantilla.OrderBy(p => p.Orden))
        {
            var caloriasComida = calculo.CaloriasObjetivo * comida.Porcentaje / 100m;
            var elegidos = new List<AlimentoCandidato>();

            foreach (var categoria in comida.Categorias)
            {
                var candidatos = alimentos
                    .Where(a => string.Equals(a.Categoria, categoria, StringComparison.OrdinalIgnoreCase) && !usadosHoy.Contains(a.Id))
                    .OrderBy(a => a.Id)
                    .ToList();

                if (candidatos.Count == 0)
                {
                    observaciones.Add($"{comida.TipoComida}: no hay alimentos disponibles de la categoría {categoria}.");
                    continue;
                }

                var noRecientes = candidatos.Where(a => !alimentosRecientes.Contains(a.Id)).ToList();
                var pool = noRecientes.Count > 0 ? noRecientes : candidatos;
                var elegido = pool[random.Next(pool.Count)];
                elegidos.Add(elegido);
                usadosHoy.Add(elegido.Id);
            }

            if (elegidos.Count == 0) continue;

            var caloriasBase = elegidos.Sum(a => a.Calorias);
            var factor = caloriasBase > 0 ? caloriasComida / caloriasBase : 1m;
            var porciones = RedondearPorcion(factor, opciones.PorcionMinima, opciones.PorcionMaxima);
            items.AddRange(elegidos.Select(a => new ItemMenu(comida.TipoComidaId, comida.TipoComida, comida.Orden, a, porciones)));
        }

        var totales = CalculadoraNutricional.CalcularTotales(items);
        var cumplimiento = calculo.CaloriasObjetivo > 0 ? Math.Round(totales.Calorias / calculo.CaloriasObjetivo * 100m, 2) : 0m;
        observaciones.AddRange(EvaluarCumplimiento(calculo, totales, cumplimiento, opciones.ToleranciaCaloriasPorcentaje));

        return new MenuGenerado(items, totales, cumplimiento, observaciones);
    }

    /// <summary>Redondea a múltiplos de 0.5 dentro de [min, max].</summary>
    public static decimal RedondearPorcion(decimal factor, decimal minimo, decimal maximo) =>
        Math.Clamp(Math.Round(factor * 2m, MidpointRounding.AwayFromZero) / 2m, minimo, maximo);

    public static IEnumerable<string> EvaluarCumplimiento(ResultadoCalculo calculo, TotalesNutricionales totales, decimal cumplimiento, decimal tolerancia)
    {
        if (cumplimiento < 100 - tolerancia)
            yield return $"El menú cubre el {cumplimiento}% de las calorías objetivo; se sugiere agregar una porción extra.";
        else if (cumplimiento > 100 + tolerancia)
            yield return $"El menú cubre el {cumplimiento}% de las calorías objetivo; se sugiere reducir porciones.";

        if (calculo.ProteinasG > 0 && totales.Proteinas < calculo.ProteinasG * 0.9m)
            yield return $"Proteína del menú ({totales.Proteinas} g) por debajo del objetivo ({calculo.ProteinasG} g).";

        if (calculo.GrasasG > 0 && totales.Grasas > calculo.GrasasG * 1.2m)
            yield return $"Grasas del menú ({totales.Grasas} g) por encima del objetivo ({calculo.GrasasG} g).";
    }
}
