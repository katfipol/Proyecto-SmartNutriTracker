// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Domain;

/// <summary>
/// HU-26 – Cálculo nutricional automático (lógica pura, sin base de datos).
/// IMC, TMB (Mifflin-St Jeor), gasto energético total, calorías objetivo y macronutrientes.
/// </summary>
public static class CalculadoraNutricional
{
    public static decimal CalcularImc(decimal pesoKg, decimal alturaCm)
    {
        if (pesoKg <= 0) throw new ArgumentOutOfRangeException(nameof(pesoKg), "El peso debe ser mayor a 0.");
        if (alturaCm <= 0) throw new ArgumentOutOfRangeException(nameof(alturaCm), "La altura debe ser mayor a 0.");
        var metros = alturaCm / 100m;
        return Math.Round(pesoKg / (metros * metros), 2);
    }

    public static decimal CalcularTmb(PerfilFisico perfil)
    {
        ValidarPerfil(perfil);
        var baseCalculo = 10m * perfil.PesoKg + 6.25m * perfil.AlturaCm - 5m * perfil.Edad;
        return Math.Round(char.ToUpperInvariant(perfil.Sexo) == 'M' ? baseCalculo + 5m : baseCalculo - 161m, 2);
    }

    /// <summary>HU-24 – Ubica el IMC en la categoría correspondiente.</summary>
    public static ReglaImcModelo ClasificarImc(decimal imc, IEnumerable<ReglaImcModelo> reglas) =>
        reglas.FirstOrDefault(r => imc >= r.ImcMin && imc < r.ImcMax)
        ?? throw new InvalidOperationException($"No existe una categoría de IMC configurada para el valor {imc}.");

    /// <summary>HU-24 + HU-25: si el objetivo pedido no está permitido para el IMC, se usa el sugerido.</summary>
    public static (string ObjetivoAplicado, string? Observacion) ResolverObjetivo(string? objetivoSolicitado, ReglaImcModelo regla)
    {
        if (string.IsNullOrWhiteSpace(objetivoSolicitado))
            return (regla.ObjetivoSugerido, $"Sin objetivo definido: se aplica el sugerido para IMC '{regla.Categoria}' ({regla.ObjetivoSugerido}).");

        var solicitado = objetivoSolicitado.Trim().ToUpperInvariant();
        if (regla.ObjetivosPermitidos.Contains(solicitado, StringComparer.OrdinalIgnoreCase))
            return (solicitado, null);

        return (regla.ObjetivoSugerido,
            $"El objetivo '{solicitado}' no es adecuado para IMC '{regla.Categoria}'. Se aplicó '{regla.ObjetivoSugerido}'. {regla.Mensaje}");
    }

    public static ResultadoCalculo Calcular(
        PerfilFisico perfil,
        string? objetivoSolicitado,
        IReadOnlyList<ReglaImcModelo> reglas,
        IReadOnlyList<ObjetivoModelo> objetivos,
        decimal caloriasMinimas)
    {
        ValidarPerfil(perfil);
        var observaciones = new List<string>();

        var imc = CalcularImc(perfil.PesoKg, perfil.AlturaCm);
        var regla = ClasificarImc(imc, reglas);
        observaciones.Add($"IMC {imc} – {regla.Categoria}. {regla.Mensaje}");

        var (codigoObjetivo, obsObjetivo) = ResolverObjetivo(objetivoSolicitado, regla);
        if (obsObjetivo is not null) observaciones.Add(obsObjetivo);

        var objetivo = objetivos.FirstOrDefault(o => string.Equals(o.Codigo, codigoObjetivo, StringComparison.OrdinalIgnoreCase))
                       ?? throw new InvalidOperationException($"El objetivo '{codigoObjetivo}' no está configurado.");

        var tmb = CalcularTmb(perfil);
        var get = Math.Round(tmb * perfil.FactorActividad, 2);

        var calorias = Math.Round(get * (1 + objetivo.AjustePorcentaje / 100m), 0);
        if (calorias < caloriasMinimas)
        {
            observaciones.Add($"Las calorías calculadas ({calorias} kcal) son menores al mínimo seguro; se ajustan a {caloriasMinimas} kcal.");
            calorias = caloriasMinimas;
        }

        var proteinas = Math.Round(calorias * objetivo.PctProteina / 100m / 4m, 1);
        var carbohidratos = Math.Round(calorias * objetivo.PctCarbohidratos / 100m / 4m, 1);
        var grasas = Math.Round(calorias * objetivo.PctGrasas / 100m / 9m, 1);

        var solicitado = string.IsNullOrWhiteSpace(objetivoSolicitado) ? codigoObjetivo : objetivoSolicitado.Trim().ToUpperInvariant();
        return new ResultadoCalculo(imc, regla.Id, regla.Categoria, tmb, perfil.FactorActividad, get, solicitado,
            objetivo.Codigo, calorias, proteinas, carbohidratos, grasas, observaciones);
    }

    public static TotalesNutricionales CalcularTotales(IEnumerable<ItemMenu> items)
    {
        decimal kcal = 0, p = 0, c = 0, g = 0;
        foreach (var i in items) { kcal += i.Calorias; p += i.Proteinas; c += i.Carbohidratos; g += i.Grasas; }
        return new TotalesNutricionales(Math.Round(kcal, 2), Math.Round(p, 2), Math.Round(c, 2), Math.Round(g, 2));
    }

    public static int CalcularEdad(DateOnly fechaNacimiento, DateOnly fecha)
    {
        var edad = fecha.Year - fechaNacimiento.Year;
        if (fechaNacimiento > fecha.AddYears(-edad)) edad--;
        return edad;
    }

    private static void ValidarPerfil(PerfilFisico perfil)
    {
        ArgumentNullException.ThrowIfNull(perfil);
        if (perfil.PesoKg is <= 0 or > 400) throw new ArgumentOutOfRangeException(nameof(perfil), "Peso fuera de rango (0-400 kg).");
        if (perfil.AlturaCm is < 50 or > 250) throw new ArgumentOutOfRangeException(nameof(perfil), "Altura fuera de rango (50-250 cm).");
        if (perfil.Edad is < 5 or > 100) throw new ArgumentOutOfRangeException(nameof(perfil), "Edad fuera de rango (5-100 años).");
        if (perfil.FactorActividad is < 1 or > 2.5m) throw new ArgumentOutOfRangeException(nameof(perfil), "Factor de actividad fuera de rango (1-2.5).");
        if (char.ToUpperInvariant(perfil.Sexo) is not ('M' or 'F')) throw new ArgumentException("Sexo debe ser 'M' o 'F'.", nameof(perfil));
    }
}
