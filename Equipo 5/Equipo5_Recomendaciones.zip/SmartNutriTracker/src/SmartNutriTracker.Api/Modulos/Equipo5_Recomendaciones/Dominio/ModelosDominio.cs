// EQUIPO 5 – Recomendaciones Inteligentes
// SmartNutriTracker · Colegio Innovare


namespace SmartNutriTracker.Api.Domain;

/// <summary>Datos físicos para calcular requerimientos (HU-26).</summary>
public sealed record PerfilFisico(decimal PesoKg, decimal AlturaCm, int Edad, char Sexo, decimal FactorActividad);

/// <summary>Categoría de IMC con sus objetivos permitidos (HU-24). ImcMin inclusivo, ImcMax exclusivo.</summary>
public sealed record ReglaImcModelo(
    int Id, string Categoria, decimal ImcMin, decimal ImcMax,
    string ObjetivoSugerido, IReadOnlyList<string> ObjetivosPermitidos, string Mensaje);

/// <summary>Objetivo nutricional con ajuste calórico y reparto de macros (HU-25).</summary>
public sealed record ObjetivoModelo(
    int Id, string Codigo, string Nombre, decimal AjustePorcentaje,
    decimal PctProteina, decimal PctCarbohidratos, decimal PctGrasas);

/// <summary>Resultado del cálculo nutricional automático (HU-26).</summary>
public sealed record ResultadoCalculo(
    decimal Imc,
    int CategoriaImcId,
    string CategoriaImc,
    decimal Tmb,
    decimal FactorActividad,
    decimal GastoEnergeticoTotal,
    string ObjetivoSolicitado,
    string ObjetivoAplicado,
    decimal CaloriasObjetivo,
    decimal ProteinasG,
    decimal CarbohidratosG,
    decimal GrasasG,
    IReadOnlyList<string> Observaciones);

/// <summary>Alimento disponible para el menú (valores por porción).</summary>
public sealed record AlimentoCandidato(
    int Id, string Nombre, string Categoria, string Porcion,
    decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas);

/// <summary>Tiempo de comida con su % de calorías y las categorías que lo componen.</summary>
public sealed record ComidaPlantilla(int TipoComidaId, string TipoComida, int Orden, decimal Porcentaje, IReadOnlyList<string> Categorias);

/// <summary>Un alimento del menú con sus porciones.</summary>
public sealed record ItemMenu(int TipoComidaId, string TipoComida, int OrdenComida, AlimentoCandidato Alimento, decimal Porciones)
{
    public decimal Calorias => Math.Round(Alimento.Calorias * Porciones, 2);
    public decimal Proteinas => Math.Round(Alimento.Proteinas * Porciones, 2);
    public decimal Carbohidratos => Math.Round(Alimento.Carbohidratos * Porciones, 2);
    public decimal Grasas => Math.Round(Alimento.Grasas * Porciones, 2);
}

public sealed record TotalesNutricionales(decimal Calorias, decimal Proteinas, decimal Carbohidratos, decimal Grasas)
{
    public static readonly TotalesNutricionales Cero = new(0, 0, 0, 0);

    /// <summary>% de calorías por macronutriente (4 kcal/g proteína y carbohidrato, 9 kcal/g grasa).</summary>
    public (decimal Proteina, decimal Carbohidratos, decimal Grasas) DistribucionPorcentual()
    {
        var kcal = Proteinas * 4 + Carbohidratos * 4 + Grasas * 9;
        if (kcal <= 0) return (0, 0, 0);
        return (Math.Round(Proteinas * 4 / kcal * 100, 1),
                Math.Round(Carbohidratos * 4 / kcal * 100, 1),
                Math.Round(Grasas * 9 / kcal * 100, 1));
    }
}

public sealed record MenuGenerado(
    IReadOnlyList<ItemMenu> Items,
    TotalesNutricionales Totales,
    decimal PorcentajeCumplimiento,
    IReadOnlyList<string> Observaciones);

/// <summary>Parámetros del motor (appsettings: "Recomendaciones").</summary>
public sealed class RecomendacionOptions
{
    public decimal CaloriasMinimas { get; set; } = 1400;
    public int RecomendacionesRecientesParaVariedad { get; set; } = 3;
    public decimal PorcionMinima { get; set; } = 0.5m;
    public decimal PorcionMaxima { get; set; } = 3.0m;
    public decimal ToleranciaCaloriasPorcentaje { get; set; } = 10;
}

public static class CodigosObjetivo
{
    public const string Bajar = "BAJAR";
    public const string Mantener = "MANTENER";
    public const string Ganar = "GANAR";
}
