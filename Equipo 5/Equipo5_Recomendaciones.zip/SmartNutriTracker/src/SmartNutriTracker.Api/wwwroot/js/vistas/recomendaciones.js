// EQUIPO 5 – HU-23 recomendación · HU-24 IMC · HU-25 objetivos · HU-26 cálculo
import { api } from '../api.js';
import { estado, cargarEstudiantes, estudianteSeleccionado, htmlSelectorEstudiante, engancharSelector } from '../estado.js';
import { esc, num, fecha, vacio, toast, on, htmlComidas, htmlResumen, badgeEstado, badgeImc, abrirModal } from '../ui.js';

let seleccionada = null; // id de recomendación mostrada

export async function render(ctx) {
  const { el, params } = ctx;
  await cargarEstudiantes();
  const id = estudianteSeleccionado(params);
  if (!id) { el.innerHTML = vacio('No hay estudiantes disponibles.', 'bi-people'); return; }

  const historial = await api.get(`/api/recomendaciones/estudiante/${id}`);
  if (!historial.some(h => h.id === seleccionada)) seleccionada = historial[0]?.id ?? null;
  const rec = seleccionada ? await api.get(`/api/recomendaciones/${seleccionada}`) : null;

  el.innerHTML = `
    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
      ${htmlSelectorEstudiante(id)}
      <div class="ms-auto d-flex gap-2 align-items-center">
        <select class="form-select form-select-sm" id="objetivo" style="width:220px">
          <option value="">Objetivo del perfil</option>
          ${estado.catalogos.objetivos.map(o => `<option value="${esc(o.codigo)}">${esc(o.nombre)}</option>`).join('')}
        </select>
        <button class="btn btn-primary btn-sm text-nowrap" data-accion="generar"><span class="spinner-border spinner-border-sm d-none me-1"></span><i class="bi bi-stars me-1"></i>Generar menú recomendado</button>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-xl-9">${rec ? detalle(rec) : `<div class="tarjeta">${vacio('Aún no hay recomendaciones. Presiona "Generar menú recomendado".', 'bi-stars')}</div>`}</div>
      <div class="col-xl-3"><div class="tarjeta"><div class="cabecera"><i class="bi bi-clock-history" style="color:var(--snt-700)"></i><h3>Historial</h3></div>
        <div class="cuerpo p-0">${historial.length ? historial.map(h => `
          <a href="#" class="d-block px-3 py-2 border-bottom text-decoration-none ${h.id === seleccionada ? 'bg-body-secondary' : ''}" data-accion="ver" data-id="${h.id}" style="color:inherit">
            <div class="d-flex justify-content-between"><strong>${fecha(h.fecha)}</strong>${badgeEstado(h.estado)}</div>
            <div class="small muted">${esc(h.objetivoAplicado)} · ${num(h.caloriasMenu)} / ${num(h.caloriasObjetivo)} kcal</div>
          </a>`).join('') : '<div class="p-3 small muted">Sin historial.</div>'}</div></div></div>
    </div>`;

  const recargar = () => render(ctx);
  engancharSelector(el, () => { seleccionada = null; recargar(); });
  on(el, 'click', '[data-accion=ver]', (ev, a) => { ev.preventDefault(); seleccionada = parseInt(a.dataset.id, 10); recargar(); });
  on(el, 'click', '[data-accion=generar]', async (_, b) => {
    b.disabled = true;
    b.querySelector('.spinner-border').classList.remove('d-none');
    try {
      const r = await api.post('/api/recomendaciones/generar', { estudianteId: id, objetivo: el.querySelector('#objetivo').value || null });
      seleccionada = r.id;
      toast('Menú recomendado generado.');
      recargar();
    } catch (e) {
      toast(e.message, 'error');
      b.disabled = false;
      b.querySelector('.spinner-border').classList.add('d-none');
    }
  });
  on(el, 'click', '[data-accion=estado]', (_, b) => {
    const nuevo = b.dataset.estado;
    abrirModal({
      titulo: nuevo === 'Aceptada' ? 'Aceptar recomendación' : 'Rechazar recomendación',
      cuerpo: `<label class="form-label">Comentario (opcional)</label><textarea class="form-control" id="comentario" maxlength="300" rows="3"></textarea>`,
      textoGuardar: nuevo === 'Aceptada' ? 'Aceptar' : 'Rechazar',
      alGuardar: async (form) => {
        await api.patch(`/api/recomendaciones/${rec.id}/estado`, { estado: nuevo, comentario: form.querySelector('#comentario').value.trim() || null });
        toast(`Recomendación ${nuevo.toLowerCase()}.`);
        recargar();
      }
    });
  });
}

function detalle(r) {
  const c = r.calculo;
  return `
    <div class="tarjeta mb-3"><div class="cuerpo pt-3">
      <div class="d-flex flex-wrap justify-content-between gap-2 align-items-start">
        <div><h4 class="fw-bold mb-0">Menú del ${fecha(r.fecha, true)}</h4>
          <div class="muted small">${esc(r.estudiante)} · ${r.edad} años · ${num(r.pesoKg, 1)} kg · ${num(r.alturaCm)} cm</div></div>
        <div class="text-end">${badgeEstado(r.estado)}
          ${r.estado === 'Generada' ? `<div class="mt-2 d-flex gap-1">
            <button class="btn btn-sm btn-success" data-accion="estado" data-estado="Aceptada"><i class="bi bi-hand-thumbs-up me-1"></i>Aceptar</button>
            <button class="btn btn-sm btn-light" data-accion="estado" data-estado="Rechazada"><i class="bi bi-hand-thumbs-down me-1"></i>Rechazar</button></div>` : ''}
          ${r.comentarioEstado ? `<div class="small muted mt-1">“${esc(r.comentarioEstado)}”</div>` : ''}</div>
      </div>
      <div class="row g-2 text-center mt-2">
        <div class="col-6 col-md"><div class="p-2 rounded-3" style="background:var(--snt-50)"><div class="small muted">IMC</div><div class="fw-bold">${num(c.imc, 1)}</div>${badgeImc(c.categoriaImc)}</div></div>
        <div class="col-6 col-md"><div class="p-2 rounded-3" style="background:var(--snt-50)"><div class="small muted">TMB</div><div class="fw-bold">${num(c.tmb)} kcal</div></div></div>
        <div class="col-6 col-md"><div class="p-2 rounded-3" style="background:var(--snt-50)"><div class="small muted">Gasto total</div><div class="fw-bold">${num(c.gastoEnergeticoTotal)} kcal</div><div class="small muted">×${num(c.factorActividad, 3)}</div></div></div>
        <div class="col-6 col-md"><div class="p-2 rounded-3" style="background:var(--snt-100)"><div class="small muted">Objetivo</div><div class="fw-bold">${num(c.caloriasObjetivo)} kcal</div><div class="small">${esc(c.objetivoAplicado)}</div></div></div>
        <div class="col-12 col-md"><div class="p-2 rounded-3" style="background:var(--snt-50)"><div class="small muted">Macros objetivo</div>
          <div class="small fw-semibold">P ${num(c.proteinasG)} g · C ${num(c.carbohidratosG)} g · G ${num(c.grasasG)} g</div></div></div>
      </div>
    </div></div>

    <div class="row g-3">
      <div class="col-lg-7">${htmlComidas(r.comidas)}</div>
      <div class="col-lg-5">
        <div class="tarjeta p-3 mb-3"><div class="fw-bold mb-2">Total del menú · ${num(r.porcentajeCumplimiento, 0)}% del objetivo</div>${htmlResumen(r.totales, c.caloriasObjetivo)}</div>
        <div class="tarjeta p-3"><div class="fw-bold mb-2"><i class="bi bi-lightbulb me-1" style="color:var(--snt-lima)"></i>Observaciones del motor</div>
          ${c.observaciones.map(o => `<div class="observacion ${/no es adecuado|debajo|encima|reducir|agregar/i.test(o) ? 'alerta' : ''}">${esc(o)}</div>`).join('')}</div>
      </div>
    </div>`;
}
