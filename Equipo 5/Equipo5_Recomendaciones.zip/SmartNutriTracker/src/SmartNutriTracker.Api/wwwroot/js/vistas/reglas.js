// HU-24 reglas por IMC · HU-25 objetivos · HU-27 umbrales de alertas
import { api } from '../api.js';
import { estado, esSalud } from '../estado.js';
import { esc, num, abrirModal, opciones, toast, on, leerFormulario, badgeNivel } from '../ui.js';

export async function render(ctx) {
  const { el } = ctx;
  const [categorias, objetivos, alertas] = await Promise.all([
    api.get('/api/reglas/imc'), api.get('/api/reglas/objetivos'), api.get('/api/reglas/alertas')
  ]);
  const editar = esSalud();
  const btn = (accion, id) => editar ? `<button class="btn btn-sm btn-light" data-accion="${accion}" data-id="${id}"><i class="bi bi-pencil"></i></button>` : '';

  el.innerHTML = `
    ${editar ? '' : '<div class="alert alert-info py-2 small"><i class="bi bi-eye me-1"></i>Vista de consulta. Solo el nutricionista o el administrador pueden modificar las reglas.</div>'}
    <div class="tarjeta mb-3"><div class="cabecera"><i class="bi bi-rulers" style="color:var(--snt-700)"></i><h3>Modelo nutricional según IMC</h3></div>
      <div class="cuerpo p-0"><div class="table-responsive"><table class="table">
        <thead><tr><th>Categoría</th><th>Rango IMC</th><th>Objetivo sugerido</th><th>Objetivos permitidos</th><th>Mensaje</th><th></th></tr></thead>
        <tbody>${categorias.map(c => `<tr class="${c.activo ? '' : 'opacity-50'}">
          <td class="fw-semibold">${esc(c.nombre)}</td><td>${num(c.imcMin, 1)} – ${num(c.imcMax, 1)}</td>
          <td><span class="badge b-verde">${esc(c.objetivoSugerido)}</span></td>
          <td>${c.objetivosPermitidos.map(o => `<span class="badge b-gris me-1">${esc(o)}</span>`).join('')}</td>
          <td class="small">${esc(c.mensaje)}</td><td class="text-end">${btn('imc', c.id)}</td></tr>`).join('')}</tbody></table></div></div></div>

    <div class="row g-3">
      <div class="col-xl-6"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-bullseye" style="color:var(--snt-700)"></i><h3>Objetivos nutricionales</h3></div>
        <div class="cuerpo p-0"><div class="table-responsive"><table class="table">
          <thead><tr><th>Objetivo</th><th class="text-end">Ajuste kcal</th><th class="text-end">Prot.</th><th class="text-end">Carb.</th><th class="text-end">Grasas</th><th></th></tr></thead>
          <tbody>${objetivos.map(o => `<tr><td><div class="fw-semibold">${esc(o.nombre)}</div><div class="small muted">${esc(o.descripcion ?? '')}</div></td>
            <td class="text-end">${o.ajustePorcentaje > 0 ? '+' : ''}${num(o.ajustePorcentaje)}%</td>
            <td class="text-end">${num(o.pctProteina)}%</td><td class="text-end">${num(o.pctCarbohidratos)}%</td><td class="text-end">${num(o.pctGrasas)}%</td>
            <td class="text-end">${btn('objetivo', o.id)}</td></tr>`).join('')}</tbody></table></div></div></div></div>

      <div class="col-xl-6"><div class="tarjeta h-100"><div class="cabecera"><i class="bi bi-exclamation-triangle" style="color:var(--snt-coral)"></i><h3>Umbrales de alertas</h3></div>
        <div class="cuerpo p-0"><div class="table-responsive"><table class="table">
          <thead><tr><th>Alerta</th><th class="text-end">Umbral</th><th>Nivel</th><th>Estado</th><th></th></tr></thead>
          <tbody>${alertas.map(a => `<tr class="${a.activo ? '' : 'opacity-50'}"><td><div class="fw-semibold">${esc(a.nombre)}</div><div class="small muted">${esc(a.descripcion ?? '')}</div></td>
            <td class="text-end text-nowrap">${a.codigo === 'IMC_RIESGO' ? '—' : `${num(a.umbral, a.umbral % 1 ? 1 : 0)} ${esc(a.unidad)}`}</td>
            <td>${badgeNivel(a.nivel)}</td><td>${a.activo ? '<span class="badge b-verde">Activa</span>' : '<span class="badge b-gris">Inactiva</span>'}</td>
            <td class="text-end">${btn('alerta', a.id)}</td></tr>`).join('')}</tbody></table></div></div></div></div>
    </div>`;

  const recargar = () => render(ctx);
  const objs = estado.catalogos.objetivos;

  on(el, 'click', '[data-accion=imc]', (_, b) => {
    const c = categorias.find(x => x.id === parseInt(b.dataset.id, 10));
    abrirModal({
      titulo: `Categoría: ${c.nombre}`,
      cuerpo: `<div class="row g-3">
        <div class="col-6"><label class="form-label">IMC mínimo (incluido)</label><input type="number" step="0.01" class="form-control" name="imcMin" data-tipo="num" required value="${c.imcMin}"></div>
        <div class="col-6"><label class="form-label">IMC máximo (excluido)</label><input type="number" step="0.01" class="form-control" name="imcMax" data-tipo="num" required value="${c.imcMax}"></div>
        <div class="col-12"><label class="form-label">Objetivos permitidos</label><div>${objs.map(o => `
          <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" value="${o.id}" id="perm-${o.id}" data-permitido ${c.objetivosPermitidosIds.includes(o.id) ? 'checked' : ''}>
          <label class="form-check-label" for="perm-${o.id}">${esc(o.nombre)}</label></div>`).join('')}</div></div>
        <div class="col-12"><label class="form-label">Objetivo sugerido</label><select class="form-select" name="objetivoSugeridoId" data-tipo="int">${opciones(objs, c.objetivoSugeridoId)}</select></div>
        <div class="col-12"><label class="form-label">Mensaje</label><textarea class="form-control" name="mensaje" rows="2" maxlength="300" required>${esc(c.mensaje)}</textarea></div>
        <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="c-activo" ${c.activo ? 'checked' : ''}><label class="form-check-label" for="c-activo">Activa</label></div></div>
      </div>`,
      alGuardar: async (form) => {
        const datos = leerFormulario(form);
        datos.objetivosPermitidosIds = [...form.querySelectorAll('[data-permitido]:checked')].map(x => parseInt(x.value, 10));
        await api.put(`/api/reglas/imc/${c.id}`, datos);
        toast('Regla actualizada.');
        recargar();
      }
    });
  });

  on(el, 'click', '[data-accion=objetivo]', (_, b) => {
    const o = objetivos.find(x => x.id === parseInt(b.dataset.id, 10));
    abrirModal({
      titulo: `Objetivo: ${o.nombre}`,
      cuerpo: `<div class="row g-3">
        <div class="col-md-8"><label class="form-label">Nombre</label><input class="form-control" name="nombre" required maxlength="60" value="${esc(o.nombre)}"></div>
        <div class="col-md-4"><label class="form-label">Ajuste calórico (%)</label><input type="number" step="1" min="-30" max="30" class="form-control" name="ajustePorcentaje" data-tipo="num" required value="${o.ajustePorcentaje}"></div>
        <div class="col-4"><label class="form-label">% Proteína</label><input type="number" min="0" max="100" class="form-control" name="pctProteina" data-tipo="num" required value="${o.pctProteina}"></div>
        <div class="col-4"><label class="form-label">% Carbohidratos</label><input type="number" min="0" max="100" class="form-control" name="pctCarbohidratos" data-tipo="num" required value="${o.pctCarbohidratos}"></div>
        <div class="col-4"><label class="form-label">% Grasas</label><input type="number" min="0" max="100" class="form-control" name="pctGrasas" data-tipo="num" required value="${o.pctGrasas}"></div>
        <div class="col-12 small muted">La suma de los tres porcentajes debe ser 100.</div>
        <div class="col-12"><label class="form-label">Descripción</label><input class="form-control" name="descripcion" maxlength="300" data-nulo value="${esc(o.descripcion ?? '')}"></div>
      </div>`,
      alGuardar: async (form) => { await api.put(`/api/reglas/objetivos/${o.id}`, leerFormulario(form)); toast('Objetivo actualizado.'); recargar(); }
    });
  });

  on(el, 'click', '[data-accion=alerta]', (_, b) => {
    const a = alertas.find(x => x.id === parseInt(b.dataset.id, 10));
    abrirModal({
      titulo: `Alerta: ${a.nombre}`,
      cuerpo: `<div class="row g-3">
        <div class="col-md-6"><label class="form-label">Umbral (${esc(a.unidad)})</label><input type="number" step="0.1" min="0" class="form-control" name="umbral" data-tipo="num" required value="${a.umbral}"></div>
        <div class="col-md-6"><label class="form-label">Nivel</label><select class="form-select" name="nivel">${opciones(['Baja', 'Media', 'Alta'].map(n => ({ id: n, nombre: n })), a.nivel)}</select></div>
        <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="activo" id="a-activo" ${a.activo ? 'checked' : ''}><label class="form-check-label" for="a-activo">Alerta activa</label></div></div>
        <div class="col-12 small muted">${esc(a.descripcion ?? '')}</div>
      </div>`,
      alGuardar: async (form) => { await api.put(`/api/reglas/alertas/${a.id}`, leerFormulario(form)); toast('Umbral actualizado.'); recargar(); }
    });
  });
}
