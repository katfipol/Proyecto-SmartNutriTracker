# SmartNutriTracker · Equipo 5 – Recomendaciones Inteligentes

**Historias de usuario:** HU-23 a HU-26  
**Proyecto:** SmartNutriTracker – Colegio "Innovare" · Programación Web III  
**Tecnologías:** .NET 10 · ASP.NET Core Web API · Entity Framework Core 10 · SQL Server · HTML + JS + Bootstrap 5

Este ZIP contiene **solo la parte del Equipo 5**, con las mismas rutas del proyecto completo.
Para tener el sistema funcionando, **descomprima los 6 ZIP en la misma carpeta**: los archivos no se pisan.

---

## 1. Historias de usuario implementadas

| HU | Descripción | Implementación |
|---|---|---|
| HU-23 | Recomendación inteligente de menú | `GeneradorMenu`: reparte calorías por comida, elige alimentos por categoría sin repetir y escala porciones · `POST /api/recomendaciones/generar` |
| HU-24 | Modelo nutricional según IMC | `CategoriasImc` + `CategoriaImcObjetivos`: si el objetivo no está permitido para el IMC, se aplica el sugerido |
| HU-25 | Ajustes según objetivo | `ObjetivosNutricionales` (ajuste −15 / 0 / +10 % y reparto de macros) y `AlimentosExcluidos` |
| HU-26 | Cálculo nutricional automático | `CalculadoraNutricional`: IMC, TMB (Mifflin-St Jeor), gasto energético total, calorías y gramos de macros · `/api/calculos` |

### Cómo funciona el motor
1. Calcula el IMC y lo ubica en `CategoriasImc`.
2. Decide el objetivo: el solicitado o el del perfil. Si no está permitido para ese IMC, aplica el sugerido.
3. Calcula la TMB con Mifflin-St Jeor: `10·peso + 6.25·talla − 5·edad + 5` (hombre) o `− 161` (mujer).
4. Calcula el gasto energético total: TMB × factor de actividad.
5. Calcula las calorías: gasto total × (1 + ajuste), con un mínimo de 1400 kcal.
6. Reparte las calorías por tiempo de comida según `TiposComida`.
7. Elige alimentos según `TipoComidaCategorias`, evitando:
   - los excluidos por el estudiante;
   - los repetidos en el día;
   - los de las últimas 3 recomendaciones.
8. Escala las porciones en pasos de 0.5, guarda las observaciones y una semilla para reproducir el mismo menú.

## 2. Base de datos

**Script del equipo:** `database/por_equipo/5_Equipo5_Recomendaciones.sql`

Orden de ejecución en SSMS (base nueva): **Equipo 1 → 2 → 3 → 4 → 5 → 6**.
- El script del Equipo 1 crea la base desde cero.
- Cada script comprueba que ya se ejecutaron los anteriores.

### Tablas del equipo
- `ObjetivosNutricionales`
- `CategoriasImc`
- `CategoriaImcObjetivos`
- `AlimentosExcluidos`
- `Recomendaciones`
- `RecomendacionDetalles`
- `RecomendacionObservaciones`

### Normalización (3FN)
- Los objetivos permitidos por categoría de IMC están en una tabla puente (`CategoriaImcObjetivos`), no en un texto separado por comas (1FN).
- Las observaciones son filas en `RecomendacionObservaciones` (1FN).
- `RecomendacionDetalles` guarda solo alimento y porciones. **Los totales del menú, el IMC, la TMB y el gasto energético se calculan**, no se guardan.
- `Recomendaciones` guarda peso, talla, edad, factor y metas como **hechos históricos** de esa recomendación: dependen solo de su `Id` (no es una copia transitiva).

## 3. API REST (endpoints del equipo)

| Método | Ruta | Roles | Descripción |
|---|---|---|---|
| POST | `/api/recomendaciones/generar` | Cualquier usuario autenticado | Genera y guarda un menú diario saludable según IMC, objetivo y alimentos excluidos. |
| GET | `/api/recomendaciones/{id}` | Cualquier usuario autenticado | Obtener por id |
| GET | `/api/recomendaciones/estudiante/{estudianteId}` | Cualquier usuario autenticado | Historial |
| GET | `/api/recomendaciones/estudiante/{estudianteId}/ultima` | Cualquier usuario autenticado | Última recomendación del estudiante |
| PATCH | `/api/recomendaciones/{id}/estado` | Cualquier usuario autenticado | Cambiar estado |
| DELETE | `/api/recomendaciones/{id}` | Admin, Nutricionista | Eliminar |
| POST | `/api/calculos/nutricional` | Cualquier usuario autenticado | IMC, TMB (Mifflin-St Jeor), gasto energético, calorías y macronutrientes para datos libres. |
| GET | `/api/calculos/estudiante/{estudianteId}` | Cualquier usuario autenticado | Requerimientos del estudiante según su perfil registrado. |
| GET | `/api/reglas/imc` | Admin, Docente, Nutricionista | Listar categorías de IMC |
| PUT | `/api/reglas/imc/{id}` | Admin, Nutricionista | Editar categoría de IMC y objetivos permitidos |
| GET | `/api/reglas/objetivos` | Admin, Docente, Nutricionista | Listar objetivos nutricionales |
| PUT | `/api/reglas/objetivos/{id}` | Admin, Nutricionista | Editar objetivo (ajuste y % de macros) |
| GET | `/api/reglas/alertas` | Admin, Docente, Nutricionista | Listar tipos de alerta y umbrales |
| PUT | `/api/reglas/alertas/{id}` | Admin, Nutricionista | Editar umbral y nivel de una alerta |

Todas las rutas (salvo el login) requieren el encabezado `Authorization: Bearer <token>`.
Para probarlas en Swagger (`/swagger`):
1. Inicie sesión en `POST /api/auth/login`.
2. Copie el token.
3. Presione **Authorize**.

## 4. Frontend (pantallas del equipo)
- Recomendaciones: generar menú, ver cálculo, aceptar o rechazar, historial (`vistas/recomendaciones.js`)
- Reglas nutricionales: categorías de IMC, objetivos y umbrales (`vistas/reglas.js`)

## 5. Archivos del equipo

**Backend**
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/ContextoDatos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Controladores.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Dominio/CalculadoraNutricional.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Dominio/GeneradorMenu.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Dominio/ModelosDominio.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Dtos.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Entidades.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Servicios/Mapeos.Equipo5.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Servicios/NutricionService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Servicios/RecomendacionesService.cs`
- `src/SmartNutriTracker.Api/Modulos/Equipo5_Recomendaciones/Servicios/ReglasService.cs`

**Frontend**
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/recomendaciones.js`
- `src/SmartNutriTracker.Api/wwwroot/js/vistas/reglas.js`

**Base de datos**
- `database/por_equipo/5_Equipo5_Recomendaciones.sql`

**Pruebas**
- `tests/SmartNutriTracker.Tests/CalculadoraNutricionalTests.cs`
- `tests/SmartNutriTracker.Tests/GeneradorMenuTests.cs`

## 6. Dependencias con otros equipos
Equipos 1, 2 y 3. Usa las notificaciones del Equipo 6 para avisar al estudiante.

La integración se hace así:
- **Clase parcial `SmartNutriDbContext`:** cada equipo aporta sus `DbSet` y su configuración en `ContextoDatos.cs`, mediante el método `ConfigurarEquipo5`.
- **Clase parcial `Mapeos`:** cada equipo aporta sus conversiones a DTO.
- **Inyección de dependencias:** los servicios se registran en `Program.cs`, que entrega el Equipo 1.

## 7. Cómo ejecutar el sistema completo
1. Descomprima los 6 ZIP en la misma carpeta (por ejemplo `SmartNutriTracker/`).
2. Ejecute en SSMS los scripts `database/por_equipo/1_…sql` a `6_…sql`, en orden.
3. Ajuste la cadena de conexión en `src/SmartNutriTracker.Api/appsettings.json`.
   - Por defecto es `Server=.\\SQLEXPRESS`.
   - En el laboratorio, por ejemplo: `Server=b405-06\\SQLEXPRESS`.
4. En la carpeta raíz, ejecute:
   ```bash
   dotnet restore
   dotnet run --project src/SmartNutriTracker.Api
   ```
5. Abra http://localhost:5200 para el sistema y http://localhost:5200/swagger para la API.

**Usuarios de prueba** (contraseña `Innovare2026!`):

| Rol | Correo |
|---|---|
| Admin | admin@innovare.edu.bo |
| Nutricionista | nutricion@innovare.edu.bo |
| Docente | jvargas@innovare.edu.bo |
| Estudiante | carla.flores@innovare.edu.bo |
